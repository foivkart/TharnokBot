// Run ONCE (and again whenever you add/change commands):  npm run deploy
require('dotenv').config();
const fs = require('node:fs');
const path = require('node:path');
const { REST, Routes } = require('discord.js');

const { DISCORD_TOKEN, CLIENT_ID, GUILD_ID } = process.env;
if (!DISCORD_TOKEN || !CLIENT_ID || !GUILD_ID) {
  console.error('❌ Fill in DISCORD_TOKEN, CLIENT_ID and GUILD_ID in your .env file first.');
  process.exit(1);
}

const dir = path.join(__dirname, 'commands');
const commands = fs.readdirSync(dir)
  .filter((f) => f.endsWith('.js'))
  .map((f) => require(path.join(dir, f)).data.toJSON());

new REST().setToken(DISCORD_TOKEN)
  .put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), { body: commands })
  .then(() => console.log(`✅ Registered ${commands.length} slash commands.`))
  .catch((e) => console.error('❌ Failed to register commands:', e.message));
