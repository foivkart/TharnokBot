const { AttachmentBuilder } = require('discord.js');
const config = require('../config');
const db = require('./db');
const h = require('./helpers');
const { makeBanner } = require('./banner');
const { withBanner } = require('./panelart');

const chan = (key, fallback) => {
  const id = db.get().channels[key];
  return id ? `<#${id}>` : fallback;
};

function fill(text, member) {
  const g = member.guild;
  return text
    .replaceAll('{user}', `${member}`)
    .replaceAll('{name}', member.displayName)
    .replaceAll('{server}', g.name)
    .replaceAll('{count}', String(g.memberCount))
    .replaceAll('{rules}', chan('rules', '#κανόνες'))
    .replaceAll('{roles}', chan('roles', '#επιλογή-ρόλων'))
    .replaceAll('{tickets}', chan('tickets', '#αιτήματα'))
    .replaceAll('{applications}', chan('applications', '#αιτήσεις-στο-σώμα'));
}

async function buildWelcome(member) {
  const w = config.welcome;
  const embed = h.baseEmbed().setTitle(w.title).setDescription(fill(w.message, member));
  const payload = { content: `${member}`, embeds: [embed], allowedMentions: { users: [member.id] } };
  if (w.banner) {
    try {
      const buf = await makeBanner(member);
      if (buf) {
        payload.files = [new AttachmentBuilder(buf, { name: 'welcome.png' })];
        embed.setImage('attachment://welcome.png');
      }
    } catch (e) {
      console.warn('Banner error:', e.message);
    }
  }
  return payload;
}

const rulesPayload = () => withBanner({
  embeds: [
    h.baseEmbed()
      .setTitle('📜 Κανονισμός του Server')
      .setDescription(config.rules.map((r, n) => `**${n + 1}.** ${r}`).join('\n\n'))
      .addFields({ name: '⚠️ Σημαντικό', value: 'Η παραβίαση των κανόνων επιφέρει προειδοποίηση, σίγαση, αποβολή ή αποκλεισμό (αυτόματα από το σύστημα ασφαλείας).' }),
  ],
}, 'rules');

module.exports = { fill, buildWelcome, rulesPayload };
