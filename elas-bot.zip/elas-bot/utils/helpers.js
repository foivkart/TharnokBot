const { EmbedBuilder, PermissionFlagsBits, MessageFlags, ChannelType } = require('discord.js');
const config = require('../config');
const db = require('./db');

const EPH = MessageFlags.Ephemeral;
const cfg = () => db.get().cfg;

const isAdmin = (m) => m.permissions.has(PermissionFlagsBits.Administrator);

// ── roles ────────────────────────────────────────────────────
// Everything below uses the roles you chose with /config. If nothing is set it falls back to the
// role NAMES in config.js (so a server created with /setup works without /config).
const findRole = (guild, name) => guild.roles.cache.find((r) => r.name === name);
const rolesOf = (guild, ids) => (ids || []).map((id) => guild.roles.cache.get(id)).filter(Boolean);
const uniq = (arr) => [...new Map(arr.filter(Boolean).map((r) => [r.id, r])).values()];

/** Rank roles, lowest → highest (ordered by their position in the server's role list). */
function ladder(guild) {
  const L = rolesOf(guild, cfg().ranks);
  if (L.length) return L.sort((a, b) => a.position - b.position);
  return config.ranks.map((n) => findRole(guild, n)).filter(Boolean);
}
const rankRoles = ladder;
const rankName = (guild, i) => ladder(guild)[i]?.name ?? '—';

function rankIndex(member) {
  const L = ladder(member.guild);
  let best = -1;
  L.forEach((r, i) => { if (member.roles.cache.has(r.id)) best = i; });
  return best;
}

function commandIndex(guild) {
  const L = ladder(guild);
  const c = cfg().commandFrom;
  if (c) { const i = L.findIndex((r) => r.id === c); if (i >= 0) return i; }
  const j = L.findIndex((r) => r.name === config.commandFrom);
  return j >= 0 ? j : Math.max(0, L.length - 1);
}

const hasAny = (m, ids) => (ids || []).some((id) => m.roles.cache.has(id));

/** Has an officer role or a rank (administrators are NOT counted). */
const isStaff = (m) => rankIndex(m) >= 0 || hasAny(m, cfg().officerRoles);
const isOfficer = (m) => isAdmin(m) || isStaff(m);
const isCommand = (m) => {
  if (isAdmin(m)) return true;
  const r = rankIndex(m);
  return (r >= 0 && r >= commandIndex(m.guild)) || hasAny(m, cfg().commandRoles);
};

const commandRoleList = (guild) => uniq([...ladder(guild).slice(commandIndex(guild)), ...rolesOf(guild, cfg().commandRoles)]);
const officerRoleList = (guild) => uniq([...ladder(guild), ...rolesOf(guild, cfg().officerRoles)]);
const ticketStaffRoles = (guild) => (cfg().ticketRoles.length ? uniq([...rolesOf(guild, cfg().ticketRoles), ...commandRoleList(guild)]) : officerRoleList(guild));

const NAME_FALLBACK = () => ({ onDuty: config.onDutyRole, offDuty: config.offDutyRole, eventPing: config.eventPingRole });
/** key: onDuty | offDuty | eventPing | interviewWait | interviewDenied | blacklisted */
function roleFor(guild, key) {
  const id = cfg().roles[key];
  if (id) return guild.roles.cache.get(id) ?? null;
  const name = NAME_FALLBACK()[key];
  return name ? findRole(guild, name) ?? null : null;
}

function autoRoleList(guild, bot) {
  const ids = bot ? cfg().autoRoles.bots : cfg().autoRoles.onJoin;
  const roles = rolesOf(guild, ids);
  if (roles.length || ids.length) return roles;
  return (bot ? config.autoRoles.bots : config.autoRoles.onJoin).map((n) => findRole(guild, n)).filter(Boolean);
}

function selfRoleList(guild) {
  const c = cfg().selfRoles.map((s) => ({ role: guild.roles.cache.get(s.roleId), emoji: s.emoji })).filter((x) => x.role);
  if (c.length) return c;
  return config.selfRoles.map((s) => ({ role: findRole(guild, s.name), emoji: s.emoji })).filter((x) => x.role);
}

// Roles that /mod role_add and role_remove must never touch
function protectedRoleIds(guild) {
  const c = cfg();
  const ids = new Set([...ladder(guild).map((r) => r.id), ...c.officerRoles, ...c.commandRoles, ...Object.values(c.roles)]);
  for (const k of ['onDuty', 'offDuty']) { const r = roleFor(guild, k); if (r) ids.add(r.id); }
  return ids;
}

// ── units (ΕΚΑΜ, ΟΠΚΕ, ...) chosen with /config unit ─────────
const unitList = (guild) => cfg().units.map((u) => ({ ...u, role: guild.roles.cache.get(u.roleId) })).filter((u) => u.role);
const unitsOf = (member) => cfg().units.filter((u) => member.roles.cache.has(u.roleId));
const unitCode = (member) => unitsOf(member)[0]?.code ?? null;

// ── settings (changeable with /config setting) ───────────────
const DEFAULTS = () => ({
  weeklyQuotaMinutes: config.weeklyQuotaMinutes,
  ticketAutoCloseHours: config.tickets.autoCloseHours,
  applicationCooldownDays: config.application.cooldownDays,
  maxOpenTickets: config.tickets.maxOpenPerUser,
  signalsDefaultUnit: config.signals.defaultUnit,
  signalsSetNickname: config.signals.setNickname ? 1 : 0,
});
const setting = (k) => cfg().settings[k] ?? DEFAULTS()[k];

// ── voice channels that count for duty time ──────────────────
// Accepts a channel object (preferred) or an id. A channel counts if it was added itself or its category was added.
function voiceInfo(x) {
  if (!x) return undefined;
  const id = typeof x === 'string' ? x : x.id;
  const d = db.get();
  if (d.voiceChannels[id]) return d.voiceChannels[id];
  const parent = typeof x === 'object' ? x.parentId : null;
  if (parent && d.voiceCategories[parent]) return d.voiceCategories[parent];
  return undefined;
}

// ── channels ─────────────────────────────────────────────────
// If a specific log channel is not set, the next one in the chain is used.
const FALLBACK = {
  securityLog: ['modLog', 'logs'], modLog: ['logs'], memberLog: ['logs'], msgLog: ['logs'], serverLog: ['logs'],
  dutyLog: ['logs'], ticketLog: ['logs'], staffLog: ['logs'], appAccepted: ['appReview'], appDenied: ['appReview'],
};

async function getChannel(guild, key) {
  for (const k of [key, ...(FALLBACK[key] || [])]) {
    const id = db.get().channels[k];
    if (!id) continue;
    const ch = await guild.channels.fetch(id).catch(() => null);
    if (ch) return ch;
  }
  return null;
}

async function sendTo(guild, key, payload) {
  const ch = await getChannel(guild, key);
  if (!ch) return null;
  return ch.send(payload).catch((e) => {
    console.error(`Could not send to "${key}":`, e.message);
    return null;
  });
}

/** Category for new tickets / interview channels (kind: tickets | interviews) */
async function categoryFor(guild, kind) {
  const c = cfg().categories;
  const id = c[kind] ?? (kind === 'interviews' ? c.tickets : null) ?? db.get().channels.ticketCategory;
  return id ? guild.channels.fetch(id).catch(() => null) : null;
}

const baseEmbed = () =>
  new EmbedBuilder()
    .setColor(config.color)
    .setFooter({ text: `${config.department} • ${config.serverName}` })
    .setTimestamp();

// Optional "post it in another channel" option for slash commands
const channelOpt = (o, desc = 'Post in this channel instead of the default one') =>
  o.setName('channel').setDescription(desc).addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement);

const dm = (user, payload) => user.send(payload).then(() => true).catch(() => false);
const deny = (interaction, text) => interaction.reply({ content: `⛔ ${text}`, flags: EPH });
const unix = (ms) => Math.floor(ms / 1000);

function fmtDuration(ms) {
  const mins = Math.floor(ms / 60000);
  const h = Math.floor(mins / 60);
  return h ? `${h}ω ${mins % 60}λ` : `${mins}λ`;
}

const cut = (s, n) => (s.length > n ? s.slice(0, n - 1) + '…' : s);
const pad = (n, len = 4) => String(n).padStart(len, '0');

module.exports = {
  EPH, cfg, isAdmin, findRole, rolesOf, ladder, rankRoles, rankName, rankIndex, commandIndex, isStaff, isOfficer, isCommand,
  unitList, unitsOf, unitCode, commandRoleList, officerRoleList, ticketStaffRoles, roleFor, autoRoleList, selfRoleList, protectedRoleIds, setting,
  voiceInfo, channelOpt, getChannel, sendTo, categoryFor, baseEmbed, dm, deny, unix, fmtDuration, cut, pad,
};
