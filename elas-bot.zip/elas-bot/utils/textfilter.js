// Multilingual bad-word detection with obfuscation handling:
//  • case / accents / final-sigma / zero-width characters are ignored
//  • leetspeak (f*ck, sh1t, 5hit, @ss), stretched letters (fuuuck), separators (f.u.c.k) and spaced letters (f u c k)
//  • mixed-script tricks (Cyrillic/Greek look-alikes inside Latin words)
//  • whole-word matching, so "class", "Scunthorpe" or "γάμος" (wedding) are NOT flagged
const LISTS = require('./wordlists');

const COMB = /[\u0300-\u036f\u064b-\u065f\u0670\u0640\u200b-\u200f\u202a-\u202e\u2060\ufeff\u00ad\ufe0f]/g;
function norm(s) {
  return String(s).normalize('NFKD').replace(COMB, '').normalize('NFC').toLowerCase()
    .replace(/ς/g, 'σ').replace(/ß/g, 'ss').replace(/ı/g, 'i').replace(/ł/g, 'l')
    .replace(/đ/g, 'd').replace(/ø/g, 'o').replace(/æ/g, 'ae')
    .replace(/[أإآٱ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي');
}

const LEET = { 0: 'o', 1: 'i', 3: 'e', 4: 'a', 5: 's', 7: 't', 8: 'b', '!': 'i', '@': 'a', $: 's', '€': 'e', '+': 't' };
const deleet = (t) => t.replace(/[013457 8!@$€+]/g, (c) => LEET[c] ?? c);
const LOOK = {
  а: 'a', в: 'b', с: 'c', е: 'e', к: 'k', м: 'm', н: 'h', о: 'o', р: 'p', т: 't', у: 'y', х: 'x', і: 'i', ѕ: 's', ј: 'j',
  α: 'a', β: 'b', ε: 'e', ι: 'i', κ: 'k', ν: 'v', ο: 'o', ρ: 'p', τ: 't', υ: 'u', χ: 'x', ω: 'w', η: 'n',
};
const latinize = (t) => t.replace(/[а-яіѕјα-ω]/gu, (c) => LOOK[c] ?? c);
const invert = (m) => Object.fromEntries(Object.entries(m).map(([k, v]) => [v, k]));
const TO_CYR = { a: 'а', b: 'в', c: 'с', e: 'е', k: 'к', m: 'м', h: 'н', o: 'о', p: 'р', t: 'т', y: 'у', x: 'х', i: 'і' };
const TO_GRE = { a: 'α', b: 'β', e: 'ε', i: 'ι', k: 'κ', v: 'ν', o: 'ο', p: 'ρ', t: 'τ', u: 'υ', x: 'χ', w: 'ω', n: 'η', y: 'υ' };
const cyrillize = (t) => t.replace(/[a-z]/g, (c) => TO_CYR[c] ?? c);
const grecize = (t) => t.replace(/[a-z]/g, (c) => TO_GRE[c] ?? c);
// all alphabets a "mixed-script" token could really be written in
function scriptForms(t) {
  const out = new Set([t]);
  for (const b of [t, deleet(t)]) {
    out.add(b);
    const lat = /\p{Script=Latin}/u.test(b);
    if (lat && /\p{Script=Cyrillic}/u.test(b)) { out.add(latinize(b)); out.add(cyrillize(b)); }
    if (lat && /\p{Script=Greek}/u.test(b)) { out.add(latinize(b)); out.add(grecize(b)); }
  }
  return [...out];
}
const onlyAlnum = (t) => t.replace(/[^\p{L}\p{N}]/gu, '');

const exact = new Map();
const subs = [];
const phrases = [];
let custom = new Map();   // user-added words
let allow = new Set();    // words that must never be flagged

function addWord(word, sev, lang, target) {
  const w = norm(word.replace(/_/g, ' ')).trim();
  if (!w) return;
  if (w.startsWith('*')) target.subs.push({ w: w.slice(1), sev, lang });
  else if (w.includes(' ')) target.phrases.push({ w, sev, lang });
  else if (!target.exact.has(w)) target.exact.set(w, { sev, lang });
}
for (const [lang, sets] of Object.entries(LISTS)) {
  for (const sev of ['swear', 'slur']) {
    for (const w of (sets[sev] || '').split(/\s+/).filter(Boolean)) addWord(w, sev, lang, { exact, subs, phrases });
  }
}

let cx = { exact: new Map(), subs: [], phrases: [] };
function setCustom(words = [], allowWords = []) {
  cx = { exact: new Map(), subs: [], phrases: [] };
  for (const w of words) addWord(w.word, w.severe ? 'slur' : 'swear', 'custom', cx);
  allow = new Set(allowWords.map((w) => norm(w).trim()));
}

function variants(tok) {
  const letters = (tok.match(/\p{L}/gu) || []).length;
  if (letters < 2) return [];
  const out = new Set();
  const stripped = onlyAlnum(tok);
  const leeted = onlyAlnum(deleet(tok));
  for (const v of [stripped, leeted]) {
    if (!v) continue;
    out.add(v);
    out.add(v.replace(/(.)\1{2,}/gu, '$1$1'));
    out.add(v.replace(/(.)\1+/gu, '$1'));
  }
  for (const part of tok.split(/[.\-_*|]+/u)) {
    const p = onlyAlnum(part);
    if (p && p !== stripped) { out.add(p); out.add(p.replace(/(.)\1+/gu, '$1')); }
  }
  return [...out].filter((v) => v.length >= 2);
}

function lookup(v, hits) {
  if (allow.has(v)) return;
  const a = cx.exact.get(v) || exact.get(v);
  if (a) hits.push({ ...a, word: v, kind: 'word' });
}

/** @returns {{severity:'swear'|'slur', word:string, lang:string, kind:string}|null} */
function check(text) {
  if (!text) return null;
  const n = norm(text);
  const hits = [];
  const toks = n.split(/[\s\u3000,;:?()\[\]{}"'«»<>\\/]+/u).filter(Boolean);

  const runs = [];
  let run = [];
  const flush = () => { if (run.length >= 3) runs.push(run.join('')); run = []; };

  for (const tok of toks) {
    const s = onlyAlnum(tok);
    if (s.length === 1 && /\p{L}/u.test(s)) { run.push(s); continue; }
    if (s.length === 0) continue; // pure punctuation inside a "f . u . c . k" run
    flush();
    for (const t of scriptForms(tok)) for (const v of variants(t)) lookup(v, hits);
  }
  flush();
  for (const joined of runs) for (const v of variants(joined)) lookup(v, hits);

  // phrases
  const padded = ` ${n.replace(/[^\p{L}\p{N}]+/gu, ' ')} `;
  for (const p of [...phrases, ...cx.phrases]) {
    if (padded.includes(` ${p.w} `) && !allow.has(p.w)) hits.push({ sev: p.sev, word: p.w, lang: p.lang, kind: 'phrase' });
  }
  // substring entries (CJK, Arabic compounds...)
  const squashed = onlyAlnum(n);
  const squashedLeet = onlyAlnum(deleet(n));
  for (const sEntry of [...subs, ...cx.subs]) {
    if ((squashed.includes(sEntry.w) || squashedLeet.includes(sEntry.w)) && !allow.has(sEntry.w)) {
      hits.push({ sev: sEntry.sev, word: sEntry.w, lang: sEntry.lang, kind: 'substring' });
    }
  }

  if (!hits.length) return null;
  const best = hits.find((h) => h.sev === 'slur') || hits[0];
  return { severity: best.sev, word: best.word, lang: best.lang, kind: best.kind };
}

const stats = () => {
  const langs = {};
  for (const v of exact.values()) langs[v.lang] = (langs[v.lang] || 0) + 1;
  return { words: exact.size + subs.length + phrases.length, languages: Object.keys(langs).length, custom: cx.exact.size + cx.subs.length + cx.phrases.length };
};

module.exports = { check, setCustom, norm, stats };
