const config = require('../config');
const h = require('./helpers');

// Gives a civilian the lowest rank + the officer roles + Off Duty (used by /promote and approved applications)
async function enlist(member, reason) {
  const L = h.ladder(member.guild);
  if (!L.length) throw new Error('no ranks configured');
  const give = [L[0], ...h.rolesOf(member.guild, h.cfg().officerRoles), h.roleFor(member.guild, 'offDuty')].filter(Boolean);
  await member.roles.add(give, reason);
  for (const k of ['interviewWait', 'interviewDenied']) {
    const r = h.roleFor(member.guild, k);
    if (r && member.roles.cache.has(r.id)) await member.roles.remove(r, reason).catch(() => {});
  }
}

// dir = +1 promote, -1 demote
async function change(i, dir) {
  if (!h.isCommand(i.member)) return h.deny(i, 'Μόνο η Διοίκηση μπορεί να αλλάξει βαθμούς.');

  const target = i.options.getMember('officer');
  if (!target) return h.deny(i, 'Ο χρήστης δεν βρίσκεται στον server.');
  if (target.user.bot) return h.deny(i, 'Δεν μπορείς να βαθμολογήσεις bot.');
  if (target.id === i.user.id) return h.deny(i, 'Δεν μπορείς να αλλάξεις τον δικό σου βαθμό.');

  const L = h.ladder(i.guild);
  if (!L.length) return h.deny(i, 'Δεν έχουν οριστεί βαθμοί. Χρησιμοποίησε `/config rank_range` (ή `/config rank`).');

  const cur = h.rankIndex(target);
  const mine = h.rankIndex(i.member);
  const admin = h.isAdmin(i.member);
  const next = cur + dir;

  if (dir < 0 && cur === -1) return h.deny(i, 'Ο χρήστης δεν έχει βαθμό.');
  if (dir < 0 && cur === 0) return h.deny(i, 'Βρίσκεται ήδη στον χαμηλότερο βαθμό.');
  if (next >= L.length) return h.deny(i, 'Βρίσκεται ήδη στον ανώτατο βαθμό.');
  if (!admin && (cur >= mine || next >= mine)) {
    return h.deny(i, 'Μπορείς να διαχειριστείς μόνο βαθμούς χαμηλότερους από τον δικό σου.');
  }

  const reason = i.options.getString('reason') ?? 'Δεν δόθηκε λόγος';
  await i.deferReply();

  try {
    const old = L.filter((r) => target.roles.cache.has(r.id));
    if (old.length) await target.roles.remove(old, `Αλλαγή βαθμού από ${i.user.tag}`);
    await target.roles.add(L[next], `Αλλαγή βαθμού από ${i.user.tag}`);
    if (cur === -1) await enlist(target, `Κατάταξη από ${i.user.tag}`).catch(() => {});
  } catch (e) {
    console.error(e);
    return i.editReply('⚠️ Δεν μπόρεσα να αλλάξω τους ρόλους. Βάλε **τον ρόλο του bot πάνω από όλους τους βαθμούς** (Ρυθμίσεις server → Ρόλοι).');
  }

  const up = dir > 0;
  const embed = h.baseEmbed()
    .setColor(up ? 0x2ecc71 : 0xe74c3c)
    .setTitle(up ? '📈 Προαγωγή' : '📉 Υποβιβασμός')
    .setDescription(`${target}\n**${cur >= 0 ? L[cur].name : 'Πολίτης'}** → **${L[next].name}**`)
    .addFields(
      { name: 'Λόγος', value: h.cut(reason, 500) },
      { name: 'Από', value: `${i.member}`, inline: true },
    );
  await i.editReply({ embeds: [embed] });
  await h.sendTo(i.guild, 'staffLog', { embeds: [embed] });
  await h.dm(target.user, { embeds: [embed] });
}

module.exports = { change, enlist };
