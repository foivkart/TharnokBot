// Profanity lists. Words are space-separated; "_" inside an entry = a space (phrase);
// a leading "*" = substring match (used for languages without spaces and for long compounds).
// Accents / case do not matter – everything is normalised before matching.
// Add your own words live with /security word_add (no need to edit this file).
module.exports = {
  // ── Greek ────────────────────────────────────────────────────
  el: {
    swear: 'γαμω γαμωτο γαμησε γαμησω γαμαω γαμημενος γαμημενη γαμημενο γαμιεσαι γαμηθεις γαμηθειτε γαμιεται γαμημενε γαμησου γαμιολης γαμιολα γαμω_το γαμω_την γαμω_τη μαλακας μαλακα μαλακες μαλακια μαλακιες μαλακισμενος μαλακισμενη παλιομαλακα πουτανα πουτανες παλιοπουτανο πουτσα πουτσος πουτσες αρχιδια αρχιδι αρχιδες μουνι μουνια μουνακι καριολης καριολα καριολη καριολιδες σκατα σκατο σκατοψυχος χεσμενος χεσμενη χεστηκα χεσε_με κωλοτρυπιδα ξεκωλιαρης ψωλη ψωλες κουραδα κουραδες κωλοπαιδο πορνη πορνες τσουλα τσουλες φλωρος σκασε_μαλακα',
    slur: 'πουστης πουστη πουστηδες πουστια πουστιες γυφτος γυφτοι γυφτισσα αραπης αραπηδες νεγρος νεγροι',
  },
  // Greek written with Latin letters ("Greeklish")
  'el-latin': {
    swear: 'gamw gamo gamoto gamisou gamiesai gamimenos gamimeni gamimeno gamiolis gamiola malakas malaka malakes malakia malakies malakismenos palyomalakas poutana poutanes paliopoutana poutsa poutsos poutses archidia archidi mouni mounia kariolis kariola kariolides skata skato xesmenos xestika kolotripida psoli koyrada kourada tsoula tsoules porni',
    slur: 'poustis pousti poustidia poustia gyftos gyftoi giftos arapis arapides negros',
  },
  // ── English ──────────────────────────────────────────────────
  en: {
    swear: 'fuck fucks fucked fucker fuckers fucking fuckin motherfucker motherfuckers shit shits shitty bullshit horseshit bitch bitches bitchy asshole assholes dumbass jackass dickhead cocksucker pussy cunt cunts whore whores slut sluts bastard bastards wanker wankers twat twats blowjob handjob jizz kys kill_yourself fuck_off fuckoff stfu',
    slur: 'nigger niggers nigga niggas faggot faggots fag fags retard retards retarded tranny trannies chink chinks spic spics kike kikes coon coons dyke dykes gook gooks wetback wetbacks',
  },
  // ── European languages ───────────────────────────────────────
  es: {
    swear: 'puta putas puto putos mierda joder jodete coño cabron cabrones pendejo pendeja pendejos verga chingar chingada chingadera culero gilipollas hijueputa hijodeputa hijo_de_puta zorra malparido boludo pelotudo capullo',
    slur: 'maricon maricones marica sudaca',
  },
  fr: {
    swear: 'merde putain pute salope connard connasse encule enculer nique niquer ntm fdp batard bordel couille couilles branleur ferme_ta_gueule ta_gueule',
    slur: 'pede bougnoule youpin',
  },
  de: {
    swear: 'scheisse scheiße arschloch fotze hurensohn wichser schlampe fick ficken ficker verpiss miststuck miststück',
    slur: 'schwuchtel kanake neger spast spasti',
  },
  it: {
    swear: 'cazzo minchia merda stronzo stronza puttana troia vaffanculo fanculo coglione figa pompino bastardo',
    slur: 'frocio finocchio ricchione negro',
  },
  pt: {
    swear: 'porra caralho puta foda foder fodasse cuzao buceta filhadaputa fdp arrombado vadia',
    slur: 'viado',
  },
  nl: {
    swear: 'kut kanker klootzak hoer tering tyfus godverdomme lul neuken',
    slur: 'flikker mongool nikker',
  },
  sv: { swear: 'fitta kuk hora knulla jävla horunge', slur: 'bög' },
  pl: {
    swear: 'kurwa kurwy chuj chuje pierdolic pierdol pierdolone jebac jebany jeb skurwysyn cipa zjeb dupek',
    slur: 'ciota pedal',
  },
  ro: { swear: 'pula pizda muie futut dracu curva cacat coaie labagiu bulangiu pulamea', slur: 'poponar' },
  sq: { swear: 'kurve kurva byth bythqir pidh pidhi pidhat qifsha qifsh', slur: '' },
  // Serbian / Croatian / Bosnian (Latin + Cyrillic)
  sr: {
    swear: 'kurac kurva picka pička jebem jebote jebi govno sranje seronja курац курва пичка јебем јебо срање говно',
    slur: 'peder педер',
  },
  bg: { swear: 'курва курви путка копеле лайно шибан шибаняк майната', slur: 'педераст педал' },
  // ── Russian / Turkish ────────────────────────────────────────
  ru: {
    swear: 'хуй хуйня хуев пизда пиздец блядь бля блять ебать ебал ебаный ебан сука суки мудак мудила гандон залупа долбоеб ебанат уебок шлюха нахуй похуй',
    slur: 'пидор пидорас',
  },
  'ru-latin': {
    swear: 'hui huy huinya pizda pizdec blyat blyad ebat ebal ebanyi suka mudak mudila gandon zalupa dolboeb ebanat shlyuha nahui nahuy pohui',
    slur: 'pidor pidoras',
  },
  tr: {
    swear: 'orospu orospucocugu siktir sik amk aq amina yarrak gotveren pezevenk ananisikeyim',
    slur: 'ibne',
  },
  // ── Others ───────────────────────────────────────────────────
  ar: { swear: 'شرموطه شرموطة عاهره عاهرة قحبه قحبة منيوك كسمك كس زب ابن_الكلب', slur: 'خول' },
  hi: { swear: 'madarchod behenchod bhenchod bhosdike chutiya gandu randi', slur: '' },
  zh: { swear: '*操你妈 *傻逼 *他妈的 *妈的 *草泥马 *你妈逼', slur: '' },
  ko: { swear: '*씨발 *시발 *병신 *개새끼 *지랄 *좆', slur: '' },
  ja: { swear: '*死ね *ばか野郎', slur: '' },
};
