// Signal (callsign) boards: numbers 1-100 and 101-200 that officers pick with a button.
const config = require('../config');
const db = require('./db');
const h = require('./helpers');

const S = () => db.get().signals;
const ranges = () => config.signals.ranges;
const rangeOf = (n) => ranges().findIndex((r) => n >= r.from && n <= r.to);
const pad3 = (n) => String(n).padStart(3, '0');
const label = (n) => (n < 100 ? String(n).padStart(2, '0') : String(n)); // 9 -> 09, 33 -> 33, 116 -> 116
const callsign = (n, unit) => `${unit}-${label(n)}`;
const cleanUnit = (u) => {
  const d = String(u ?? '').replace(/\D/g, '').slice(0, 2);
  return d ? d.padStart(2, '0') : String(h.setting('signalsDefaultUnit')).replace(/\D/g, '').slice(0, 2).padStart(2, '0');
};

function numberOf(userId) {
  for (const [n, a] of Object.entries(S().assignments)) if (a.userId === userId) return Number(n);
  return null;
}
function callsignOf(userId) {
  const n = numberOf(userId);
  return n == null ? null : callsign(n, S().assignments[n].unit);
}

function assign(userId, n, unit) {
  const s = S();
  if (rangeOf(n) === -1) return { ok: false, error: 'range' };
  if (s.retired.includes(n)) return { ok: false, error: 'retired' };
  const cur = s.assignments[n];
  if (cur && cur.userId !== userId) return { ok: false, error: 'taken', by: cur.userId };
  const prev = numberOf(userId);
  if (prev != null && prev !== n) delete s.assignments[prev];
  s.assignments[n] = { userId, unit: cleanUnit(unit), at: Date.now() };
  db.save();
  return { ok: true, prev };
}

function release(userId) {
  const n = numberOf(userId);
  if (n == null) return null;
  delete S().assignments[n];
  db.save();
  return n;
}

// ── nicknames: "[xx-NN] Name" ──────────────────────────────
const PREFIX = /^\s*\[[^\]]*\]\s*/;
const baseName = (m) => (m.nickname ?? m.user.globalName ?? m.user.username).replace(PREFIX, '').trim();

async function applyNickname(member, n, unit) {
  if (!h.setting('signalsSetNickname')) return 'off';
  if (!member.manageable) return 'locked';
  const tag = `[${callsign(n, unit)}] `;
  try { await member.setNickname(tag + baseName(member).slice(0, 32 - tag.length), 'Signal assigned'); return 'ok'; } catch { return 'locked'; }
}
async function clearNickname(member) {
  if (!h.setting('signalsSetNickname') || !member?.manageable) return;
  if (member.nickname && PREFIX.test(member.nickname)) {
    await member.setNickname(member.nickname.replace(PREFIX, '').trim() || null, 'Signal released').catch(() => {});
  }
}

// ── board rendering (grid + assigned list) ─────────────────
function boardEmbed(idx) {
  const { from, to } = ranges()[idx];
  const s = S();
  const total = to - from + 1;
  let taken = 0;
  let retired = 0;
  const cells = [];
  const list = [];
  for (let n = from; n <= to; n++) {
    if (s.retired.includes(n)) { retired++; cells.push('  ✕'); }
    else if (s.assignments[n]) {
      taken++;
      cells.push('  ■');
      list.push(`\`${pad3(n)}\` [${s.assignments[n].unit}] <@${s.assignments[n].userId}>`);
    } else cells.push(pad3(n));
  }
  const rows = [];
  for (let r = 0; r < Math.ceil(cells.length / 10); r++) rows.push(cells.slice(r * 10, r * 10 + 10).join(' '));
  const free = total - taken - retired;
  const filled = Math.round(((taken + retired) / total) * 12);
  const bar = '▬'.repeat(filled) + '▭'.repeat(12 - filled);

  const e = h.baseEmbed().setColor(config.signals.color)
    .setAuthor({ name: 'Πίνακας Σημάτων' })
    .setTitle(`📻 ${pad3(from)} – ${pad3(to)}`)
    .setDescription(`\`${bar}\`  **${free}** ελεύθερα · **${taken}** κατειλημμένα${retired ? ` · **${retired}** αποσυρμένα` : ''}\n\`\`\`\n${rows.join('\n')}\n\`\`\``);

  // chunk the assigned list into fields (Discord: 1024 chars per field)
  const chunks = [];
  let cur = '';
  for (const line of list) {
    if (cur.length + line.length + 1 > 1000) { chunks.push(cur); cur = ''; }
    cur += (cur ? '\n' : '') + line;
  }
  if (cur) chunks.push(cur);
  if (!chunks.length) e.addFields({ name: 'Ανατεθειμένα', value: '— κανένα ακόμα —' });
  chunks.slice(0, 8).forEach((c, k) => e.addFields({ name: k === 0 ? 'Ανατεθειμένα' : '\u200b', value: c }));
  e.setFooter({ text: `■ κατειλημμένο   ✕ αποσυρμένο   ${String(free).padStart(3, '0')} ελεύθερα • ${config.department}` });
  return e;
}

function boardButtons(idx) {
  const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
  const { from, to } = ranges()[idx];
  return [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`signal:pick:${idx}`).setLabel(`Επιλογή σήματος (${from}-${to})`).setEmoji('🎫').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(`signal:release:${idx}`).setLabel('Αποδέσμευση του δικού μου').setEmoji('🔓').setStyle(ButtonStyle.Secondary),
  )];
}

async function refreshBoards(guild) {
  for (const b of S().boards) {
    const ch = await guild.channels.fetch(b.channelId).catch(() => null);
    const msg = await ch?.messages.fetch(b.messageId).catch(() => null);
    if (msg) await msg.edit({ embeds: [boardEmbed(b.range)], components: boardButtons(b.range) }).catch(() => {});
  }
}

module.exports = {
  S, ranges, rangeOf, pad3, label, callsign, cleanUnit, numberOf, callsignOf, assign, release,
  applyNickname, clearNickname, boardEmbed, boardButtons, refreshBoards,
};
