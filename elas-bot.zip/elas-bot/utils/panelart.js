// Adds the custom banner image (assets/banners/<key>.png) to a panel message.
// Keys: duty, tickets, applications, rules, roles. To use your own art just replace the PNG (1200x400).
const fs = require('node:fs');
const path = require('node:path');
const { AttachmentBuilder } = require('discord.js');

function withBanner(payload, key) {
  const file = path.join(__dirname, '..', 'assets', 'banners', `${key}.png`);
  if (!fs.existsSync(file)) return payload;
  payload.files = [...(payload.files || []), new AttachmentBuilder(file, { name: `${key}.png` })];
  payload.embeds[0].setImage(`attachment://${key}.png`);
  return payload;
}

module.exports = { withBanner };
