// Tiny JSON "database" – no extra installs needed. Saved in data/data.json (back it up!).
const fs = require('node:fs');
const path = require('node:path');

const FILE = path.join(__dirname, '..', 'data', 'data.json');
const TMP = FILE + '.tmp';

const defaults = () => ({
  channels: {},        // key -> channel id
  voiceChannels: {},   // channel id -> { key, counted, commandOnly, open }
  voiceCategories: {}, // category id -> { counted, commandOnly }  (every voice channel inside counts)
  // Runtime configuration set with /config (overrides the names in config.js)
  cfg: {
    ranks: [],            // role ids; the ladder is ordered by role position (lowest -> highest)
    commandFrom: null,    // role id: this rank and above = command staff
    commandRoles: [],     // extra roles that count as command staff
    officerRoles: [],     // extra roles that count as officers (e.g. the general police role)
    roles: {},            // onDuty, offDuty, eventPing, interviewWait, interviewDenied, blacklisted
    autoRoles: { onJoin: [], bots: [] },
    selfRoles: [],        // [{ roleId, emoji }]
    ticketRoles: [],      // roles that can see tickets (empty = all officers)
    categories: {},       // tickets, interviews
    settings: {},         // weeklyQuotaMinutes, ticketAutoCloseHours, ...
    units: [],            // [{ roleId, code, name }]  e.g. ΕΚΑΜ -> 07
  },
  duty: {},
  events: {},
  tickets: {},
  applications: {},
  complaints: {},
  warnings: {},
  leaves: {},
  notes: {},            // staff notes per user
  commends: {},         // commendations per user
  bolos: {},
  trainings: {},
  giveaways: {},
  reminders: [],
  ticketBlacklist: {},
  quarantine: {},
  signals: { assignments: {}, retired: [], boards: [], header: null },
  settings: { applicationsOpen: true, panels: {} },
  threat: { level: 'green', reason: null, by: null, at: null },
  security: { modules: {}, customWords: [], allowWords: [], trusted: [], strikes: {}, exemptChannels: [], exemptRoles: [], events: [], nukeLimits: {}, nukePunishment: null, lockdown: { active: false, channels: [] }, raid: { active: false, endsAt: 0, prevLevel: null } },
  counters: { report: 0, intel: 0, event: 0, ticket: 0, application: 0, complaint: 0, warning: 0, leave: 0, bolo: 0, training: 0, giveaway: 0 },
});

let data = defaults();
let timer = null;

function load() {
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  try {
    const saved = JSON.parse(fs.readFileSync(FILE, 'utf8'));
    const d = defaults();
    data = {
      ...d, ...saved,
      counters: { ...d.counters, ...saved.counters },
      settings: { ...d.settings, ...saved.settings, panels: { ...(saved.settings?.panels || {}) } },
      signals: { ...d.signals, ...saved.signals },
      cfg: {
        ...d.cfg, ...saved.cfg,
        roles: { ...(saved.cfg?.roles || {}) },
        autoRoles: { ...d.cfg.autoRoles, ...(saved.cfg?.autoRoles || {}) },
        categories: { ...(saved.cfg?.categories || {}) },
        settings: { ...(saved.cfg?.settings || {}) },
      },
      security: { ...d.security, ...saved.security, lockdown: { ...d.security.lockdown, ...saved.security?.lockdown }, raid: { ...d.security.raid, ...saved.security?.raid } },
    };
  } catch {
    data = defaults();
  }
}

function saveNow() {
  clearTimeout(timer);
  try {
    fs.writeFileSync(TMP, JSON.stringify(data, null, 2));
    fs.renameSync(TMP, FILE);
  } catch (e) {
    console.error('Could not save data:', e.message);
  }
}

function save() {
  clearTimeout(timer);
  timer = setTimeout(saveNow, 300);
}

const get = () => data;

module.exports = { load, save, saveNow, get };
