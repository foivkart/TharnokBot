// Welcome banner: assets/banner.png (Welcome emblem + LOCKDOWN logo) + the new member's avatar, name and number in the centre.
// Needs the optional package @napi-rs/canvas (installed by npm install). Without it the welcome is sent without the image.
const fs = require('node:fs');
const path = require('node:path');
const config = require('../config');

let lib = null;
try { lib = require('@napi-rs/canvas'); } catch { lib = null; }

let fontFamily = '"Segoe UI", Arial, "DejaVu Sans", "Noto Sans", sans-serif';
if (lib) {
  try {
    const dir = path.join(__dirname, '..', 'assets', 'fonts');
    let ok = false;
    if (fs.existsSync(dir)) {
      for (const f of fs.readdirSync(dir)) {
        if (/\.(ttf|otf)$/i.test(f) && lib.GlobalFonts.registerFromPath(path.join(dir, f), 'ElasFont')) ok = true;
      }
    }
    if (ok) fontFamily = `ElasFont, ${fontFamily}`;
  } catch (e) {
    console.warn('Fonts not loaded:', e.message);
  }
} else {
  console.warn('ℹ️ @napi-rs/canvas not found – welcome messages will be sent without the banner image.');
}

const W = 1200;
const H = 450;
const CX = 615; // centre of the dynamic panel (matches the base image)

async function makeBanner(member) {
  if (!lib) return null;
  const { createCanvas, loadImage } = lib;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  let base = null;
  try { base = await loadImage(path.join(__dirname, '..', config.welcome.baseImage)); } catch { /* fallback below */ }
  if (base) {
    ctx.drawImage(base, 0, 0, W, H);
  } else {
    const g = ctx.createLinearGradient(0, 0, W, H);
    g.addColorStop(0, '#06214a');
    g.addColorStop(1, '#0d5eaf');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    ctx.fillRect(CX - 195, 38, 390, H - 76);
  }

  // Avatar
  const R = 62;
  const CY = 168;
  let drewAvatar = false;
  try {
    const url = member.user.displayAvatarURL({ extension: 'png', size: 256, forceStatic: true });
    const res = await fetch(url);
    const img = await loadImage(Buffer.from(await res.arrayBuffer()));
    ctx.save();
    ctx.beginPath();
    ctx.arc(CX, CY, R, 0, Math.PI * 2);
    ctx.closePath();
    ctx.clip();
    ctx.drawImage(img, CX - R, CY - R, R * 2, R * 2);
    ctx.restore();
    drewAvatar = true;
  } catch { /* initial letter below */ }
  if (!drewAvatar) {
    ctx.fillStyle = '#5865f2';
    ctx.beginPath();
    ctx.arc(CX, CY, R, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.font = `bold 70px ${fontFamily}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'alphabetic';
    ctx.fillText((member.displayName[0] || '?').toUpperCase(), CX, CY + 24);
  }
  ctx.lineWidth = 5;
  ctx.strokeStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(CX, CY, R, 0, Math.PI * 2);
  ctx.stroke();

  // Texts
  ctx.textAlign = 'center';
  ctx.textBaseline = 'alphabetic';
  ctx.shadowColor = 'rgba(0,0,0,0.7)';
  ctx.shadowBlur = 8;

  ctx.fillStyle = '#9ec9ff';
  ctx.font = `bold 28px ${fontFamily}`;
  ctx.fillText(config.welcome.bannerTop, CX, 80);

  const name = member.displayName;
  let size = 54;
  ctx.font = `bold ${size}px ${fontFamily}`;
  while (ctx.measureText(name).width > 360 && size > 26) {
    size -= 2;
    ctx.font = `bold ${size}px ${fontFamily}`;
  }
  ctx.fillStyle = '#ffffff';
  ctx.fillText(name, CX, 302);

  ctx.shadowBlur = 0;
  ctx.fillRect(CX - 50, 326, 100, 4);

  ctx.shadowBlur = 8;
  ctx.fillStyle = '#d6e6ff';
  ctx.font = `26px ${fontFamily}`;
  ctx.fillText(`Μέλος #${member.guild.memberCount}`, CX, 364);

  ctx.fillStyle = '#9ec9ff';
  ctx.font = `bold 19px ${fontFamily}`;
  ctx.fillText(config.welcome.bannerBottom, CX, 402);

  return canvas.toBuffer('image/png');
}

module.exports = { makeBanner };
