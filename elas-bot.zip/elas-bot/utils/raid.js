// Raid mode: pauses invites, raises verification, removes recent joiners. Ends automatically.
const { GuildVerificationLevel } = require('discord.js');
const config = require('../config');
const db = require('./db');
const h = require('./helpers');
const sec = require('./security');

const timers = new Map();

async function startRaid(guild, reason, victims = []) {
  const raid = db.get().security.raid;
  if (raid.active) return false;
  const mins = config.security.antiRaid.raidModeMinutes;
  raid.active = true;
  raid.endsAt = Date.now() + mins * 60000;
  raid.prevLevel = guild.verificationLevel;
  db.save();

  try { if (typeof guild.disableInvites === 'function') await guild.disableInvites(true); } catch (e) { console.error('disableInvites:', e.message); }
  try { await guild.setVerificationLevel(GuildVerificationLevel.VeryHigh, 'Raid mode'); } catch (e) { console.error('verification:', e.message); }

  let removed = 0;
  for (const m of victims) {
    if (!m || m.user.bot || h.isStaff(m) || sec.trusted(guild, m.id)) continue;
    try {
      await h.dm(m.user, { content: `🚫 Ο server **${guild.name}** είναι προσωρινά σε προστασία από επίθεση (raid). Δοκίμασε ξανά σε λίγα λεπτά.` });
      if (config.security.antiRaid.action === 'ban') await m.ban({ reason: 'Raid mode' });
      else await m.kick('Raid mode');
      removed++;
    } catch { /* ignore */ }
  }

  await sec.logSec(guild, {
    color: 0xc0392b, title: '🚨 RAID MODE ΕΝΕΡΓΟΠΟΙΗΘΗΚΕ',
    description: `${reason}\nΟι προσκλήσεις **σταμάτησαν**, το verification ανέβηκε στο μέγιστο και αφαιρέθηκαν **${removed}** νέα μέλη.\nΛήγει αυτόματα σε **${mins} λεπτά** (ή με \`/security raidmode off\`).`,
  });
  try {
    const owner = await guild.fetchOwner();
    await owner.send(`🚨 **RAID MODE** στον ${guild.name}: ${reason}`).catch(() => {});
  } catch { /* ignore */ }

  clearTimeout(timers.get(guild.id));
  timers.set(guild.id, setTimeout(() => endRaid(guild), mins * 60000));
  return true;
}

async function endRaid(guild, by) {
  const raid = db.get().security.raid;
  if (!raid.active) return false;
  clearTimeout(timers.get(guild.id));
  try { if (typeof guild.disableInvites === 'function') await guild.disableInvites(false); } catch { /* ignore */ }
  try { if (raid.prevLevel != null) await guild.setVerificationLevel(raid.prevLevel, 'Raid mode ended'); } catch { /* ignore */ }
  raid.active = false;
  raid.endsAt = 0;
  db.save();
  await sec.logSec(guild, { color: 0x2ecc71, title: '✅ Raid mode τελείωσε', description: by ? `Απενεργοποιήθηκε από ${by}.` : 'Έληξε αυτόματα. Οι προσκλήσεις και το verification επανήλθαν.' });
  return true;
}

// After a restart, resume or finish a raid that was running
function resume(client) {
  const raid = db.get().security.raid;
  if (!raid.active) return;
  for (const guild of client.guilds.cache.values()) {
    const left = raid.endsAt - Date.now();
    if (left <= 0) endRaid(guild);
    else timers.set(guild.id, setTimeout(() => endRaid(guild), left));
  }
}

module.exports = { startRaid, endRaid, resume };
