// Server lockdown: nobody (except admins) can write in the public channels until it is lifted.
const { ChannelType, PermissionFlagsBits: P } = require('discord.js');
const db = require('./db');
const sec = require('./security');

const TEXTY = [ChannelType.GuildText, ChannelType.GuildAnnouncement, ChannelType.GuildForum];

async function lock(guild, by, reason) {
  const L = sec.S().lockdown;
  if (L.active) return 0;
  const everyone = guild.roles.everyone;
  const changed = [];
  for (const ch of guild.channels.cache.values()) {
    if (!TEXTY.includes(ch.type)) continue;
    const perms = ch.permissionsFor(everyone);
    if (!perms?.has(P.ViewChannel) || !perms.has(P.SendMessages)) continue; // only channels people can write in
    const ow = ch.permissionOverwrites.cache.get(everyone.id);
    const prev = ow?.allow.has(P.SendMessages) ? true : ow?.deny.has(P.SendMessages) ? false : null;
    try {
      await ch.permissionOverwrites.edit(everyone, { SendMessages: false }, { reason: `Lockdown: ${reason}` });
      changed.push({ id: ch.id, prev });
    } catch { /* skip */ }
  }
  L.active = true;
  L.channels = changed;
  db.save();
  await sec.logSec(guild, { color: 0xc0392b, title: '🔒 LOCKDOWN ΕΝΕΡΓΟΠΟΙΗΘΗΚΕ', description: `${by}: ${reason}\nΚλειδώθηκαν **${changed.length}** κανάλια.` });
  return changed.length;
}

async function unlock(guild, by) {
  const L = sec.S().lockdown;
  if (!L.active) return 0;
  let n = 0;
  for (const c of L.channels) {
    const ch = guild.channels.cache.get(c.id);
    if (!ch) continue;
    try {
      await ch.permissionOverwrites.edit(guild.roles.everyone, { SendMessages: c.prev }, { reason: 'Lockdown lifted' });
      n++;
    } catch { /* skip */ }
  }
  L.active = false;
  L.channels = [];
  db.save();
  await sec.logSec(guild, { color: 0x2ecc71, title: '🔓 Lockdown τελείωσε', description: `${by}. Ξεκλειδώθηκαν **${n}** κανάλια.` });
  return n;
}

module.exports = { lock, unlock };
