// Shared security helpers: module switches, trust list, strikes and the punishment ladder.
const config = require('../config');
const db = require('./db');
const h = require('./helpers');
const filter = require('./textfilter');

const S = () => db.get().security;
const moduleOn = (name) => S().modules[name] ?? config.security.modules[name];

const trusted = (guild, userId) =>
  userId === guild.ownerId ||
  userId === guild.client.user.id ||
  config.security.antiNuke.trusted.includes(userId) ||
  S().trusted.includes(userId);

const loadFilter = () => filter.setCustom(S().customWords, S().allowWords);

const isExemptChannel = (id) => config.security.exemptChannels.includes(id) || S().exemptChannels.includes(id);
const nukeLimit = (key) => S().nukeLimits[key] ?? config.security.antiNuke.limits[key];
const nukePunishment = () => S().nukePunishment ?? config.security.antiNuke.punishment;

// Who is ignored by the chat filters. kind: 'language' | 'spam'
function exempt(member, kind = 'spam') {
  if (h.isAdmin(member)) return true;
  const names = [...config.security.exemptRoles, ...S().exemptRoles];
  if (names.some((n) => member.roles.cache.some((r) => r.name === n))) return true;
  return kind === 'spam' && h.isCommand(member);
}

const notice = async (channel, text) => {
  const m = await channel.send({ content: text, allowedMentions: { parse: ['users'] } }).catch(() => null);
  if (m) setTimeout(() => m.delete().catch(() => {}), 8000);
};

// Last 100 security events (shown by /security audit)
function record(title, description) {
  const ev = S().events;
  ev.push({ at: Date.now(), title: String(title).slice(0, 80), text: String(description || '').slice(0, 160) });
  if (ev.length > 100) ev.shift();
  db.save();
}

async function logSec(guild, { color = 0xe67e22, title, description, fields = [], channelKey = 'securityLog' }) {
  record(title, description);
  const e = h.baseEmbed().setColor(color).setTitle(title);
  if (description) e.setDescription(h.cut(description, 4000));
  if (fields.length) e.addFields(fields.map((f) => ({ ...f, value: h.cut(String(f.value || '—'), 1024) })));
  return h.sendTo(guild, channelKey, { embeds: [e] });
}

function strikesOf(userId) {
  const r = S().strikes[userId];
  if (!r) return 0;
  if (Date.now() - r.last > config.security.strikeDecayHours * 3600000) return 0;
  return r.count;
}
const clearStrikes = (userId) => { delete S().strikes[userId]; db.save(); };

async function punish(member, entry, reason, channel) {
  const why = `AutoMod: ${reason}`;
  const sec = config.security;
  const tell = (txt) => (sec.notifyDM ? h.dm(member.user, { content: txt }) : Promise.resolve());
  try {
    if (entry.action === 'warn') {
      if (channel) await notice(channel, `⚠️ ${member}, ${reason}. Αυτή είναι **προειδοποίηση**.`);
      return 'warn';
    }
    if (entry.action === 'timeout') {
      if (!member.moderatable) return `timeout ${entry.minutes}m (failed – role too high)`;
      await tell(`⏳ Σου έγινε σίγαση **${entry.minutes} λεπτών** στον **${member.guild.name}**.\nΛόγος: ${reason}`);
      await member.timeout(entry.minutes * 60000, why);
      return `timeout ${entry.minutes}m`;
    }
    if (entry.action === 'kick') {
      if (!member.kickable) return 'kick (failed – role too high)';
      await tell(`👢 Αποβλήθηκες από τον **${member.guild.name}**.\nΛόγος: ${reason}`);
      await member.kick(why);
      return 'kick';
    }
    if (entry.action === 'ban') {
      if (!member.bannable) return 'ban (failed – role too high)';
      await tell(`🔨 Αποκλείστηκες από τον **${member.guild.name}**.\nΛόγος: ${reason}`);
      await member.ban({ reason: why });
      return 'ban';
    }
  } catch (e) {
    console.error('Punish error:', e.message);
    return `${entry.action} (failed)`;
  }
  return 'none';
}

/** Adds strikes and applies the ladder step that was just reached. */
async function applyStrikes(member, n, reason, channel) {
  const all = S().strikes;
  const now = Date.now();
  const rec = (all[member.id] ??= { count: 0, last: 0, log: [] });
  if (now - rec.last > config.security.strikeDecayHours * 3600000) rec.count = 0;
  const prev = rec.count;
  rec.count += n;
  rec.last = now;
  rec.log.push({ at: now, n, reason: reason.slice(0, 120) });
  if (rec.log.length > 20) rec.log.shift();
  db.save();
  const entry = config.security.ladder.filter((e) => e.at <= rec.count && e.at > prev).at(-1);
  const action = entry ? await punish(member, entry, reason, channel) : 'message deleted';
  return { count: rec.count, action };
}

module.exports = { S, moduleOn, trusted, loadFilter, exempt, isExemptChannel, nukeLimit, nukePunishment, notice, record, logSec, strikesOf, clearStrikes, applyStrikes };
