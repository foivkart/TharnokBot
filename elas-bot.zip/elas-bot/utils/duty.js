// On Duty / Off Duty system.
// Duty time is counted ONLY while an On Duty officer is connected to a "counted" duty voice channel.
const db = require('./db');
const h = require('./helpers');
const config = require('../config');

const sessions = new Map(); // userId -> { since (last checkpoint), start, channelId }

const weekKey = (t = Date.now()) => {
  const d = new Date(t);
  d.setUTCHours(0, 0, 0, 0);
  d.setUTCDate(d.getUTCDate() - ((d.getUTCDay() + 6) % 7)); // Monday
  return d.toISOString().slice(0, 10);
};

function rec(id, name) {
  const all = db.get().duty;
  const r = (all[id] ??= {
    name: name || 'Άγνωστος', onDuty: false, dutySince: null, shiftMs: 0,
    callMs: 0, calls: 0, events: 0, week: { key: weekKey(), ms: 0 },
  });
  if (name) r.name = name;
  if (r.week.key !== weekKey()) r.week = { key: weekKey(), ms: 0 };
  return r;
}

const live = (id) => (sessions.has(id) ? Date.now() - sessions.get(id).since : 0);
const totalMs = (id) => rec(id).callMs + live(id);
const weekMs = (id) => rec(id).week.ms + live(id);
const inCall = (id) => sessions.has(id);
const callChannel = (id) => sessions.get(id)?.channelId;

function addTime(id, ms) {
  const r = rec(id);
  r.callMs += ms;
  r.week.ms += ms;
  r.shiftMs += ms;
}

function startCall(member, channelId) {
  const s = sessions.get(member.id);
  if (s) { s.channelId = channelId; return; }
  const r = rec(member.id, member.displayName);
  const now = Date.now();
  sessions.set(member.id, { since: now, start: now, channelId });
  r.calls++;
  db.save();
}

async function endCall(id, guild) {
  const s = sessions.get(id);
  if (!s) return 0;
  const now = Date.now();
  addTime(id, now - s.since);
  sessions.delete(id);
  db.save();
  const len = now - s.start;
  if (guild && len >= 5000) {
    await h.sendTo(guild, 'dutyLog', {
      embeds: [h.baseEmbed().setColor(0x7f8c8d).setDescription(`🎧 <@${id}> τελείωσε την κλήση στο <#${s.channelId}> • διάρκεια **${h.fmtDuration(len)}**`)],
    });
  }
  return len;
}

// Called every minute: saves running sessions so a crash loses at most ~1 minute
function checkpoint() {
  const now = Date.now();
  for (const [id, s] of sessions) { addTime(id, now - s.since); s.since = now; }
  if (sessions.size) db.save();
}

async function swapRoles(member, on) {
  const onRole = h.roleFor(member.guild, 'onDuty');
  const offRole = h.roleFor(member.guild, 'offDuty');
  try {
    if (on) { if (onRole) await member.roles.add(onRole); if (offRole) await member.roles.remove(offRole); }
    else { if (offRole) await member.roles.add(offRole); if (onRole) await member.roles.remove(onRole); }
  } catch (e) {
    console.error('Duty roles:', e.message);
  }
}

async function goOn(member) {
  const r = rec(member.id, member.displayName);
  if (r.onDuty) return 'Είσαι ήδη **On Duty**.';
  r.onDuty = true;
  r.dutySince = Date.now();
  r.shiftMs = 0;
  db.save();
  await swapRoles(member, true);
  await h.sendTo(member.guild, 'dutyLog', {
    embeds: [h.baseEmbed().setColor(0x2ecc71).setDescription(`🟢 Ο/Η ${member} είναι τώρα **On Duty**`)],
  });
  const warn = h.roleFor(member.guild, 'onDuty') ? '' : '\n⚠️ Δεν έχει οριστεί ρόλος On Duty (`/config role`).';
  return `🟢 Είσαι πλέον **On Duty**. Μπες σε φωνητικό κανάλι της ΕΛ.ΑΣ. — ο χρόνος μετράει **μόνο όσο είσαι σε κλήση**.${warn}`;
}

async function goOff(member) {
  const r = rec(member.id, member.displayName);
  if (!r.onDuty) return 'Δεν είσαι **On Duty**.';
  await endCall(member.id, member.guild);
  const since = r.dutySince;
  r.onDuty = false;
  r.dutySince = null;
  db.save();
  await swapRoles(member, false);
  if (h.voiceInfo(member.voice?.channel)?.counted) await member.voice.disconnect('Off Duty').catch(() => {});
  await h.sendTo(member.guild, 'dutyLog', {
    embeds: [
      h.baseEmbed().setColor(0xe74c3c).setDescription(
        `🔴 Ο/Η ${member} είναι τώρα **Off Duty**\nΒάρδια: **${since ? h.fmtDuration(Date.now() - since) : '—'}** • Χρόνος σε κλήση: **${h.fmtDuration(r.shiftMs)}**`,
      ),
    ],
  });
  return `🔴 Είσαι πλέον **Off Duty**. Χρόνος σε κλήση σε αυτή τη βάρδια: **${h.fmtDuration(r.shiftMs)}**.`;
}

// Member left the server / lost officer status
async function forceOff(userId, guild) {
  await endCall(userId, guild);
  const r = db.get().duty[userId];
  if (r?.onDuty) { r.onDuty = false; r.dutySince = null; db.save(); }
}

// On startup: align stored state with the real roles and voice channels
async function sync(client) {
  sessions.clear();
  for (const guild of client.guilds.cache.values()) {
    await guild.members.fetch().catch(() => {});
    const onRole = h.roleFor(guild, 'onDuty');
    for (const m of guild.members.cache.values()) {
      if (m.user.bot || !h.isStaff(m)) continue;
      const r = rec(m.id, m.displayName);
      const has = !!onRole && m.roles.cache.has(onRole.id);
      if (has && !r.onDuty) { r.onDuty = true; r.dutySince = Date.now(); r.shiftMs = 0; }
      if (!has && r.onDuty) { r.onDuty = false; r.dutySince = null; }
    }
    for (const ch of guild.channels.cache.values()) {
      const info = h.voiceInfo(ch);
      if (!info?.counted || !ch.isVoiceBased()) continue;
      for (const m of ch.members.values()) {
        if (m.user.bot) continue;
        if (rec(m.id).onDuty && (!info.commandOnly || h.isCommand(m))) startCall(m, ch.id);
        else if (!h.isAdmin(m)) m.voice.disconnect('Δεν είσαι On Duty').catch(() => {});
      }
    }
  }
  db.save();
}

module.exports = { rec, totalMs, weekMs, inCall, callChannel, startCall, endCall, checkpoint, goOn, goOff, forceOff, sync, weekKey };
