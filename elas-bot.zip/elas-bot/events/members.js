// Member join / leave: autoroles, welcome banner, goodbye, logs
const { Events } = require('discord.js');
const config = require('../config');
const h = require('../utils/helpers');
const duty = require('../utils/duty');
const { buildWelcome, fill } = require('../utils/welcome');

function register(client) {
  client.on(Events.GuildMemberAdd, async (member) => {
    try {
      // 1) Autoroles
      const roles = h.autoRoleList(member.guild, member.user.bot);
      if (roles.length) {
        await member.roles.add(roles, 'Autoroles')
          .catch((e) => console.error('Autoroles:', e.message));
      }

      // 2) Welcome
      if (config.welcome.enabled && !member.user.bot) {
        const ch = await h.getChannel(member.guild, 'welcome');
        if (ch) await ch.send(await buildWelcome(member)).catch((e) => console.error('Welcome:', e.message));
        if (config.welcome.dm) await h.dm(member.user, { content: fill(config.welcome.dm, member) });
      }

      // 3) Log
      const ageDays = Math.floor((Date.now() - member.user.createdTimestamp) / 86400000);
      const e = h.baseEmbed()
        .setColor(0x2ecc71)
        .setTitle(member.user.bot ? '🤖 Είσοδος bot' : '📥 Είσοδος μέλους')
        .setThumbnail(member.user.displayAvatarURL())
        .setDescription(`${member} (${member.user.tag})`)
        .addFields(
          { name: 'Λογαριασμός δημιουργήθηκε', value: `<t:${h.unix(member.user.createdTimestamp)}:R>`, inline: true },
          { name: 'Σύνολο μελών', value: String(member.guild.memberCount), inline: true },
        );
      if (ageDays < 7) e.addFields({ name: '⚠️ Προσοχή', value: `Πολύ νέος λογαριασμός (${ageDays} ημερών).` });
      await h.sendTo(member.guild, 'memberLog', { embeds: [e] });
    } catch (err) {
      console.error('GuildMemberAdd:', err);
    }
  });

  client.on(Events.GuildMemberRemove, async (member) => {
    try {
      await duty.forceOff(member.id, member.guild); // closes any running call / duty

      if (config.welcome.enabled && !member.user.bot) {
        await h.sendTo(member.guild, 'welcome', {
          embeds: [h.baseEmbed().setColor(0x7f8c8d).setDescription(fill(config.welcome.goodbye, member))],
        });
      }
      const roles = member.roles?.cache?.filter((r) => r.id !== member.guild.id).map((r) => r.name).join(', ');
      await h.sendTo(member.guild, 'memberLog', {
        embeds: [
          h.baseEmbed().setColor(0xe74c3c).setTitle('📤 Αποχώρηση μέλους')
            .setThumbnail(member.user.displayAvatarURL())
            .setDescription(`${member.user} (${member.user.tag})`)
            .addFields({ name: 'Ρόλοι', value: h.cut(roles || '—', 1000) }),
        ],
      });
    } catch (err) {
      console.error('GuildMemberRemove:', err);
    }
  });
}

module.exports = { register };
