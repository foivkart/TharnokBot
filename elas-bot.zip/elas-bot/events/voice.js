// Duty voice channels: only On Duty officers may stay; time is counted only while connected.
const { Events } = require('discord.js');
const duty = require('../utils/duty');
const h = require('../utils/helpers');

function register(client) {
  client.on(Events.VoiceStateUpdate, async (oldS, newS) => {
    try {
      const member = newS.member ?? oldS.member;
      if (!member || member.user.bot) return;

      const info = h.voiceInfo(newS.channel);
      if (info?.counted) {
        const r = duty.rec(member.id, member.displayName);
        const wrongRank = info.commandOnly && !h.isCommand(member);
        if (r.onDuty && !wrongRank) {
          duty.startCall(member, newS.channelId);
          return;
        }
        if (!h.isAdmin(member)) {
          await newS.disconnect(wrongRank ? 'Μόνο η Διοίκηση' : 'Δεν είσαι On Duty').catch(() => {});
          await h.sendTo(member.guild, 'dutyLog', {
            embeds: [h.baseEmbed().setColor(0xe67e22).setDescription(
              `⛔ Ο/Η ${member} προσπάθησε να μπει στο <#${newS.channelId}> ${wrongRank ? '(μόνο Διοίκηση)' : 'χωρίς να είναι **On Duty**'} και αποσυνδέθηκε.`,
            )],
          });
          return;
        }
        return; // administrators may join without being counted
      }
      // left the call, or moved to a channel that is not counted
      if (duty.inCall(member.id)) await duty.endCall(member.id, member.guild);
    } catch (e) {
      console.error('VoiceStateUpdate (duty):', e.message);
    }
  });
}

module.exports = { register };
