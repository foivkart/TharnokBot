// AutoMod: bad language (every supported language), invites, links, mentions, caps, emoji, zalgo, flood, duplicates, nicknames.
// Every violation deletes the message, adds strikes and applies the punishment ladder (warn → timeout → kick → ban).
const { Events, PermissionFlagsBits } = require('discord.js');
const config = require('../config');
const h = require('../utils/helpers');
const filter = require('../utils/textfilter');
const sec = require('../utils/security');

const INVITE = /(?:discord(?:app)?\.(?:gg|com\/invite)|dsc\.gg|discord\.me|invite\.gg)\/[\w-]+/i;
const SCAM = /free\s*nitro|nitro\s*(?:giveaway|gift)|steamcommunity\.com\/gift|discord\.gift\/|steam\s*gift/i;
const URL_RE = /\bhttps?:\/\/[^\s<>()]+|\b(?:[a-z0-9-]+\.)+(?:com|net|org|gg|io|me|xyz|ru|tk|ml|ga|cf|gq|link|club|site|online|shop|top|app|co|cc|ly|to)\b(?:\/\S*)?/gi;
const EMOJI = /<a?:\w+:\d+>|\p{Extended_Pictographic}/gu;
const ZALGO = /[\u0300-\u036f\u0489\u1ab0-\u1aff\u1dc0-\u1dff\u20d0-\u20ff]{4,}/u;

const recent = new Map(); // userId -> [{ id, channelId, at, sig }]

function hostOf(raw) {
  try { return new URL(/^https?:\/\//i.test(raw) ? raw : `http://${raw}`).hostname.toLowerCase().replace(/^www\./, ''); } catch { return null; }
}
const allowedHost = (host) => config.security.allowedDomains.some((d) => host === d || host.endsWith(`.${d}`));

function track(m) {
  const now = Date.now();
  const arr = (recent.get(m.author.id) ?? []).filter((e) => now - e.at < 60000);
  arr.push({ id: m.id, channelId: m.channelId, at: now, sig: filter.norm(m.content || '').replace(/\s+/g, ' ').trim().slice(0, 200) });
  recent.set(m.author.id, arr.slice(-25));
  return arr;
}

/** Returns { rule, label, strikes, detail, extra? } or null */
function evaluate(m, member, edited) {
  const text = m.content || '';
  const L = config.security.limits;
  const severe = config.security.severeStrikes;

  if (!sec.exempt(member, 'language')) {
    if (sec.moduleOn('badWords') && text) {
      const r = filter.check(text);
      if (r) {
        return {
          rule: 'badWords', strikes: r.severity === 'slur' ? severe : 1,
          label: r.severity === 'slur' ? 'υβριστική / ρατσιστική έκφραση' : 'ακατάλληλη γλώσσα',
          detail: `${r.lang} • «${r.word}»`,
        };
      }
    }
  }
  if (sec.exempt(member, 'spam')) return null;

  if (sec.moduleOn('invites') && INVITE.test(text)) return { rule: 'invites', strikes: severe, label: 'διαφήμιση / πρόσκληση server', detail: 'invite link' };
  if (sec.moduleOn('links') && text) {
    if (SCAM.test(text)) return { rule: 'links', strikes: severe, label: 'ύποπτος σύνδεσμος (scam)', detail: 'scam pattern' };
    for (const raw of text.match(URL_RE) || []) {
      const host = hostOf(raw);
      if (host && !allowedHost(host)) return { rule: 'links', strikes: 1, label: 'μη επιτρεπτός σύνδεσμος', detail: host };
    }
  }
  if (sec.moduleOn('mentions')) {
    if (/@(?:everyone|here)/.test(text) && !member.permissions.has(PermissionFlagsBits.MentionEveryone)) {
      return { rule: 'mentions', strikes: severe, label: 'κατάχρηση @everyone/@here', detail: '@everyone' };
    }
    const n = m.mentions.users.size + m.mentions.roles.size;
    if (n > L.mentions) return { rule: 'mentions', strikes: 2, label: 'υπερβολικά πολλά mentions', detail: `${n} mentions` };
  }
  if (edited) return null;

  if (sec.moduleOn('zalgo') && ZALGO.test(text)) return { rule: 'zalgo', strikes: 1, label: 'παραμορφωμένο κείμενο', detail: 'zalgo' };
  if (sec.moduleOn('emoji')) {
    const n = (text.match(EMOJI) || []).length;
    if (n > L.emoji) return { rule: 'emoji', strikes: 1, label: 'spam από emoji', detail: `${n} emoji` };
  }
  if (sec.moduleOn('caps')) {
    const letters = text.replace(/[^\p{L}]/gu, '');
    if (letters.length >= L.caps.minLetters) {
      const upper = letters.replace(/[^\p{Lu}]/gu, '').length;
      if (upper / letters.length > L.caps.ratio) return { rule: 'caps', strikes: 1, label: 'υπερβολικά κεφαλαία', detail: `${Math.round((upper / letters.length) * 100)}% caps` };
    }
  }

  const arr = track(m);
  const now = Date.now();
  if (sec.moduleOn('spam')) {
    const burst = arr.filter((e) => now - e.at <= L.spam.seconds * 1000);
    if (burst.length >= L.spam.messages) return { rule: 'spam', strikes: 2, label: 'flood μηνυμάτων', detail: `${burst.length} μηνύματα/${L.spam.seconds}δ`, extra: burst };
  }
  if (sec.moduleOn('duplicates') && arr.at(-1).sig.length >= 4) {
    const same = arr.filter((e) => e.sig === arr.at(-1).sig && now - e.at <= L.duplicates.seconds * 1000);
    if (same.length >= L.duplicates.count) return { rule: 'duplicates', strikes: 2, label: 'επαναλαμβανόμενο μήνυμα', detail: `${same.length}× ίδιο μήνυμα`, extra: same };
  }
  return null;
}

async function handle(m, member, v) {
  const ids = new Map(); // channelId -> [messageIds]
  for (const e of v.extra || []) ids.set(e.channelId, [...(ids.get(e.channelId) || []), e.id]);
  if (!ids.has(m.channelId)) ids.set(m.channelId, [m.id]);
  for (const [chId, list] of ids) {
    const ch = m.guild.channels.cache.get(chId);
    if (!ch) continue;
    if (list.length > 1) await ch.bulkDelete(list, true).catch(() => {});
    else await ch.messages.delete(list[0]).catch(() => {});
  }
  recent.delete(member.id);

  const res = await sec.applyStrikes(member, v.strikes, v.label, m.channel);
  if (res.action === 'message deleted') await sec.notice(m.channel, `🚫 ${member}, το μήνυμά σου αφαιρέθηκε (${v.label}).`);

  await sec.logSec(m.guild, {
    title: `🛡️ AutoMod • ${v.rule}`,
    description: `${member} (${member.user.tag}) στο ${m.channel}`,
    fields: [
      { name: 'Λόγος', value: `${v.label} — ${v.detail}`, inline: false },
      { name: 'Strikes', value: `+${v.strikes} → σύνολο **${res.count}**`, inline: true },
      { name: 'Ενέργεια', value: res.action, inline: true },
      { name: 'Μήνυμα', value: m.content ? `\`\`\`${h.cut(m.content.replace(/`/g, "'"), 500)}\`\`\`` : '—' },
    ],
  });
}

async function onMessage(m, edited) {
  try {
    if (!m.guild || m.author?.bot || m.webhookId || m.system) return;
    if (sec.isExemptChannel(m.channelId)) return;
    const member = m.member ?? (await m.guild.members.fetch(m.author.id).catch(() => null));
    if (!member) return;
    if (h.isAdmin(member)) return;
    const v = evaluate(m, member, edited);
    if (v) await handle(m, member, v);
  } catch (e) {
    console.error('AutoMod:', e.message);
  }
}

async function checkName(member) {
  try {
    if (member.user.bot || !sec.moduleOn('nicknames') || sec.exempt(member, 'language')) return;
    const r = filter.check(member.displayName) || filter.check(member.user.username);
    if (!r) return;
    if (member.manageable) await member.setNickname('Moderated User', 'AutoMod: ακατάλληλο όνομα').catch(() => {});
    await sec.logSec(member.guild, {
      color: 0xf1c40f, title: '🛡️ AutoMod • nickname',
      description: `${member} (${member.user.tag})`,
      fields: [{ name: 'Λόγος', value: `ακατάλληλο όνομα — ${r.lang} • «${r.word}»` }],
    });
  } catch (e) { console.error('AutoMod name:', e.message); }
}

function register(client) {
  client.once(Events.ClientReady, () => sec.loadFilter());
  client.on(Events.MessageCreate, (m) => onMessage(m, false));
  client.on(Events.MessageUpdate, (_o, m) => { if (m.content != null) onMessage(m, true); });
  client.on(Events.GuildMemberAdd, checkName);
  client.on(Events.GuildMemberUpdate, (o, n) => { if (o.nickname !== n.nickname) checkName(n); });
}

module.exports = { register, evaluate };
