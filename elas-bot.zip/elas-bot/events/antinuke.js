// Anti-nuke: detects mass destructive actions through the audit log, punishes the attacker,
// restores deleted channels, removes what the attacker created, kicks unauthorised bots and reverts dangerous permission grants.
const { Events, AuditLogEvent: A, PermissionFlagsBits: P, ChannelType } = require('discord.js');
const config = require('../config');
const db = require('../utils/db');
const h = require('../utils/helpers');
const sec = require('../utils/security');

const DANGEROUS = [P.Administrator, P.ManageGuild, P.ManageRoles, P.ManageChannels, P.BanMembers, P.KickMembers, P.ManageWebhooks, P.MentionEveryone];
const SNAP_TYPES = [ChannelType.GuildText, ChannelType.GuildVoice, ChannelType.GuildCategory, ChannelType.GuildAnnouncement, ChannelType.GuildStageVoice, ChannelType.GuildForum];

const hits = new Map();     // "uid:key" -> [timestamps]
const created = new Map();  // uid -> [{ type, id, at }]
const deleted = new Map();  // uid -> [{ snap, at }]
const punishing = new Set();
const snaps = new Map();    // channelId -> snapshot

function snapshot(c) {
  if (!c.guild || !SNAP_TYPES.includes(c.type)) return;
  snaps.set(c.id, {
    id: c.id, name: c.name, type: c.type, parentId: c.parentId ?? null, position: c.rawPosition,
    topic: c.topic ?? undefined, nsfw: c.nsfw, rateLimitPerUser: c.rateLimitPerUser, bitrate: c.bitrate, userLimit: c.userLimit,
    overwrites: c.permissionOverwrites?.cache.map((o) => ({ id: o.id, type: o.type, allow: o.allow.bitfield, deny: o.deny.bitfield })) ?? [],
  });
}

function bump(uid, key) {
  const k = `${uid}:${key}`;
  const now = Date.now();
  const win = config.security.antiNuke.windowSeconds * 1000;
  const arr = (hits.get(k) ?? []).filter((t) => now - t < win);
  arr.push(now);
  hits.set(k, arr);
  return arr.length;
}
const push = (map, uid, item) => map.set(uid, [...(map.get(uid) ?? []).filter((x) => Date.now() - x.at < 300000), { ...item, at: Date.now() }]);

function remap(oldId, newId) {
  const d = db.get();
  for (const [k, v] of Object.entries(d.channels)) if (v === oldId) d.channels[k] = newId;
  if (d.voiceChannels[oldId]) { d.voiceChannels[newId] = d.voiceChannels[oldId]; delete d.voiceChannels[oldId]; }
  for (const t of Object.values(d.tickets)) if (t.channelId === oldId) t.channelId = newId;
  db.save();
}

async function restoreChannels(guild, list) {
  const order = [...list].sort((a, b) => (a.snap.type === ChannelType.GuildCategory ? 0 : 1) - (b.snap.type === ChannelType.GuildCategory ? 0 : 1));
  const idMap = new Map();
  let restored = 0;
  for (const { snap } of order) {
    if (guild.channels.cache.has(snap.id)) continue;
    const parent = snap.parentId ? (idMap.get(snap.parentId) ?? (guild.channels.cache.has(snap.parentId) ? snap.parentId : null)) : null;
    try {
      const ch = await guild.channels.create({
        name: snap.name, type: snap.type, parent: snap.type === ChannelType.GuildCategory ? undefined : parent,
        topic: snap.topic, nsfw: snap.nsfw, rateLimitPerUser: snap.rateLimitPerUser, bitrate: snap.bitrate, userLimit: snap.userLimit,
        permissionOverwrites: snap.overwrites.filter((o) => guild.roles.cache.has(o.id) || guild.members.cache.has(o.id))
          .map((o) => ({ id: o.id, type: o.type, allow: o.allow, deny: o.deny })),
        reason: 'Anti-nuke: επαναφορά καναλιού',
      });
      idMap.set(snap.id, ch.id);
      remap(snap.id, ch.id);
      snapshot(ch);
      restored++;
    } catch (e) {
      console.error('Restore channel:', e.message);
    }
  }
  return restored;
}

async function nuke(guild, uid, key, count) {
  if (punishing.has(uid)) return;
  punishing.add(uid);
  setTimeout(() => punishing.delete(uid), 120000);
  const cfg = config.security.antiNuke;
  const preferred = sec.nukePunishment();
  const member = await guild.members.fetch(uid).catch(() => null);

  // 1) punish (preferred action, then fall back to ban / kick)
  let result = null;
  const attempts = [preferred, 'ban', 'kick'];
  for (const how of attempts) {
    try {
      if (how === 'strip' && member) { await member.roles.set([], 'Anti-nuke'); result = 'αφαιρέθηκαν όλοι οι ρόλοι'; break; }
      if (how === 'kick' && member) { await member.kick(`Anti-nuke: ${key}`); result = 'αποβλήθηκε'; break; }
      if (how === 'ban') { await guild.members.ban(uid, { reason: `Anti-nuke: ${key}` }); result = 'αποκλείστηκε'; break; }
    } catch { /* try next */ }
  }

  // 2) clean up / restore
  let cleaned = 0;
  let restored = 0;
  if (cfg.cleanupCreated) {
    for (const c of created.get(uid) ?? []) {
      try {
        if (c.type === 'channel') await guild.channels.delete(c.id, 'Anti-nuke cleanup');
        else await guild.roles.delete(c.id, 'Anti-nuke cleanup');
        cleaned++;
      } catch { /* ignore */ }
    }
    created.delete(uid);
  }
  if (cfg.restoreChannels) restored = await restoreChannels(guild, deleted.get(uid) ?? []);
  deleted.delete(uid);

  // 3) alert
  await sec.logSec(guild, {
    color: 0xc0392b, title: '🚨 ANTI-NUKE',
    description: `Ο/Η <@${uid}> έκανε μαζικές καταστροφικές ενέργειες (**${key}** ×${count}).`,
    fields: [
      { name: 'Τιμωρία', value: result ?? '⚠️ ΔΕΝ ΜΠΟΡΕΣΑ να τιμωρήσω (ο ρόλος του είναι πάνω από τον δικό μου) – ενεργήστε ΑΜΕΣΑ', inline: false },
      { name: 'Καθαρίστηκαν', value: String(cleaned), inline: true },
      { name: 'Κανάλια που επανήλθαν', value: String(restored), inline: true },
    ],
  });
  try {
    const owner = await guild.fetchOwner();
    await owner.send(`🚨 **ANTI-NUKE** στον ${guild.name}: ο χρήστης <@${uid}> (${uid}) έκανε ${key} ×${count}. Τιμωρία: ${result ?? 'ΑΠΕΤΥΧΕ'}.`).catch(() => {});
  } catch { /* ignore */ }
}

const KEYS = {
  [A.ChannelDelete]: 'channelDelete', [A.ChannelCreate]: 'channelCreate',
  [A.RoleDelete]: 'roleDelete', [A.RoleCreate]: 'roleCreate',
  [A.MemberBanAdd]: 'ban', [A.MemberKick]: 'kick', [A.MemberPrune]: 'prune',
  [A.WebhookCreate]: 'webhookCreate', [A.EmojiDelete]: 'emojiDelete',
};

function register(client) {
  client.once(Events.ClientReady, () => {
    for (const g of client.guilds.cache.values()) for (const c of g.channels.cache.values()) snapshot(c);
  });
  client.on(Events.ChannelCreate, snapshot);
  client.on(Events.ChannelUpdate, (_o, n) => snapshot(n));

  client.on(Events.GuildAuditLogEntryCreate, async (entry, guild) => {
    try {
      if (!sec.moduleOn('antiNuke')) return;
      const uid = entry.executorId;
      if (!uid || sec.trusted(guild, uid)) return;

      // Unauthorised bot → kick the bot immediately
      if (entry.action === A.BotAdd) {
        const bot = await guild.members.fetch(entry.targetId).catch(() => null);
        if (bot) await bot.kick('Anti-nuke: μη εξουσιοδοτημένο bot').catch(() => {});
        await sec.logSec(guild, { color: 0xc0392b, title: '🚨 ANTI-NUKE • bot', description: `Ο/Η <@${uid}> πρόσθεσε το bot <@${entry.targetId}> — αποβλήθηκε. Μόνο ο ιδιοκτήτης/trusted μπορούν να προσθέτουν bots.` });
        return;
      }

      const key = KEYS[entry.action];
      if (!key) return;
      if (key === 'channelCreate') push(created, uid, { type: 'channel', id: entry.targetId });
      if (key === 'roleCreate') push(created, uid, { type: 'role', id: entry.targetId });
      if (key === 'channelDelete' && snaps.has(entry.targetId)) push(deleted, uid, { snap: snaps.get(entry.targetId) });

      const count = bump(uid, key);
      if (count >= sec.nukeLimit(key)) await nuke(guild, uid, key, count);
    } catch (e) {
      console.error('Anti-nuke:', e.message);
    }
  });

  // Dangerous permissions granted to a role → revert immediately
  client.on(Events.GuildRoleUpdate, async (oldR, newR) => {
    try {
      if (!sec.moduleOn('antiNuke')) return;
      const gained = DANGEROUS.filter((p) => newR.permissions.has(p) && !oldR.permissions.has(p));
      if (!gained.length) return;
      const logs = await newR.guild.fetchAuditLogs({ type: A.RoleUpdate, limit: 6 }).catch(() => null);
      const entry = logs?.entries.find((e) => e.targetId === newR.id && Date.now() - e.createdTimestamp < 15000);
      const uid = entry?.executorId;
      if (!uid || sec.trusted(newR.guild, uid)) return;
      await newR.setPermissions(oldR.permissions, 'Anti-nuke: επικίνδυνα δικαιώματα').catch(() => {});
      await sec.logSec(newR.guild, { color: 0xc0392b, title: '🚨 ANTI-NUKE • δικαιώματα', description: `Ο/Η <@${uid}> έδωσε επικίνδυνα δικαιώματα στον ρόλο **${newR.name}**. Η αλλαγή **αναιρέθηκε**.` });
      const count = bump(uid, 'permGrant');
      if (count >= sec.nukeLimit('permGrant')) await nuke(newR.guild, uid, 'permGrant', count);
    } catch (e) {
      console.error('Anti-nuke perms:', e.message);
    }
  });
}

module.exports = { register };
