// Καταγραφές διακομιστή: μηνύματα, ρόλοι μελών, αποκλεισμοί, κανάλια, ρόλοι, φωνητικά
const { Events, ChannelType } = require('discord.js');
const db = require('../utils/db');
const h = require('../utils/helpers');

const send = (guild, key, embed) => h.sendTo(guild, key, { embeds: [embed] });
const isLogChannel = (id) =>
  ['msgLog', 'memberLog', 'modLog', 'serverLog', 'ticketLog'].some((k) => db.get().channels[k] === id);

function register(client) {
  client.on(Events.MessageDelete, async (m) => {
    try {
      if (!m.guild || m.author?.bot || isLogChannel(m.channelId)) return;
      if (db.get().tickets[m.channelId]) return;
      const e = h.baseEmbed().setColor(0xe74c3c).setTitle('🗑️ Διαγραφή μηνύματος').addFields(
        { name: 'Κανάλι', value: `<#${m.channelId}>`, inline: true },
        { name: 'Συγγραφέας', value: m.author ? `${m.author} (${m.author.tag})` : 'Άγνωστος', inline: true },
        { name: 'Περιεχόμενο', value: m.content ? h.cut(m.content, 1000) : '*Άγνωστο (το μήνυμα δεν ήταν στη μνήμη)*' },
      );
      if (m.attachments?.size) e.addFields({ name: 'Συνημμένα', value: String(m.attachments.size), inline: true });
      await send(m.guild, 'msgLog', e);
    } catch (err) { console.error('MessageDelete:', err.message); }
  });

  client.on(Events.MessageUpdate, async (oldM, newM) => {
    try {
      if (!newM.guild || newM.author?.bot || isLogChannel(newM.channelId)) return;
      if (oldM.content === newM.content || !newM.content) return;
      const e = h.baseEmbed().setColor(0xf1c40f).setTitle('✏️ Επεξεργασία μηνύματος').addFields(
        { name: 'Κανάλι', value: `<#${newM.channelId}> • [Μετάβαση](${newM.url})`, inline: true },
        { name: 'Συγγραφέας', value: `${newM.author} (${newM.author?.tag})`, inline: true },
        { name: 'Πριν', value: oldM.content ? h.cut(oldM.content, 1000) : '*Άγνωστο*' },
        { name: 'Μετά', value: h.cut(newM.content, 1000) },
      );
      await send(newM.guild, 'msgLog', e);
    } catch (err) { console.error('MessageUpdate:', err.message); }
  });

  client.on(Events.GuildMemberUpdate, async (oldM, newM) => {
    try {
      if (oldM.partial) return;
      const added = newM.roles.cache.filter((r) => !oldM.roles.cache.has(r.id));
      const removed = oldM.roles.cache.filter((r) => !newM.roles.cache.has(r.id));
      if (added.size || removed.size) {
        const e = h.baseEmbed().setColor(0x3498db).setTitle('🎭 Αλλαγή ρόλων').setDescription(`${newM} (${newM.user.tag})`);
        if (added.size) e.addFields({ name: '➕ Προστέθηκαν', value: added.map((r) => r.name).join(', ') });
        if (removed.size) e.addFields({ name: '➖ Αφαιρέθηκαν', value: removed.map((r) => r.name).join(', ') });
        await send(newM.guild, 'memberLog', e);
      }
      if (oldM.nickname !== newM.nickname) {
        await send(newM.guild, 'memberLog', h.baseEmbed().setColor(0x3498db).setTitle('📝 Αλλαγή ψευδωνύμου')
          .setDescription(`${newM} (${newM.user.tag})`)
          .addFields(
            { name: 'Πριν', value: oldM.nickname ?? '—', inline: true },
            { name: 'Μετά', value: newM.nickname ?? '—', inline: true },
          ));
      }
    } catch (err) { console.error('GuildMemberUpdate:', err.message); }
  });

  client.on(Events.GuildBanAdd, async (ban) => {
    await send(ban.guild, 'modLog', h.baseEmbed().setColor(0xc0392b).setTitle('🔨 Αποκλεισμός')
      .setDescription(`${ban.user} (${ban.user.tag})`)
      .addFields({ name: 'Λόγος', value: ban.reason ?? 'Δεν δόθηκε' })).catch(() => {});
  });
  client.on(Events.GuildBanRemove, async (ban) => {
    await send(ban.guild, 'modLog', h.baseEmbed().setColor(0x2ecc71).setTitle('🔓 Άρση αποκλεισμού')
      .setDescription(`${ban.user} (${ban.user.tag})`)).catch(() => {});
  });

  const chType = (c) => (c.type === ChannelType.GuildCategory ? 'κατηγορία' : c.isVoiceBased?.() ? 'φωνητικό κανάλι' : 'κανάλι');
  client.on(Events.ChannelCreate, (c) => {
    if (c.guild && !db.get().tickets[c.id]) send(c.guild, 'serverLog', h.baseEmbed().setColor(0x2ecc71).setTitle(`➕ Νέο ${chType(c)}`).setDescription(`**${c.name}**`)).catch(() => {});
  });
  client.on(Events.ChannelDelete, (c) => {
    if (c.guild && !db.get().tickets[c.id]) send(c.guild, 'serverLog', h.baseEmbed().setColor(0xe74c3c).setTitle(`➖ Διαγραφή: ${chType(c)}`).setDescription(`**${c.name}**`)).catch(() => {});
  });
  client.on(Events.GuildRoleCreate, (r) =>
    send(r.guild, 'serverLog', h.baseEmbed().setColor(0x2ecc71).setTitle('➕ Νέος ρόλος').setDescription(`**${r.name}**`)).catch(() => {}));
  client.on(Events.GuildRoleDelete, (r) =>
    send(r.guild, 'serverLog', h.baseEmbed().setColor(0xe74c3c).setTitle('➖ Διαγραφή ρόλου').setDescription(`**${r.name}**`)).catch(() => {}));

  client.on(Events.VoiceStateUpdate, async (oldS, newS) => {
    try {
      const m = newS.member;
      if (!m || m.user.bot || oldS.channelId === newS.channelId) return;
      if (h.voiceInfo(oldS.channel) || h.voiceInfo(newS.channel)) return; // duty voice → logged in the duty log
      let text;
      if (!oldS.channelId) text = `🔊 Μπήκε στο **${newS.channel.name}**`;
      else if (!newS.channelId) text = `🔇 Βγήκε από το **${oldS.channel.name}**`;
      else text = `🔁 Μετακινήθηκε: **${oldS.channel.name}** → **${newS.channel.name}**`;
      await send(newS.guild, 'serverLog', h.baseEmbed().setColor(0x9b59b6).setDescription(`${m} ${text}`));
    } catch (err) { console.error('VoiceStateUpdate:', err.message); }
  });
}

module.exports = { register };
