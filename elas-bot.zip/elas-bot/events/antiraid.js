// Anti-raid: join-flood detection and optional minimum account age.
const { Events } = require('discord.js');
const config = require('../config');
const h = require('../utils/helpers');
const sec = require('../utils/security');
const raid = require('../utils/raid');
const db = require('../utils/db');

const joins = []; // { id, at }

function register(client) {
  client.once(Events.ClientReady, () => raid.resume(client));

  client.on(Events.GuildMemberAdd, async (member) => {
    try {
      if (member.user.bot) return;
      const cfg = config.security.antiRaid;
      const now = Date.now();
      const ageDays = (now - member.user.createdTimestamp) / 86400000;

      // 1) account age gate (always on during raid mode, for accounts under 7 days)
      const raidOn = db.get().security.raid.active;
      const minDays = raidOn ? Math.max(cfg.minAccountAgeDays, 7) : cfg.minAccountAgeDays;
      if ((sec.moduleOn('accountAge') || raidOn) && ageDays < minDays && !sec.trusted(member.guild, member.id)) {
        await h.dm(member.user, { content: `🚫 Ο λογαριασμός σου είναι πολύ νέος για τον **${member.guild.name}** (ελάχιστο ${minDays} ημέρες). Δοκίμασε ξανά αργότερα.` });
        await member.kick('Anti-raid: νέος λογαριασμός').catch(() => {});
        await sec.logSec(member.guild, {
          color: 0xe67e22, title: '🛡️ Anti-raid • νέος λογαριασμός',
          description: `${member.user.tag} αποβλήθηκε (λογαριασμός ${ageDays.toFixed(1)} ημερών).`,
        });
        return;
      }

      // 2) join flood
      if (!sec.moduleOn('antiRaid')) return;
      joins.push({ id: member.id, at: now });
      while (joins.length && now - joins[0].at > cfg.seconds * 1000) joins.shift();
      if (joins.length >= cfg.joins && !raidOn) {
        const victims = [];
        for (const j of joins) victims.push(member.guild.members.cache.get(j.id));
        await raid.startRaid(member.guild, `${joins.length} νέα μέλη σε ${cfg.seconds} δευτερόλεπτα`, victims);
        joins.length = 0;
      }
    } catch (e) {
      console.error('Anti-raid:', e.message);
    }
  });
}

module.exports = { register };
