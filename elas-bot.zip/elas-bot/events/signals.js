// Frees a signal automatically when its owner leaves the server or stops being an officer.
const { Events } = require('discord.js');
const h = require('../utils/helpers');
const sig = require('../utils/signals');

function register(client) {
  client.on(Events.GuildMemberRemove, async (member) => {
    if (sig.release(member.id) != null) await sig.refreshBoards(member.guild);
  });
  client.on(Events.GuildMemberUpdate, async (oldM, newM) => {
    try {
      if (sig.numberOf(newM.id) == null) return;
      if (h.isStaff(newM) || h.isAdmin(newM)) return;
      sig.release(newM.id);
      await sig.clearNickname(newM);
      await sig.refreshBoards(newM.guild);
    } catch (e) { console.error('Signals:', e.message); }
  });
}

module.exports = { register };
