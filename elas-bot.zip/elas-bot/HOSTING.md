# 24/7 λειτουργία του bot

Το bot δουλεύει **μόνο όσο τρέχει το πρόγραμμα** (`node index.js`). Για να είναι πάντα ενεργό χρειάζεσαι έναν υπολογιστή που δεν κλείνει. Διάλεξε ΜΙΑ από τις επιλογές:

| Επιλογή | Κόστος (περίπου) | Δυσκολία | Σχόλιο |
|---|---|---|---|
| **VPS** (προτείνεται) | ~3–5 €/μήνα | μέτρια | Σταθερό, δικό σου, 24/7. |
| **Hosting για Discord bots** (με πάνελ) | ~1–5 €/μήνα | εύκολη | Ανεβάζεις το zip και πατάς Start. |
| **Oracle Cloud Always Free** | δωρεάν | δύσκολη | Δωρεάν VM, αλλά θέλει γνώσεις Linux και η εγγραφή έχει περιορισμούς. |
| **Δικός σου υπολογιστής / Raspberry Pi** | 0 € | εύκολη | Δουλεύει μόνο όσο είναι ανοιχτός και συνδεδεμένος. |

❌ **Μην χρησιμοποιήσεις** δωρεάν υπηρεσίες που “κοιμίζουν” τις εφαρμογές (Replit, Glitch, δωρεάν πλάνα Render κ.λπ.) ούτε κοινό web hosting (cPanel): το bot κρατά μόνιμη σύνδεση με το Discord και αυτά την κόβουν.

---
## 1. VPS (Ubuntu 22.04 / 24.04) με pm2
Χρειάζεσαι 1 CPU και 1 GB RAM. Μετά την αγορά θα πάρεις μια IP και κωδικό.

```bash
# 1) σύνδεση (από τον υπολογιστή σου)
ssh root@IP_ΤΟΥ_SERVER

# 2) εγκατάσταση Node.js 20 + γραμματοσειρές για ελληνικά στο banner + pm2
apt update && apt install -y curl unzip
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs fonts-dejavu-core fonts-noto-core
npm install -g pm2

# 3) (από τον υπολογιστή σου, σε ΑΛΛΟ τερματικό) ανέβασε το zip
scp elas-lockdown-bot-v3.3.zip root@IP_ΤΟΥ_SERVER:/root/

# 4) πίσω στον server: αποσυμπίεση και ρύθμιση
unzip /root/elas-lockdown-bot-v3.3.zip -d /opt/
cd /opt/elas-bot
cp .env.example .env
nano .env                 # βάλε DISCORD_TOKEN, CLIENT_ID, GUILD_ID  (Ctrl+O, Enter, Ctrl+X)
npm install --omit=dev
npm run deploy            # καταχώρηση εντολών (μία φορά)

# 5) εκκίνηση 24/7
pm2 start ecosystem.config.js
pm2 save
pm2 startup               # θα σου εμφανίσει μια εντολή: αντίγραψέ την και τρέξ’ την
```
Έτσι το bot **ξεκινά ξανά αυτόματα** αν κρασάρει ή αν γίνει επανεκκίνηση του server.

Χρήσιμες εντολές: `pm2 status` • `pm2 logs elas-bot` • `pm2 restart elas-bot` • `pm2 stop elas-bot`

**Ενημέρωση σε νέα έκδοση:** ανέβασε το νέο zip, αντικατάστησε τα αρχεία **εκτός** από τον φάκελο `data/` και το `.env`, τρέξε `npm install --omit=dev`, `npm run deploy`, `pm2 restart elas-bot`.

**Αντίγραφα ασφαλείας** (όλα τα δεδομένα είναι στο `data/data.json`):
```bash
crontab -e
# πρόσθεσε τη γραμμή:
0 4 * * * /opt/elas-bot/scripts/backup.sh
```
Κρατά τα τελευταία 14 καθημερινά αντίγραφα στον φάκελο `backups/`. Κατέβαζε κάθε τόσο ένα αντίγραφο και στον υπολογιστή σου.

**Ασφάλεια:** μην μοιράζεσαι ποτέ το `.env`/token. Για πιο ασφαλή λειτουργία φτιάξε χρήστη (`adduser bot`) και τρέξε το pm2 από εκεί αντί για root.

---
## 2. Docker
```bash
cd /opt/elas-bot          # μέσα στον φάκελο με το .env
docker compose up -d --build
docker compose logs -f    # δες τα logs
```
Το `restart: unless-stopped` το ξανασηκώνει μόνο του, και ο φάκελος `data/` μένει έξω από το container.

---
## 3. Hosting για Discord bots (με πάνελ)
1. Πάρε πλάνο Node.js από υπηρεσία φιλοξενίας Discord bots και ανέβασε τον φάκελο (ή το zip).
2. Εντολή εκκίνησης: `npm install --omit=dev && node index.js` (ή `npm start`).
3. Πρόσθεσε τις μεταβλητές `DISCORD_TOKEN`, `CLIENT_ID`, `GUILD_ID` (ή ανέβασε το `.env`).
4. Τρέξε μία φορά `npm run deploy` από την κονσόλα του πάνελ.
5. ⚠️ Βεβαιώσου ότι ο φάκελος `data/` είναι **μόνιμος** (persistent). Αν ο δίσκος σβήνεται σε κάθε επανεκκίνηση/deploy, θα χάνονται ώρες υπηρεσίας, αιτήσεις και ρυθμίσεις.

---
## 4. Δικός σου υπολογιστής / Raspberry Pi
Εγκατάστησε Node.js 18+, τρέξε `npm install`, `npm run deploy`, και μετά `pm2 start ecosystem.config.js`, `pm2 save`. Σε Linux: `pm2 startup` για αυτόματη εκκίνηση. Σε Windows το πιο απλό είναι **Task Scheduler** με εκκίνηση στο login. Θυμήσου: αν κοπεί το ρεύμα ή το internet, το bot πέφτει.

---
## ⚠️ Να θυμάσαι
- **Ένα μόνο αντίγραφο τη φορά:** μην τρέχεις το bot ταυτόχρονα στον υπολογιστή σου και στον server — θα απαντά δύο φορές σε όλα. Σταμάτα το ένα πριν ξεκινήσεις το άλλο.
- Όταν το bot είναι εκτός, τα κουμπιά και οι εντολές δείχνουν “η εφαρμογή δεν απάντησε”. Μετά την εκκίνηση συγχρονίζεται μόνο του (υπηρεσία, φωνητικά, ενεργά giveaways).
- Ο χρόνος σε κλήση που τρέχει την ώρα της πτώσης χάνεται το πολύ για ~1 λεπτό (αποθηκεύεται κάθε λεπτό).
- Ο δίσκος: το bot χρειάζεται ελάχιστο χώρο (το `data.json` είναι μερικά KB έως λίγα MB).
