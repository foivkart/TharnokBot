// pm2 process file: keeps the bot running 24/7, restarts it if it crashes, starts it again after a reboot
module.exports = {
  apps: [{
    name: 'elas-bot',
    script: 'index.js',
    autorestart: true,
    max_restarts: 50,
    restart_delay: 5000,
    max_memory_restart: '500M',
    env: { NODE_ENV: 'production' },
  }],
};
