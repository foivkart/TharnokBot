# 🛡️ Bot ΕΛ.ΑΣ. – Lockdown (v3)

Discord bot για τον server της Ελληνικής Αστυνομίας του **Lockdown**.
Οι εντολές είναι στα **αγγλικά**, τα μηνύματα του bot στα **ελληνικά**.

## 24/7 λειτουργία
Δες το αρχείο **`HOSTING.md`** (VPS με pm2, Docker, hosting για Discord bots, Raspberry Pi). Στο φάκελο υπάρχουν έτοιμα τα `ecosystem.config.js` (pm2), `Dockerfile`, `docker-compose.yml` και `scripts/backup.sh` (καθημερινό αντίγραφο του `data.json`).

## 🧭 Έχεις ήδη φτιαγμένο server; Χρησιμοποίησε `/config` (όχι `/setup`)
Το bot **δεν δημιουργεί τίποτα μόνο του**. Του δείχνεις εσύ ποιο κανάλι και ποιος ρόλος κάνει τι. Όλα αλλάζουν οποιαδήποτε στιγμή με `/config` (μόνο διαχειριστές), και το `/config view` δείχνει τι είναι ορισμένο και τι λείπει. Το `/setup` είναι προαιρετικό (για καινούριους servers) και ζητά επιβεβαίωση.

**Κανάλια** — `/config channel feature:<λειτουργία> channel:#κανάλι` (η λειτουργία συμπληρώνεται με αναζήτηση):

| Λειτουργία | Τι είναι | Δικό σου κανάλι (παράδειγμα) |
|---|---|---|
| `welcome` | καλωσόρισμα + banner | `👋 welcome` |
| `rules` | κανόνες | `κανονισμοί-ελληνικης-αστυνομίας` |
| `announcements` | προεπιλεγμένο κανάλι ανακοινώσεων | `ελας-announcements` |
| `reports` · `intel` | αναφορές συλλήψεων/συμβάντων · πληροφορίες στρατού | `officer-report` |
| `leaves` | αιτήματα άδειας (`/loa`) | `police-officer-absences` |
| `appReview` · `appAccepted` · `appDenied` | αιτήσεις σε αναμονή · εγκεκριμένες · απορριφθείσες | `applications-pending` · `applications-accepted` · `applications-denied` |
| `ticketLog` · `modLog` · `securityLog` | logs αιτημάτων · διαχείρισης · ασφάλειας | `ticket-logs` · `moderation-logs` · `security-logs` |
| `logs` | **γενικό fallback** για όλα τα υπόλοιπα logs (μέλη, μηνύματα, διακομιστής, υπηρεσία...) | `logs` |
| `dutyLog`, `staffLog`, `memberLog`, `msgLog`, `serverLog`, `signals`, `bolo`, `training`, `events`, `status`, `suggestions`, `complaints` | προαιρετικά ειδικά κανάλια | όπως θέλεις |

Δύο λειτουργίες μπορούν να δείχνουν στο **ίδιο** κανάλι. Αν δεν οριστεί ειδικό log, χρησιμοποιείται το `logs` (και το `securityLog` → `modLog` → `logs`).

**Ρόλοι**
1. `/config rank_range lowest:@[09]Δόκιμος highest:@Αρχηγός` → όλοι οι ρόλοι ανάμεσα (με γράμματα στο όνομα) γίνονται βαθμοί, με σειρά από τη θέση τους στη λίστα ρόλων. Αν μπει ρόλος που δεν είναι βαθμός (π.χ. ομάδα), αφαίρεσέ τον: `/config rank role:@ρόλος enabled:False`.
2. `/config command_from role:@[04]Αστυνόμος Β΄` → από αυτόν τον βαθμό και πάνω = Διοίκηση. Επιπλέον ρόλοι Διοίκησης: `/config command_role role:@Διοίκηση`.
3. `/config officer_role role:@🚨| Ελληνική αστυνομία` → ο γενικός ρόλος αστυνομίας μετράει ως αστυνομικός και δίνεται στους εγκεκριμένους.
4. Όταν φτιάξεις τους ρόλους υπηρεσίας: `/config role key:On Duty role:@On Duty` και `key:Off Duty role:@Off Duty`.
5. `/config role` για: ρόλο αναμονής συνέντευξης (`Αναμονή για Interview`), ρόλο απόρριψης (`Interview Denied`), ρόλο blacklist (`Black Listed`), ρόλο ειδοποιήσεων αποστολών.
6. **Μονάδες** (ΕΚΑΜ, ΟΠΚΕ, Υ.Ε.Μ.Ε.Α., Ε.Δ.Ε.): `/config unit role:@ΕΚΑΜ code:07` → όποιος έχει τον ρόλο παίρνει αυτόματα `[07-αριθμός]` στα σήματα. Στατιστικά: `/unit list`, `/unit roster`, `/unit leaderboard`.
7. Autoroles νέων μελών: `/config autorole role:@Civilian`. Ρόλοι με κουμπιά: `/config selfrole role:@ρόλος emoji:🔔`.

**Φωνητικά που μετράνε για υπηρεσία** — `/config voice channel:<φωνητικό ή ΚΑΤΗΓΟΡΙΑ>`: αν διαλέξεις **κατηγορία** (π.χ. «ΑΔ», «ΟΠΚΕ», «ΕΚΑΜ», «Εκπαίδευση», «Κέντρο»), μετράνε όλα τα φωνητικά μέσα της. Με `command_only:True` μένουν μόνο η Διοίκηση. Το bot αποσυνδέει όποιον μπει σε αυτά χωρίς να είναι **On Duty**, οπότε δεν χρειάζεται να πειράξεις δικαιώματα.

**Κατηγορίες & ρυθμίσεις**
- `/config category kind:Tickets category:<κατηγορία>` (εκεί φτιάχνονται τα νέα tickets) και `kind:Interviews` για τα κανάλια συνέντευξης.
- `/config ticket_role` → ποιοι ρόλοι βλέπουν τα tickets (αλλιώς όλοι οι αστυνομικοί).
- `/config setting` → εβδομαδιαίος στόχος λεπτών, αυτόματο κλείσιμο tickets, αναμονή μετά από απόρριψη, μέγιστα ανοιχτά tickets, κωδικός μονάδας σημάτων.

**Πάνελ και ανακοινώσεις όπου θέλεις:** `/duty panel`, `/ticket panel`, `/application panel`, `/roles panel`, `/signal panel`, `/welcome rules` έχουν επιλογή `channel`. Το `/announce` έχει `channel` (και `ping_role`), και το ίδιο ισχύει για `/event create`, `/training schedule`, `/bolo add`, `/threat set` και `/poll`.

## Banners πάνελ (ένα διαφορετικό για κάθε πάνελ)
Φτιάχτηκαν από τα εικονίδια του server (Welcome emblem, LOCKDOWN, έμβλημα ΕΛ.ΑΣ.) με μεταλλική κορδέλα, αγκαθωτό σύρμα και αίμα, σε διαφορετικό χρώμα το καθένα:

| Πάνελ | Χρώμα | Αρχείο |
|---|---|---|
| Υπηρεσία (On/Off Duty) | 🔵 μπλε | `assets/banners/duty.png` |
| Αιτήματα (tickets) | 🟠 πορτοκαλί | `assets/banners/tickets.png` |
| Αιτήσεις ένταξης | 🔴 κόκκινο | `assets/banners/applications.png` |
| Κανόνες | ⚫ ατσάλι + κίτρινες ρίγες | `assets/banners/rules.png` |
| Ρόλοι | 🟣 μοβ | `assets/banners/roles.png` |
| Σήματα | 🩵 γαλάζιο | `assets/banners/signals.png` |

Αν θες δικά σου, αντικατέστησε το PNG (1200×400, ίδιο όνομα). Για να ξαναδημοσιευτούν τα πάνελ με νέα banners: `/setup repost_panels:True`. Το banner καλωσορίσματος είναι το `assets/banner.png`.

## Πίνακας σημάτων (callsigns) 📻
Δύο πίνακες στο `#σήματα`: **001–100** και **101–200**. Κάθε πίνακας δείχνει πλέγμα αριθμών (■ = κατειλημμένο, ✕ = αποσυρμένο), μπάρα πληρότητας και λίστα “Ανατεθειμένα”.
- Ο αστυνομικός πατά **Επιλογή σήματος**, γράφει τον αριθμό και (προαιρετικά) τον κωδικό μονάδας **xx**. Το ψευδώνυμό του γίνεται **`[xx-αριθμός] Όνομα`** (π.χ. `[05-09] Νίκος`, `[10-116] Σπύρος`). Ένα σήμα ανά αστυνομικό· αν διαλέξει άλλο, το παλιό ελευθερώνεται.
- **Αποδέσμευση του δικού μου** ελευθερώνει το σήμα και καθαρίζει το ψευδώνυμο.
- Η Διοίκηση: `/signal assign|release|retire|unretire|refresh`. Αν κάποιος φύγει από τον server ή χάσει τον βαθμό, το σήμα ελευθερώνεται αυτόματα.
- Τα σήματα φαίνονται στο `/roster`, `/profile` και `/info user`.

## Σύστημα υπηρεσίας (On Duty / Off Duty)
- Δύο ρόλοι: **On Duty** και **Off Duty**. Κάθε αστυνομικός ξεκινά Off Duty.
- Πατάει **On Duty** στο πάνελ (`#ανάληψη-υπηρεσίας`) ή με `/duty on`.
- Τα **φωνητικά κανάλια της ΕΛ.ΑΣ.** (Περιπολία 1/2, Αποστολές, Διοίκηση) είναι κλειδωμένα: μόνο όσοι είναι **On Duty** μπορούν να μπουν. Αν μπει κάποιος χωρίς On Duty, το bot τον αποσυνδέει.
- Ο χρόνος υπηρεσίας μετράει **ΜΟΝΟ όσο ο αστυνομικός είναι On Duty ΚΑΙ μέσα σε φωνητική κλήση** (το “Αναμονή (Off Duty)” δεν μετράει).
- Με **Off Duty** ο αστυνομικός αποσυνδέεται αυτόματα από την κλήση και παίρνει πίσω τον ρόλο Off Duty.
- `/duty time` (εβδομαδιαίος στόχος 120′ – αλλάζει στο `config.js`), `/duty leaderboard`, `/duty active`.
- Όλα καταγράφονται στο `#καταγραφή-υπηρεσίας`.

## Ασφάλεια
| Προστασία | Τι κάνει |
|---|---|
| **Anti-nuke** | Ανιχνεύει μαζικές διαγραφές/δημιουργίες καναλιών και ρόλων, μαζικά ban/kick, webhooks, prune. Κάνει **ban** στον δράστη, **επαναφέρει τα κανάλια** που διαγράφηκαν, διαγράφει ό,τι έφτιαξε, διώχνει **μη εξουσιοδοτημένα bots** και **αναιρεί επικίνδυνα δικαιώματα** (Administrator κ.λπ.) σε ρόλους. Ειδοποιεί τον ιδιοκτήτη με DM. |
| **Anti-raid** | Αν μπουν πολλά μέλη μαζί → **Raid mode**: σταματά τις προσκλήσεις, ανεβάζει το verification, διώχνει τους νεοεισερχόμενους, λήγει μόνο του. Προαιρετικό ελάχιστο όριο ηλικίας λογαριασμού. |
| **Φίλτρο βρισιών** | Ελληνικά, **Greeklish** και ~20 γλώσσες (αγγλικά, ισπανικά, γαλλικά, γερμανικά, ιταλικά, πορτογαλικά, ολλανδικά, ρωσικά (και με λατινικά), τουρκικά, αλβανικά, σερβικά, βουλγαρικά, ρουμανικά, πολωνικά, σουηδικά, αραβικά, χίντι, κινέζικα, κορεάτικα, ιαπωνικά). Πιάνει leetspeak (`sh1t`, `b!tch`), τεντωμένα γράμματα (`fuuuck`), κενά/τελείες (`f u c k`, `f.u.c.k`), τονισμένα/κεφαλαία και μπερδεμένα αλφάβητα. Δεν πιάνει αθώες λέξεις (π.χ. “class”, “γάμος”). |
| **AutoMod chat** | Invite links, επικίνδυνα links/scam, mass mentions, @everyone, ΚΕΦΑΛΑΙΑ, emoji spam, glitch text, flood, επαναλαμβανόμενα μηνύματα, κακά ονόματα/nicknames. |
| **Κλίμακα ποινών** | Κάθε παράβαση διαγράφει το μήνυμα και δίνει strikes: 1 → προειδοποίηση • 3 → timeout 10′ • 5 → timeout 1ω • 7 → timeout 24ω • 9 → kick • 12 → ban. Τα strikes λήγουν μετά από 24 ώρες. Οι ύβρεις/ρατσισμός μετράνε διπλά. |
| **Native AutoMod Discord** | `/security automod_setup` φτιάχνει τους κανόνες του ίδιου του Discord (Profanity / Sexual / Slurs, mention spam, spam) που δουλεύουν ακόμα κι αν το bot είναι offline. |

**Για “κάθε γλώσσα”:** καμία λίστα δεν μπορεί να καλύψει κάθε γλώσσα του κόσμου. Το bot έχει ενσωματωμένες τις παραπάνω γλώσσες **και** χρησιμοποιεί τις μεγάλες λίστες του Discord. Για ό,τι λείπει: `/security word_add`. Δοκιμή: `/security word_test`. Για ψευδώς θετικά: `/security word_allow`.

Οι **διαχειριστές** δεν ελέγχονται από το φίλτρο· η **Διοίκηση** δεν ελέγχεται για spam/links, αλλά ελέγχεται για βρισιές.

### Εντολές διαχείρισης (`/mod`)
`timeout` • `untimeout` • `kick` • `ban` (με διαγραφή μηνυμάτων 0-7 ημερών) • `unban` • `clear` (μαζική διαγραφή, προαιρετικά μόνο ενός μέλους) • `purge` (διαγραφή μηνυμάτων μέλους από ΟΛΑ τα κανάλια) • `slowmode` • `lock` • `unlock`. Όλα καταγράφονται στο `#καταγραφή-διαχείρισης`.

### Εντολές ασφάλειας (`/security`)
`status` • `toggle` (ανοιγοκλείσιμο κάθε module) • `word_add/remove/allow/list/test` • `strikes` • `strikes_clear` • `trust_add/remove/list` • `raidmode` • `automod_setup`

## Όλες οι υπόλοιπες λειτουργίες
- **Welcome banner** με τον Welcome emblem + το λογότυπο LOCKDOWN και το avatar/όνομα του νέου μέλους (`/welcome test`), **autoroles** (`Πολίτης`), πάνελ ρόλων ειδοποιήσεων (`/roles panel`), κανόνες (`/welcome rules`).
- **Προσωπικό:** `/roster`, `/promote`, `/demote`, `/loa` (άδειες), `/discipline warn|history|remove`, `/profile`.
- **Αιτήσεις & συνεντεύξεις:** `/application panel|status|toggle`. Όταν πατηθεί **Συνέντευξη**, δημιουργείται **ιδιωτικό κανάλι κειμένου + φωνητικό** για τον υποψήφιο και τη Διοίκηση. Η **Έγκριση** δίνει αυτόματα τον πρώτο βαθμό + Off Duty και σβήνει τα κανάλια.
- **Αιτήματα (tickets):** `/ticket panel|add|remove|close` – κατηγορίες, ανάληψη, **αντίγραφο συζήτησης** στα logs.
- **Καταγγελίες μελών:** `/complaint member reason [evidence]`.
- **Επιχειρήσεις:** `/event create|list` (αποστολές με κουμπιά), `/report` (σύλληψη, συμβάν, περιπολία, πληροφορίες στρατού), `/threat view|set`, `/announce`, `/poll`, `/suggest`, `/stats`.
- **Logs:** υπηρεσία, αιτήματα, μέλη (είσοδοι/έξοδοι/ρόλοι/nicknames), μηνύματα (διαγραφές/επεξεργασίες), διαχείριση, διακομιστής (κανάλια/ρόλοι/φωνητικά).

## Επιπλέον εντολές (v3.1)
- **Υπηρεσία:** `/duty inactive` (κάτω από τον εβδομαδιαίο στόχο), `adjust` (προσθήκη/αφαίρεση λεπτών), `forceoff`, `resetweek`.
- **Tickets:** `priority` (🟢🟡🟠🔴 στο όνομα του καναλιού), `claim/unclaim/transfer`, `rename`, `list`, `transcript`, `stats`, `blacklist_add/remove`, **αυτόματο κλείσιμο αδρανών αιτημάτων** (72 ώρες, αλλάζει στο `config.js`).
- **Αιτήσεις:** `list`, `view`, `interview`, `accept`, `reject`, `note` (σημειώσεις Διοίκησης), `schedule` (ραντεβού συνέντευξης με DM), `stats`, αναμονή 3 ημερών μετά από απόρριψη.
- **Ασφάλεια:** `lockdown` (κλείδωμα όλων των δημόσιων καναλιών), `audit` (τελευταία συμβάντα ασφαλείας), `exempt_channel/exempt_role`, `nuke_limit`, `nuke_punishment`.
- **Διαχείριση:** `quarantine/unquarantine` (αφαιρεί και αποθηκεύει ρόλους + μακρύ timeout), `nick`, `role_add/role_remove`, `vkick`, `note/notes`.
- **Νέες εντολές:** `/bolo` (καταζητούμενοι), `/commend` (έπαινοι), `/training` (εκπαιδεύσεις με εγγραφές), `/say` (μήνυμα ή custom embed), `/info` (user/server/avatar/bot), `/ranks`, `/giveaway`, `/remind`, `/signal`.

---
## Βήμα 1 – Δημιούργησε το bot (Developer Portal)
1. https://discord.com/developers/applications → **New Application**.
2. **General Information** → αντίγραψε το **Application ID** (`CLIENT_ID`).
3. **Bot** → **Reset Token** → αντίγραψέ το (`DISCORD_TOKEN`). Μην το μοιραστείς ποτέ.
4. Στο ίδιο μενού ενεργοποίησε: ✅ **Server Members Intent** και ✅ **Message Content Intent** → Save.
5. **OAuth2 → URL Generator** → scopes **`bot`** + **`applications.commands`** → permission **Administrator** → άνοιξε το link και πρόσθεσε το bot.
6. Discord → Ρυθμίσεις → Για προχωρημένους → **Developer Mode** → δεξί κλικ στον server → **Copy Server ID** (`GUILD_ID`).

## Βήμα 2 – Τρέξε το
Χρειάζεσαι **Node.js 18+**. Αντίγραψε το `.env.example` σε `.env` και βάλε τις 3 τιμές. Μετά:
```
npm install
npm run deploy     # καταχωρεί τις εντολές
npm start
```

## Βήμα 3 – Στήσιμο
1. **Υπάρχων server:** ακολούθησε τον οδηγό `/config` πιο πάνω. (Νέος κενός server: `/setup confirm:True`.)
2. **Σύρε τον ρόλο του bot στην κορυφή** της λίστας ρόλων (απαραίτητο για anti-nuke, ρόλους, moderation).
3. `/security automod_setup` → native AutoMod του Discord.
4. `/promote @χρήστης` για τους πρώτους αστυνομικούς.
5. Αν χρησιμοποιείς άλλα bots (μουσική, κ.λπ.): πρόσθεσέ τα **πριν** ή κάνε `/security trust_add` στον εαυτό σου – το anti-nuke διώχνει bots που προσθέτει μη-trusted χρήστης.

## Σημαντικά
- Ο ιδιοκτήτης του server και το ίδιο το bot είναι πάντα **trusted**. Διαχειριστές **δεν** είναι αυτόματα trusted (αυτό προστατεύει από χακαρισμένο admin λογαριασμό).
- Το anti-nuke επαναφέρει **κανάλια** αλλά όχι διαγραμμένους ρόλους.
- Το bot πρέπει να έχει **ψηλότερο ρόλο** από αυτόν που θέλει να τιμωρήσει. Αν δεν μπορεί, το `#καταγραφή-διαχείρισης` και ένα DM στον ιδιοκτήτη σε ειδοποιούν να δράσεις χειροκίνητα.
- Banner: αν βλέπεις τετραγωνάκια αντί για ελληνικά, βάλε ένα `.ttf` με ελληνικά στο `assets/fonts/`. Δικό σου background: αντικατέστησε το `assets/banner.png` (1200×450, κράτα ελεύθερο το κέντρο).
- Όλα αποθηκεύονται στο `data/data.json` – κράτα αντίγραφο.
- 24/7: VPS ή hosting για Discord bots με εντολή εκκίνησης `npm start` (σε VPS: `pm2 start index.js --name elas-bot`).
