// ─────────────────────────────────────────────────────────────
//  ΕΛ.ΑΣ. LOCKDOWN BOT – SETTINGS
//  Edit anything here, then run /setup in Discord so the bot
//  creates any new roles / channels.
// ─────────────────────────────────────────────────────────────
module.exports = {
  serverName: 'Lockdown',
  department: 'Ελληνική Αστυνομία',
  color: 0x0d5eaf,

  // Ranks, LOWEST → HIGHEST. /setup creates these roles.
  ranks: [
    'Δόκιμος Αστυφύλακας',
    'Αστυφύλακας',
    'Αρχιφύλακας',
    'Ανθυπαστυνόμος',
    'Υπαστυνόμος Β΄',
    'Υπαστυνόμος Α΄',
    'Αστυνόμος Β΄',
    'Αστυνόμος Α΄',
    'Αστυνομικός Υποδιευθυντής',
    'Αστυνομικός Διευθυντής',
    'Ταξίαρχος',
    'Υποστράτηγος',
    'Αντιστράτηγος',
    'Αρχηγός',
  ],

  // This rank and above = "Command staff" (promote, announce, approve applications, see logs...)
  commandFrom: 'Αστυνόμος Β΄',

  // ── DUTY SYSTEM ──────────────────────────────────────────────
  onDutyRole: 'On Duty',
  offDutyRole: 'Off Duty',
  // Only officers who are On Duty can join the duty voice channels.
  // Duty time is counted ONLY while an On Duty officer is inside a counted voice channel.
  weeklyQuotaMinutes: 120, // weekly goal shown in /duty time and /duty leaderboard (0 = off)

  // ── AUTOROLES ────────────────────────────────────────────────
  autoRoles: {
    onJoin: ['Πολίτης'], // given to every new member
    bots: [],            // given to bots
  },
  // Roles members pick themselves with buttons (/roles panel). Max 25.
  selfRoles: [
    { name: 'Ειδοποιήσεις Αποστολών', emoji: '⚔️' },
    { name: 'Ειδοποιήσεις Ανακοινώσεων', emoji: '📢' },
    { name: 'Ειδοποιήσεις Εκδηλώσεων', emoji: '🎉' },
    { name: 'Ειδοποιήσεις Συναγερμού', emoji: '🚨' },
  ],
  eventPingRole: 'Ειδοποιήσεις Αποστολών',

  // ── CATEGORIES & CHANNELS ────────────────────────────────────
  categories: {
    public: '📢 ΕΛ.ΑΣ. | ΔΗΜΟΣΙΑ',
    staff: '🚔 ΕΛ.ΑΣ. | ΠΡΟΣΩΠΙΚΟ',
    command: '🔒 ΕΛ.ΑΣ. | ΔΙΟΙΚΗΣΗ',
    voice: '🔊 ΕΛ.ΑΣ. | ΦΩΝΗΤΙΚΑ',
    tickets: '📩 ΑΙΤΗΜΑΤΑ',
  },
  // access: public = everyone reads | staff = all officers | command = command staff only
  channels: {
    welcome: { name: 'καλωσόρισμα', access: 'public', topic: 'Καλώς ήρθατε στην Ασφαλή Ζώνη' },
    rules: { name: 'κανόνες', access: 'public', topic: 'Οι κανόνες του server' },
    announcements: { name: 'ανακοινώσεις', access: 'public', topic: 'Επίσημες ανακοινώσεις της ΕΛ.ΑΣ.' },
    status: { name: 'κατάσταση-ζώνης', access: 'public', topic: 'Τρέχον επίπεδο απειλής της Ασφαλούς Ζώνης' },
    roles: { name: 'επιλογή-ρόλων', access: 'public', topic: 'Διάλεξε τους ρόλους ειδοποιήσεων που θέλεις' },
    tickets: { name: 'αιτήματα', access: 'public', topic: 'Άνοιξε ιδιωτικό αίτημα προς την ΕΛ.ΑΣ.' },
    applications: { name: 'αιτήσεις-στο-σώμα', access: 'public', topic: 'Θέλεις να γίνεις αστυνομικός; Κάνε αίτηση εδώ' },
    suggestions: { name: 'προτάσεις', access: 'public', topic: 'Προτάσεις των μελών (/suggest)' },

    duty: { name: 'ανάληψη-υπηρεσίας', access: 'staff', topic: 'On Duty / Off Duty' },
    dutyLog: { name: 'καταγραφή-υπηρεσίας', access: 'staff', topic: 'On/Off Duty και διάρκεια φωνητικών κλήσεων' },
    events: { name: 'αποστολές', access: 'staff', topic: 'Αποστολές και εκδηλώσεις εκτός Ασφαλούς Ζώνης' },
    reports: { name: 'αναφορές', access: 'staff', topic: 'Αναφορές συλλήψεων, συμβάντων και περιπολιών' },
    intel: { name: 'πληροφορίες-στρατού', access: 'staff', topic: 'Γιατί ήρθε ο στρατός; Συλλογή πληροφοριών' },
    signals: { name: 'σήματα', access: 'staff', topic: 'Επίλεξε το σήμα (callsign) σου: 01-200' },
    bolo: { name: 'καταζητούμενοι', access: 'staff', topic: 'BOLO – καταζητούμενοι και άτομα προς αναζήτηση' },
    training: { name: 'εκπαιδεύσεις', access: 'staff', topic: 'Προγραμματισμένες εκπαιδεύσεις προσωπικού' },
    staffLog: { name: 'αρχείο-προσωπικού', access: 'staff', topic: 'Προαγωγές, πειθαρχικά και άλλες ενέργειες προσωπικού' },

    appReview: { name: 'έλεγχος-αιτήσεων', access: 'command', topic: 'Αξιολόγηση αιτήσεων υποψηφίων' },
    complaints: { name: 'καταγγελίες', access: 'command', topic: 'Καταγγελίες μελών' },
    leaves: { name: 'άδειες', access: 'command', topic: 'Αιτήματα άδειας προσωπικού' },
    ticketLog: { name: 'καταγραφή-αιτημάτων', access: 'command', topic: 'Αρχείο κλεισμένων αιτημάτων' },
    memberLog: { name: 'καταγραφή-μελών', access: 'command', topic: 'Είσοδοι, έξοδοι, ρόλοι, ψευδώνυμα' },
    msgLog: { name: 'καταγραφή-μηνυμάτων', access: 'command', topic: 'Διαγραμμένα και επεξεργασμένα μηνύματα' },
    modLog: { name: 'καταγραφή-διαχείρισης', access: 'command', topic: 'Αποκλεισμοί, αποβολές, σιγάσεις' },
    serverLog: { name: 'καταγραφή-διακομιστή', access: 'command', topic: 'Αλλαγές καναλιών, ρόλων και φωνητικών' },
    securityLog: { name: 'καταγραφή-ασφάλειας', access: 'command', topic: 'Anti-nuke, anti-raid, AutoMod' },
    appAccepted: { name: 'αιτήσεις-εγκεκριμένες', access: 'command', topic: 'Αποτελέσματα: εγκεκριμένες αιτήσεις' },
    appDenied: { name: 'αιτήσεις-απορριφθείσες', access: 'command', topic: 'Αποτελέσματα: απορριφθείσες αιτήσεις' },
    logs: { name: 'logs', access: 'command', topic: 'Γενικό κανάλι logs (χρησιμοποιείται αν δεν οριστεί ειδικό)' },
  },

  // Duty voice channels (created by /setup). Only On Duty officers can connect.
  //  counted: time is added to duty time | commandOnly: only command staff may stay | open: any officer may join (not counted)
  voiceChannels: [
    { key: 'patrol1', name: '🚔 Περιπολία 1', counted: true },
    { key: 'patrol2', name: '🚔 Περιπολία 2', counted: true },
    { key: 'events', name: '⚔️ Αποστολές', counted: true },
    { key: 'command', name: '🎖️ Διοίκηση', counted: true, commandOnly: true },
    { key: 'lounge', name: '☕ Αναμονή (Off Duty)', counted: false, open: true },
  ],

  // ── SIGNALS / CALLSIGNS ──────────────────────────────────────
  // Two boards (1-100 and 101-200). Officers pick a number with a button; the nickname becomes [xx-NN] Name.
  signals: {
    ranges: [{ from: 1, to: 100 }, { from: 101, to: 200 }],
    defaultUnit: '01',     // the "xx" part when the officer does not type one
    setNickname: true,     // change the nickname to [xx-NN] Name
    color: 0x00a6ff,
  },

  // ── WELCOME ──────────────────────────────────────────────────
  // Variables: {user} {name} {server} {count} {rules} {roles} {tickets} {applications}
  welcome: {
    enabled: true,
    banner: true,
    baseImage: 'assets/banner.png', // 1200x450 – Welcome emblem + LOCKDOWN logo
    bannerTop: 'ΚΑΛΩΣ ΗΡΘΕΣ',
    bannerBottom: 'ΕΛΛΗΝΙΚΗ ΑΣΤΥΝΟΜΙΑ',
    title: '🛡️ Καλώς ήρθες στην Ασφαλή Ζώνη!',
    message:
      'Καλώς ήρθες {user} στο **{server}**! 🇬🇷\n\n' +
      'Είσαι το μέλος **#{count}**. Η Ελληνική Αστυνομία προστατεύει την Ασφαλή Ζώνη — μείνε ασφαλής εκεί έξω.\n\n' +
      '📜 Διάβασε τους κανόνες: {rules}\n' +
      '🎭 Διάλεξε ρόλους: {roles}\n' +
      '📩 Χρειάζεσαι βοήθεια; Άνοιξε αίτημα: {tickets}\n' +
      '📝 Θες να γίνεις αστυνομικός; {applications}',
    dm: 'Καλώς ήρθες στο **{server}**! Διάβασε τους κανόνες και μείνε ασφαλής. Η ΕΛ.ΑΣ. σε προστατεύει. 🛡️',
    goodbye: '**{name}** εγκατέλειψε την Ασφαλή Ζώνη. Ελπίζουμε να τα καταφέρει εκεί έξω... 🧟',
  },

  rules: [
    'Σεβασμός προς όλα τα μέλη και το προσωπικό. Καμία προσβολή, ρατσισμός ή τοξικότητα.',
    'Απαγορεύονται τα FailRP, RDM, VDM, Metagaming και Powergaming.',
    'Εντός της Ασφαλούς Ζώνης απαγορεύεται η άσκηση βίας χωρίς σοβαρό λόγο (Safe Zone Rules).',
    'Οι αστυνομικοί υπακούν στην ιεραρχία και στις εντολές των ανωτέρων τους.',
    'Απαγορεύεται η διαφήμιση, το spam και η αποστολή ακατάλληλου περιεχομένου.',
    'Χρησιμοποίησε τα σωστά κανάλια: αναφορές, αιτήματα, καταγγελίες.',
    'Οι αστυνομικοί μπαίνουν στα φωνητικά της ΕΛ.ΑΣ. μόνο όταν είναι On Duty.',
    'Οι αποφάσεις της Διοίκησης και των διαχειριστών είναι τελικές.',
  ],

  tickets: {
    maxOpenPerUser: 1,
    autoCloseHours: 72, // close tickets with no activity for this long (0 = never)
    description:
      'Χρειάζεσαι βοήθεια ή θέλεις να επικοινωνήσεις με την ΕΛ.ΑΣ.;\n' +
      'Πάτησε ένα κουμπί για να ανοίξει **ιδιωτικό** αίτημα.',
    categories: [
      { key: 'help', label: 'Βοήθεια', emoji: '🆘', description: 'Χρειάζεσαι βοήθεια ή προστασία' },
      { key: 'complaint', label: 'Καταγγελία', emoji: '📢', description: 'Ορατή μόνο στη Διοίκηση', commandOnly: true },
      { key: 'question', label: 'Ερώτηση', emoji: '❓', description: 'Γενική ερώτηση προς την ΕΛ.ΑΣ.' },
      { key: 'other', label: 'Άλλο', emoji: '📩', description: 'Οτιδήποτε άλλο' },
    ],
  },

  application: {
    cooldownDays: 3, // days a rejected applicant must wait before applying again (0 = none)
    info:
      'Θέλεις να υπηρετήσεις στην Ελληνική Αστυνομία και να προστατεύσεις την Ασφαλή Ζώνη;\n\n' +
      '**Προϋποθέσεις:**\n' +
      '• Να έχεις διαβάσει και να τηρείς τους κανόνες\n' +
      '• Καλό επίπεδο Roleplay και λειτουργικό μικρόφωνο\n' +
      '• Να είσαι ενεργός/ή και υπεύθυνος/η\n\n' +
      'Συμπλήρωσε τη φόρμα. Αν περάσεις στη **συνέντευξη**, θα δημιουργηθεί ιδιωτικό κανάλι (κείμενο + φωνητικό) για εσένα και τη Διοίκηση.',
  },

  warnThreshold: 3, // warnings before command staff is alerted

  // ── SECURITY ─────────────────────────────────────────────────
  // Everything here can also be switched live with /security toggle.
  security: {
    modules: {
      badWords: true,    // swear/slur filter – Greek, Greeklish and 20+ languages, with leetspeak / spaced-letter detection
      invites: true,     // block Discord invite links
      links: true,       // block links that are not in allowedDomains
      mentions: true,    // mass mentions / @everyone abuse
      caps: true,        // SHOUTING
      emoji: true,       // emoji spam
      zalgo: true,       // glitch text
      spam: true,        // message flood
      duplicates: true,  // same message repeated
      nicknames: true,   // bad words in nicknames / usernames
      antiNuke: true,    // mass channel/role delete, mass ban/kick, webhook spam, unauthorised bots, permission grabs
      antiRaid: true,    // join floods
      accountAge: false, // kick accounts younger than antiRaid.minAccountAgeDays
    },
    exemptChannels: [],  // channel IDs the filters ignore
    exemptRoles: [],     // role names the filters ignore (Administrators are always exempt)
    allowedDomains: [
      'discord.com', 'discord.gg', 'discordapp.com', 'discordapp.net', 'tenor.com', 'giphy.com', 'imgur.com',
      'youtube.com', 'youtu.be', 'twitch.tv', 'twitter.com', 'x.com', 'instagram.com', 'tiktok.com', 'google.com',
    ],
    limits: {
      mentions: 5,                              // max mentions per message
      caps: { minLetters: 15, ratio: 0.7 },
      emoji: 12,
      spam: { messages: 6, seconds: 6 },
      duplicates: { count: 3, seconds: 30 },
    },
    // Strikes -> punishment ladder. A strike expires after strikeDecayHours without violations.
    strikeDecayHours: 24,
    severeStrikes: 2, // slurs / invite ads / @everyone abuse count double
    ladder: [
      { at: 1, action: 'warn' },
      { at: 3, action: 'timeout', minutes: 10 },
      { at: 5, action: 'timeout', minutes: 60 },
      { at: 7, action: 'timeout', minutes: 1440 },
      { at: 9, action: 'kick' },
      { at: 12, action: 'ban' },
    ],
    notifyDM: true, // DM the user when they are punished
    antiNuke: {
      punishment: 'ban',   // ban | kick | strip (remove all roles)
      windowSeconds: 10,
      limits: { channelDelete: 3, channelCreate: 5, roleDelete: 3, roleCreate: 5, ban: 4, kick: 4, prune: 1, webhookCreate: 2, emojiDelete: 5, permGrant: 2 },
      trusted: [],         // user IDs that are never touched (the server owner and this bot are always trusted)
      restoreChannels: true, // re-create channels deleted during a nuke
      cleanupCreated: true,  // delete channels/roles the attacker created
    },
    antiRaid: { joins: 6, seconds: 10, action: 'kick', minAccountAgeDays: 3, raidModeMinutes: 10 },
  },
};
