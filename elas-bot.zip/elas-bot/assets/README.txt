assets/banner.png  – welcome banner background (1200x450): Welcome emblem + LOCKDOWN logo.
                     The bot draws the member's avatar, name and member number in the CENTRE panel (x 420-810).
                     You can replace it with your own 1200x450 image – just keep the centre free.
assets/fonts/      – optional: put a .ttf/.otf with Greek support here (e.g. Roboto, Noto Sans)
                     if the banner text shows squares instead of Greek letters (some Linux servers).
