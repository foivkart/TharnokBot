require('dotenv').config();
const fs = require('node:fs');
const path = require('node:path');
const {
  Client, Collection, Events, GatewayIntentBits, Partials, ActivityType, MessageFlags,
} = require('discord.js');
const db = require('./utils/db');
const duty = require('./utils/duty');

if (!process.env.DISCORD_TOKEN) {
  console.error('❌ DISCORD_TOKEN is missing. Copy .env.example to .env and fill it in.');
  process.exit(1);
}

db.load();

// In the Developer Portal (Bot tab) these must be ON:  Server Members Intent  +  Message Content Intent
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.GuildVoiceStates,
  ],
  partials: [Partials.Message, Partials.Channel],
});

client.commands = new Collection(); // command name -> module
client.handlers = new Collection(); // button/modal prefix -> module

const cmdDir = path.join(__dirname, 'commands');
for (const file of fs.readdirSync(cmdDir).filter((f) => f.endsWith('.js'))) {
  const cmd = require(path.join(cmdDir, file));
  client.commands.set(cmd.data.name, cmd);
  client.handlers.set(cmd.prefix ?? cmd.data.name, cmd);
}

const evDir = path.join(__dirname, 'events');
for (const file of fs.readdirSync(evDir).filter((f) => f.endsWith('.js'))) {
  require(path.join(evDir, file)).register(client);
}

client.once(Events.ClientReady, async (c) => {
  console.log(`✅ Online as ${c.user.tag} – ${client.commands.size} commands loaded`);
  c.user.setPresence({ activities: [{ name: 'την Ασφαλή Ζώνη 🛡️', type: ActivityType.Watching }], status: 'online' });
  await duty.sync(client).catch((e) => console.error('Duty sync:', e));
  setInterval(duty.checkpoint, 60000); // saves running call time every minute
  setInterval(() => client.commands.get('ticket')?.tick(client).catch(console.error), 15 * 60000); // auto-close idle tickets
  setInterval(() => client.commands.get('remind')?.tick(client).catch(console.error), 30000);     // reminders
  client.commands.get('giveaway')?.resume(client);                                                  // running giveaways
  console.log('✅ Duty system synced');
});

client.on(Events.InteractionCreate, async (interaction) => {
  try {
    if (!interaction.inGuild()) return;

    if (interaction.isChatInputCommand()) {
      await client.commands.get(interaction.commandName)?.execute(interaction);
    } else if (interaction.isAutocomplete()) {
      await client.commands.get(interaction.commandName)?.autocomplete?.(interaction);
    } else if (interaction.isButton() || interaction.isModalSubmit()) {
      // customId: prefix:part1:part2...
      const [prefix, ...parts] = interaction.customId.split(':');
      const mod = client.handlers.get(prefix);
      const handler = interaction.isButton() ? mod?.button : mod?.modal;
      await handler?.(interaction, parts);
    }
  } catch (err) {
    console.error(err);
    if (interaction.isAutocomplete() || !interaction.isRepliable()) return;
    const msg = { content: '⚠️ Κάτι πήγε στραβά. Δοκίμασε ξανά.', flags: MessageFlags.Ephemeral };
    if (interaction.replied || interaction.deferred) await interaction.followUp(msg).catch(() => {});
    else await interaction.reply(msg).catch(() => {});
  }
});

process.on('unhandledRejection', (e) => console.error('Unhandled rejection:', e));
process.on('uncaughtException', (e) => console.error('Uncaught exception:', e));
const shutdown = () => { duty.checkpoint(); db.saveNow(); process.exit(0); };
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

client.login(process.env.DISCORD_TOKEN).catch((err) => {
  const m = String(err.message).toLowerCase();
  if (m.includes('disallowed intents')) {
    console.error('❌ Privileged intents are OFF.\n   Developer Portal → your app → Bot → turn ON "Server Members Intent" AND "Message Content Intent" → Save.');
  } else if (m.includes('invalid token') || m.includes('token')) {
    console.error('❌ Invalid token. Check DISCORD_TOKEN in your .env file.');
  } else {
    console.error(err);
  }
  process.exit(1);
});
