const { SlashCommandBuilder } = require('discord.js');
const config = require('../config');
const db = require('../utils/db');
const h = require('../utils/helpers');
const duty = require('../utils/duty');
const sig = require('../utils/signals');

module.exports = {
  data: new SlashCommandBuilder().setName('roster').setDescription('Show all officers grouped by rank'),

  async execute(i) {
    await i.deferReply();
    const members = await i.guild.members.fetch();
    const L = h.ladder(i.guild);
    const groups = L.map(() => []);
    const noRank = [];
    for (const m of members.values()) {
      if (m.user.bot) continue;
      const r = h.rankIndex(m);
      if (r >= 0) groups[r].push(m);
      else if (h.isStaff(m)) noRank.push(m);
    }

    const dutyData = db.get().duty;
    let total = 0;
    let on = 0;
    const line = (m) => {
      const isOn = !!dutyData[m.id]?.onDuty;
      if (isOn) on++;
      const cs = sig.callsignOf(m.id);
      return `${duty.inCall(m.id) ? '🎧' : isOn ? '🟢' : '⚫'} ${m}${cs ? ` \`${cs}\`` : ''}`;
    };
    const blocks = [];
    for (let r = L.length - 1; r >= 0; r--) {
      if (!groups[r].length) continue;
      total += groups[r].length;
      blocks.push(`**${L[r].name}** (${groups[r].length})\n${groups[r].map(line).join('\n')}`);
    }
    if (noRank.length) { total += noRank.length; blocks.push(`**Χωρίς βαθμό** (${noRank.length})\n${noRank.map(line).join('\n')}`); }
    if (!blocks.length) return i.editReply('Δεν υπάρχουν αστυνομικοί ακόμα. Όρισε βαθμούς/ρόλους με `/config` και χρησιμοποίησε `/promote @user`.');

    const pages = [];
    let cur = '';
    for (const b of blocks) {
      if (cur && (cur + '\n\n' + b).length > 3500) { pages.push(cur); cur = b; }
      else cur = cur ? `${cur}\n\n${b}` : b;
    }
    if (cur) pages.push(cur);

    const embeds = pages.map((p, n) => {
      const e = h.baseEmbed().setDescription(h.cut(p, 4000));
      if (n === 0) e.setTitle(`👮 ${config.department} – Προσωπικό`).setAuthor({ name: `${total} αστυνομικοί • ${on} On Duty` });
      return e;
    });
    await i.editReply({ embeds: [embeds[0]], allowedMentions: { parse: [] } });
    for (const e of embeds.slice(1)) await i.followUp({ embeds: [e], allowedMentions: { parse: [] } });
  },
};
