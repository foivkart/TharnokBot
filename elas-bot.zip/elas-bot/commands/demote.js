const { SlashCommandBuilder } = require('discord.js');
const { change } = require('../utils/rank');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('demote')
    .setDescription('Demote an officer one rank')
    .addUserOption((o) => o.setName('officer').setDescription('Who to demote').setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('Reason').setMaxLength(300)),
  execute: (i) => change(i, -1),
};
