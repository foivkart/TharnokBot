const { SlashCommandBuilder } = require('discord.js');
const h = require('../utils/helpers');
const { buildWelcome, rulesPayload } = require('../utils/welcome');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('welcome')
    .setDescription('Test the welcome banner and post the rules (command staff)')
    .addSubcommand((s) => s.setName('test').setDescription('Preview the welcome message + banner (only you see it)'))
    .addSubcommand((s) => s.setName('rules').setDescription('Post the rules').addChannelOption((o) => h.channelOpt(o, 'Where to post the rules (default: the rules channel)'))),

  async execute(i) {
    if (!h.isCommand(i.member)) return h.deny(i, 'Μόνο η Διοίκηση μπορεί να το χρησιμοποιήσει.');
    if (i.options.getSubcommand() === 'test') {
      await i.deferReply({ flags: h.EPH });
      return i.editReply(await buildWelcome(i.member));
    }
    const ch = i.options.getChannel('channel') ?? await h.getChannel(i.guild, 'rules');
    if (!ch) return h.deny(i, 'Δεν βρέθηκε το κανάλι κανόνων. Τρέξε πρώτα `/config`.');
    await ch.send(rulesPayload());
    return i.reply({ content: `✅ Οι κανόνες δημοσιεύτηκαν στο ${ch}.`, flags: h.EPH });
  },
};
