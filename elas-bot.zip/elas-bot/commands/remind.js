const { SlashCommandBuilder } = require('discord.js');
const db = require('../utils/db');
const h = require('../utils/helpers');

// "1h30m", "2d", "45m", "90s" -> milliseconds (null if invalid)
function parseDuration(text) {
  let ms = 0;
  let found = false;
  const clean = text.toLowerCase().replace(/\s+/g, '');
  const rest = clean.replace(/(\d+)(d|h|m|s)/g, (_, n, u) => { found = true; ms += Number(n) * { d: 86400000, h: 3600000, m: 60000, s: 1000 }[u]; return ''; });
  return found && !rest ? ms : null;
}

async function tick(client) {
  const list = db.get().reminders;
  const now = Date.now();
  const due = list.filter((r) => r.at <= now);
  if (!due.length) return;
  db.get().reminders = list.filter((r) => r.at > now);
  db.save();
  for (const r of due) {
    const user = await client.users.fetch(r.userId).catch(() => null);
    const text = `⏰ **Υπενθύμιση:** ${r.text}`;
    const ok = user ? await h.dm(user, { content: text }) : false;
    if (!ok) {
      const ch = await client.channels.fetch(r.channelId).catch(() => null);
      await ch?.send({ content: `<@${r.userId}> ${text}`, allowedMentions: { users: [r.userId] } }).catch(() => {});
    }
  }
}

module.exports = {
  tick,
  parseDuration,
  data: new SlashCommandBuilder()
    .setName('remind')
    .setDescription('Personal reminders')
    .addSubcommand((s) =>
      s.setName('set').setDescription('Remind me later')
        .addStringOption((o) => o.setName('in').setDescription('When? e.g. 30m, 2h, 1d12h').setRequired(true).setMaxLength(20))
        .addStringOption((o) => o.setName('message').setDescription('What should I remind you?').setRequired(true).setMaxLength(300)))
    .addSubcommand((s) => s.setName('list').setDescription('Show my reminders'))
    .addSubcommand((s) => s.setName('cancel').setDescription('Cancel a reminder').addIntegerOption((o) => o.setName('number').setDescription('Number from /remind list').setRequired(true).setMinValue(1))),

  async execute(i) {
    const sub = i.options.getSubcommand();
    const d = db.get();
    const mine = d.reminders.filter((r) => r.userId === i.user.id).sort((a, b) => a.at - b.at);
    if (sub === 'list') {
      const text = mine.map((r, n) => `**${n + 1}.** <t:${h.unix(r.at)}:R> — ${h.cut(r.text, 100)}`).join('\n') || 'Δεν έχεις ενεργές υπενθυμίσεις.';
      return i.reply({ embeds: [h.baseEmbed().setTitle('⏰ Οι υπενθυμίσεις μου').setDescription(text)], flags: h.EPH });
    }
    if (sub === 'cancel') {
      const r = mine[i.options.getInteger('number') - 1];
      if (!r) return h.deny(i, 'Δεν βρέθηκε υπενθύμιση με αυτόν τον αριθμό.');
      d.reminders = d.reminders.filter((x) => x !== r); db.save();
      return i.reply({ content: '✅ Η υπενθύμιση ακυρώθηκε.', flags: h.EPH });
    }
    const ms = parseDuration(i.options.getString('in'));
    if (!ms || ms < 10000 || ms > 90 * 86400000) return h.deny(i, 'Μη έγκυρος χρόνος. Παραδείγματα: `30m`, `2h`, `1d12h` (από 10 δευτερόλεπτα έως 90 ημέρες).');
    if (mine.length >= 20) return h.deny(i, 'Έχεις πολλές υπενθυμίσεις (μέγιστο 20).');
    d.reminders.push({ userId: i.user.id, channelId: i.channelId, at: Date.now() + ms, text: i.options.getString('message') });
    db.save();
    return i.reply({ content: `⏰ Θα σε ειδοποιήσω <t:${h.unix(Date.now() + ms)}:R>.`, flags: h.EPH });
  },
};
