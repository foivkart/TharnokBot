const { SlashCommandBuilder, ChannelType, PermissionFlagsBits: P } = require('discord.js');
const config = require('../config');
const db = require('../utils/db');
const h = require('../utils/helpers');

const ROLE_KEYS = {
  onDuty: 'On Duty role', offDuty: 'Off Duty role', eventPing: 'Role pinged for new events',
  interviewWait: 'Role while waiting for an interview', interviewDenied: 'Role after a rejected application', blacklisted: 'Blacklisted role (blocked from tickets/applications)',
};
const SETTINGS = {
  weeklyQuotaMinutes: 'Weekly duty quota in minutes (0 = off)',
  ticketAutoCloseHours: 'Auto-close idle tickets after N hours (0 = off)',
  applicationCooldownDays: 'Days to wait after a rejected application',
  maxOpenTickets: 'Max open tickets per member',
  signalsDefaultUnit: 'Default signal unit code xx (number)',
  signalsSetNickname: 'Set nickname when picking a signal (1 yes / 0 no)',
};
const CHANNEL_KEYS = Object.keys(config.channels);
const keyLabel = (k) => `${k} — ${config.channels[k].topic}`;

const roleOpt = (o, desc = 'The role') => o.setName('role').setDescription(desc).setRequired(true);
const enabledOpt = (o) => o.setName('enabled').setDescription('Add (default) or remove');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('config')
    .setDescription('Tell the bot which channels and roles to use on YOUR server (admins)')
    .setDefaultMemberPermissions(P.Administrator)
    .addSubcommand((s) => s.setName('view').setDescription('Show everything that is configured and what is missing'))
    .addSubcommand((s) =>
      s.setName('channel').setDescription('Choose the channel a feature uses (logs, welcome, panels...)')
        .addStringOption((o) => o.setName('feature').setDescription('Which feature').setRequired(true).setAutocomplete(true))
        .addChannelOption((o) => o.setName('channel').setDescription('The channel').setRequired(true).addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)))
    .addSubcommand((s) => s.setName('channel_clear').setDescription('Forget the channel of a feature').addStringOption((o) => o.setName('feature').setDescription('Which feature').setRequired(true).setAutocomplete(true)))
    .addSubcommand((s) =>
      s.setName('role').setDescription('Set an important role (On Duty, Off Duty, interview roles...)')
        .addStringOption((o) => o.setName('key').setDescription('What is this role for').setRequired(true).addChoices(...Object.entries(ROLE_KEYS).map(([value, name]) => ({ name, value }))))
        .addRoleOption(roleOpt))
    .addSubcommand((s) =>
      s.setName('role_clear').setDescription('Forget an important role')
        .addStringOption((o) => o.setName('key').setDescription('Which one').setRequired(true).addChoices(...Object.entries(ROLE_KEYS).map(([value, name]) => ({ name, value })))))
    .addSubcommand((s) => s.setName('rank').setDescription('Add/remove a rank role (order = their position in the role list)').addRoleOption((o) => roleOpt(o, 'The rank role')).addBooleanOption(enabledOpt))
    .addSubcommand((s) =>
      s.setName('rank_range').setDescription('Make every role between two roles a rank (lowest rank + highest rank)')
        .addRoleOption((o) => o.setName('lowest').setDescription('Lowest rank role (e.g. Cadet)').setRequired(true))
        .addRoleOption((o) => o.setName('highest').setDescription('Highest rank role (e.g. Chief)').setRequired(true)))
    .addSubcommand((s) => s.setName('rank_clear').setDescription('Remove all configured ranks'))
    .addSubcommand((s) => s.setName('command_from').setDescription('This rank and above = command staff').addRoleOption((o) => roleOpt(o, 'The lowest command rank')))
    .addSubcommand((s) => s.setName('command_role').setDescription('Extra role that counts as command staff').addRoleOption(roleOpt).addBooleanOption(enabledOpt))
    .addSubcommand((s) => s.setName('officer_role').setDescription('Extra role that counts as an officer (e.g. the general police role)').addRoleOption(roleOpt).addBooleanOption(enabledOpt))
    .addSubcommand((s) =>
      s.setName('autorole').setDescription('Role given automatically to new members / bots')
        .addRoleOption(roleOpt)
        .addStringOption((o) => o.setName('target').setDescription('Who gets it (default: members)').addChoices({ name: 'New members', value: 'onJoin' }, { name: 'Bots', value: 'bots' }))
        .addBooleanOption(enabledOpt))
    .addSubcommand((s) =>
      s.setName('selfrole').setDescription('Role members can pick with buttons (/roles panel)')
        .addRoleOption(roleOpt)
        .addStringOption((o) => o.setName('emoji').setDescription('Button emoji (default 🔔)').setMaxLength(8))
        .addBooleanOption(enabledOpt))
    .addSubcommand((s) =>
      s.setName('category').setDescription('Category where new tickets / interview channels are created')
        .addStringOption((o) => o.setName('kind').setDescription('Which one').setRequired(true).addChoices({ name: 'Tickets', value: 'tickets' }, { name: 'Interviews', value: 'interviews' }))
        .addChannelOption((o) => o.setName('category').setDescription('The category').setRequired(true).addChannelTypes(ChannelType.GuildCategory)))
    .addSubcommand((s) =>
      s.setName('unit').setDescription('Link a unit role (ΕΚΑΜ, ΟΠΚΕ...) to a code xx used in signals and /unit stats')
        .addRoleOption(roleOpt)
        .addStringOption((o) => o.setName('code').setDescription('Unit code, 1-2 digits (e.g. 07)').setMaxLength(2))
        .addStringOption((o) => o.setName('name').setDescription('Display name (default: the role name)').setMaxLength(40))
        .addBooleanOption(enabledOpt))
    .addSubcommand((s) => s.setName('ticket_role').setDescription('Role that can see tickets (default: all officers)').addRoleOption(roleOpt).addBooleanOption(enabledOpt))
    .addSubcommand((s) =>
      s.setName('voice').setDescription('A voice channel (or a whole category) whose time counts for duty')
        .addChannelOption((o) => o.setName('channel').setDescription('Voice channel or category').setRequired(true).addChannelTypes(ChannelType.GuildVoice, ChannelType.GuildStageVoice, ChannelType.GuildCategory))
        .addBooleanOption(enabledOpt)
        .addBooleanOption((o) => o.setName('command_only').setDescription('Only command staff may stay in it')))
    .addSubcommand((s) =>
      s.setName('setting').setDescription('Change a number setting (quota, ticket auto-close...)')
        .addStringOption((o) => o.setName('key').setDescription('Which setting').setRequired(true).addChoices(...Object.entries(SETTINGS).map(([value, name]) => ({ name, value }))))
        .addIntegerOption((o) => o.setName('value').setDescription('New value').setRequired(true).setMinValue(0).setMaxValue(100000))),

  async autocomplete(i) {
    const q = i.options.getFocused().toLowerCase();
    await i.respond(CHANNEL_KEYS.filter((k) => keyLabel(k).toLowerCase().includes(q)).slice(0, 25).map((k) => ({ name: h.cut(keyLabel(k), 100), value: k })));
  },

  async execute(i) {
    if (!h.isAdmin(i.member)) return h.deny(i, 'Μόνο οι διαχειριστές μπορούν να αλλάξουν τις ρυθμίσεις.');
    const sub = i.options.getSubcommand();
    const d = db.get();
    const C = d.cfg;
    const toggle = (arr, id, on) => { const rest = arr.filter((x) => x !== id); return on ? [...rest, id] : rest; };
    const on = i.options.getBoolean('enabled') ?? true;
    const role = i.options.getRole('role');
    const done = (text) => { db.save(); return i.reply({ content: text, flags: h.EPH }); };

    if (sub === 'view') {
      const ch = CHANNEL_KEYS.map((k) => `${d.channels[k] ? '✅' : '▫️'} \`${k}\` → ${d.channels[k] ? `<#${d.channels[k]}>` : '*δεν έχει οριστεί*'}`).join('\n');
      const L = h.ladder(i.guild);
      const cmd = h.commandIndex(i.guild);
      const ranks = L.length ? [...L].reverse().map((r, n) => `${L.length - 1 - n >= cmd ? '⭐' : '▫️'} ${r}`).join('\n') : '*δεν έχουν οριστεί (`/config rank_range`)*';
      const list = (ids) => (ids.length ? ids.map((x) => `<@&${x}>`).join(' ') : '—');
      const roles = Object.keys(ROLE_KEYS).map((k) => `${h.roleFor(i.guild, k) ? '✅' : '▫️'} ${ROLE_KEYS[k]}: ${h.roleFor(i.guild, k) ?? '—'}`).join('\n');
      const voice = [...Object.entries(d.voiceChannels).filter(([, v]) => v.counted).map(([id, v]) => `🔊 <#${id}>${v.commandOnly ? ' (Διοίκηση)' : ''}`), ...Object.entries(d.voiceCategories).map(([id, v]) => `📁 <#${id}>${v.commandOnly ? ' (Διοίκηση)' : ''}`)].join('\n') || '—';
      const settings = Object.keys(SETTINGS).map((k) => `• ${SETTINGS[k]}: **${h.setting(k)}**`).join('\n');
      const e1 = h.baseEmbed().setTitle('⚙️ Κανάλια').setDescription(`${ch}\n\n*Τα logs έχουν fallback: αν δεν οριστεί ειδικό κανάλι, χρησιμοποιείται το \`logs\` (και το securityLog → modLog → logs).*`);
      const e2 = h.baseEmbed().setTitle('⚙️ Ρόλοι & ρυθμίσεις').setDescription(`**Βαθμοί** (από ψηλά):\n${h.cut(ranks, 1500)}`)
        .addFields(
          { name: 'Σημαντικοί ρόλοι', value: h.cut(roles, 1000) },
          { name: 'Επιπλέον ρόλοι αστυνομικών', value: list(C.officerRoles), inline: true },
          { name: 'Επιπλέον ρόλοι Διοίκησης', value: list(C.commandRoles), inline: true },
          { name: 'Autoroles', value: `Μέλη: ${list(C.autoRoles.onJoin)}\nBots: ${list(C.autoRoles.bots)}` },
          { name: 'Ρόλοι επιλογής (selfroles)', value: C.selfRoles.length ? h.cut(C.selfRoles.map((s) => `${s.emoji} <@&${s.roleId}>`).join(' '), 1000) : '—' },
          { name: 'Μονάδες (ρόλος → κωδικός xx)', value: C.units.length ? h.cut(C.units.map((u) => `\`${u.code}\` <@&${u.roleId}>`).join(' • '), 1000) : '—' },
          { name: 'Ρόλοι που βλέπουν tickets', value: C.ticketRoles.length ? list(C.ticketRoles) : '*όλοι οι αστυνομικοί*' },
          { name: 'Κατηγορίες', value: `Tickets: ${C.categories.tickets ? `<#${C.categories.tickets}>` : '—'} • Συνεντεύξεις: ${C.categories.interviews ? `<#${C.categories.interviews}>` : '*(όπως τα tickets)*'}` },
          { name: 'Φωνητικά που μετράνε', value: h.cut(voice, 1000) },
          { name: 'Ρυθμίσεις', value: h.cut(settings, 1000) },
        );
      return i.reply({ embeds: [e1, e2], flags: h.EPH, allowedMentions: { parse: [] } });
    }

    if (sub === 'channel' || sub === 'channel_clear') {
      const key = i.options.getString('feature');
      if (!CHANNEL_KEYS.includes(key)) return h.deny(i, 'Άγνωστη λειτουργία. Διάλεξε από τη λίστα προτάσεων.');
      if (sub === 'channel_clear') { delete d.channels[key]; return done(`✅ Το κανάλι της λειτουργίας \`${key}\` διαγράφηκε.`); }
      const ch = i.options.getChannel('channel');
      d.channels[key] = ch.id;
      return done(`✅ \`${key}\` → ${ch}`);
    }

    if (sub === 'role' || sub === 'role_clear') {
      const key = i.options.getString('key');
      if (sub === 'role_clear') { delete C.roles[key]; return done(`✅ Ο ρόλος «${ROLE_KEYS[key]}» διαγράφηκε.`); }
      if (role.managed || role.id === i.guild.id) return h.deny(i, 'Αυτός ο ρόλος δεν μπορεί να χρησιμοποιηθεί.');
      C.roles[key] = role.id;
      return done(`✅ ${ROLE_KEYS[key]}: ${role}`);
    }

    if (['rank', 'command_from', 'command_role', 'officer_role', 'autorole', 'selfrole', 'ticket_role', 'unit'].includes(sub) && (role.managed || role.id === i.guild.id)) {
      return h.deny(i, 'Αυτός ο ρόλος δεν μπορεί να χρησιμοποιηθεί (bot ή @everyone).');
    }

    if (sub === 'rank') { C.ranks = toggle(C.ranks, role.id, on); return done(`✅ ${role} ${on ? 'προστέθηκε στους βαθμούς' : 'αφαιρέθηκε από τους βαθμούς'}. Δες τη σειρά με \`/config view\`.`); }
    if (sub === 'rank_clear') { C.ranks = []; return done('✅ Οι βαθμοί διαγράφηκαν.'); }
    if (sub === 'rank_range') {
      const a = i.options.getRole('lowest');
      const b = i.options.getRole('highest');
      const lo = Math.min(a.position, b.position);
      const hi = Math.max(a.position, b.position);
      const picked = i.guild.roles.cache.filter((r) => r.id !== i.guild.id && !r.managed && r.position >= lo && r.position <= hi && /\p{L}/u.test(r.name)).sort((x, y) => x.position - y.position);
      if (picked.size > 30) return h.deny(i, `Το εύρος έχει ${picked.size} ρόλους (μέγιστο 30). Διάλεξε πιο κοντινούς ρόλους.`);
      C.ranks = [...picked.keys()];
      return done(`✅ Ορίστηκαν **${picked.size}** βαθμοί (χαμηλότερος → υψηλότερος):\n${picked.map((r) => `• ${r.name}`).join('\n')}\n\nΑν μπήκαν και ρόλοι που δεν είναι βαθμοί (π.χ. ομάδες), αφαίρεσέ τους με \`/config rank role:@ρόλος enabled:False\`.`);
    }
    if (sub === 'command_from') { C.commandFrom = role.id; return done(`✅ Διοίκηση: από τον βαθμό ${role} και πάνω.`); }
    if (sub === 'command_role') { C.commandRoles = toggle(C.commandRoles, role.id, on); return done(`✅ ${role} ${on ? 'μετράει πλέον ως Διοίκηση' : 'δεν μετράει πια ως Διοίκηση'}.`); }
    if (sub === 'officer_role') { C.officerRoles = toggle(C.officerRoles, role.id, on); return done(`✅ ${role} ${on ? 'μετράει πλέον ως αστυνομικός' : 'δεν μετράει πια ως αστυνομικός'}.`); }
    if (sub === 'ticket_role') { C.ticketRoles = toggle(C.ticketRoles, role.id, on); return done(`✅ ${role} ${on ? 'βλέπει πλέον τα tickets' : 'δεν βλέπει πια τα tickets'}.`); }
    if (sub === 'autorole') {
      const t = i.options.getString('target') ?? 'onJoin';
      C.autoRoles[t] = toggle(C.autoRoles[t], role.id, on);
      return done(`✅ Autorole ${role} ${on ? 'ενεργό' : 'αφαιρέθηκε'} για ${t === 'bots' ? 'τα bots' : 'τα νέα μέλη'}.`);
    }
    if (sub === 'selfrole') {
      C.selfRoles = C.selfRoles.filter((s) => s.roleId !== role.id);
      if (on) { if (C.selfRoles.length >= 25) return h.deny(i, 'Μέγιστο 25 ρόλοι επιλογής.'); C.selfRoles.push({ roleId: role.id, emoji: i.options.getString('emoji') ?? '🔔' }); }
      return done(`✅ Ρόλος επιλογής ${role} ${on ? 'προστέθηκε' : 'αφαιρέθηκε'}. Ανέβασε/ανανέωσε το πάνελ με \`/roles panel\`.`);
    }
    if (sub === 'unit') {
      C.units = C.units.filter((u) => u.roleId !== role.id);
      if (!on) return done(`✅ Η μονάδα ${role} αφαιρέθηκε.`);
      const code = String(i.options.getString('code') ?? '').replace(/\D/g, '');
      if (!code) return h.deny(i, 'Γράψε κωδικό μονάδας (1-2 ψηφία), π.χ. `07`.');
      const padded = code.padStart(2, '0');
      const clash = C.units.find((u) => u.code === padded);
      C.units.push({ roleId: role.id, code: padded, name: i.options.getString('name') ?? role.name });
      return done(`✅ Μονάδα ${role} → κωδικός **${padded}**${clash ? ` (⚠️ τον χρησιμοποιεί ήδη και η <@&${clash.roleId}>)` : ''}. Όποιος έχει αυτόν τον ρόλο παίρνει αυτόματα \`[${padded}-αριθμός]\` στα σήματα.`);
    }
    if (sub === 'category') {
      const cat = i.options.getChannel('category');
      C.categories[i.options.getString('kind')] = cat.id;
      return done(`✅ Κατηγορία (${i.options.getString('kind')}): ${cat}`);
    }
    if (sub === 'voice') {
      const ch = i.options.getChannel('channel');
      const isCat = ch.type === ChannelType.GuildCategory;
      const cmdOnly = !!i.options.getBoolean('command_only');
      delete d.voiceChannels[ch.id];
      delete d.voiceCategories[ch.id];
      if (on) {
        if (isCat) d.voiceCategories[ch.id] = { counted: true, commandOnly: cmdOnly };
        else d.voiceChannels[ch.id] = { key: 'custom', counted: true, commandOnly: cmdOnly, open: false };
      }
      return done(on ? `✅ ${isCat ? 'Όλα τα φωνητικά της κατηγορίας' : 'Το φωνητικό'} ${ch} μετράνε πλέον για υπηρεσία${cmdOnly ? ' (μόνο Διοίκηση)' : ''}.` : `✅ Το ${ch} δεν μετράει πια.`);
    }
    if (sub === 'setting') {
      const key = i.options.getString('key');
      C.settings[key] = i.options.getInteger('value');
      return done(`✅ ${SETTINGS[key]}: **${C.settings[key]}**`);
    }
  },
};
