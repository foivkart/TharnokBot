const { SlashCommandBuilder } = require('discord.js');
const { change } = require('../utils/rank');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('promote')
    .setDescription('Promote an officer one rank (or enlist a civilian)')
    .addUserOption((o) => o.setName('officer').setDescription('Who to promote').setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('Reason').setMaxLength(300)),
  execute: (i) => change(i, +1),
};
