const { SlashCommandBuilder, version: djsVersion } = require('discord.js');
const config = require('../config');
const db = require('../utils/db');
const h = require('../utils/helpers');
const duty = require('../utils/duty');
const sig = require('../utils/signals');
const sec = require('../utils/security');

const member = (o) => o.setName('member').setDescription('Member (default: you)');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('info')
    .setDescription('Information about members, the server and the bot')
    .addSubcommand((s) => s.setName('user').setDescription('Detailed info about a member').addUserOption(member))
    .addSubcommand((s) => s.setName('server').setDescription('Server information'))
    .addSubcommand((s) => s.setName('avatar').setDescription('Show a member\'s avatar').addUserOption(member))
    .addSubcommand((s) => s.setName('bot').setDescription('Bot status: ping, uptime, memory')),

  async execute(i) {
    const sub = i.options.getSubcommand();
    const d = db.get();

    if (sub === 'avatar') {
      const u = i.options.getUser('member') ?? i.user;
      return i.reply({ embeds: [h.baseEmbed().setTitle(`🖼️ ${u.username}`).setImage(u.displayAvatarURL({ size: 1024 }))] });
    }

    if (sub === 'bot') {
      const up = Math.floor(process.uptime());
      const fmt = `${Math.floor(up / 86400)}ημ ${Math.floor((up % 86400) / 3600)}ω ${Math.floor((up % 3600) / 60)}λ`;
      return i.reply({ embeds: [h.baseEmbed().setTitle('🤖 Κατάσταση bot').addFields(
        { name: 'Ping', value: `${Math.round(i.client.ws.ping)} ms`, inline: true }, { name: 'Uptime', value: fmt, inline: true },
        { name: 'Μνήμη', value: `${(process.memoryUsage().rss / 1048576).toFixed(0)} MB`, inline: true },
        { name: 'Εντολές', value: String(i.client.commands.size), inline: true }, { name: 'discord.js', value: djsVersion, inline: true }, { name: 'Node', value: process.version, inline: true },
      )], flags: h.EPH });
    }

    if (sub === 'server') {
      await i.deferReply();
      const g = i.guild;
      const members = await g.members.fetch();
      const bots = members.filter((m) => m.user.bot).size;
      return i.editReply({ embeds: [h.baseEmbed().setTitle(`🏠 ${g.name}`).setThumbnail(g.iconURL()).addFields(
        { name: 'Ιδιοκτήτης', value: `<@${g.ownerId}>`, inline: true }, { name: 'Δημιουργήθηκε', value: `<t:${h.unix(g.createdTimestamp)}:D>`, inline: true },
        { name: 'Μέλη', value: `${members.size - bots} (+${bots} bots)`, inline: true }, { name: 'Κανάλια', value: String(g.channels.cache.size), inline: true },
        { name: 'Ρόλοι', value: String(g.roles.cache.size), inline: true }, { name: 'Boosts', value: `${g.premiumSubscriptionCount ?? 0} (επίπεδο ${g.premiumTier})`, inline: true },
        { name: 'Verification', value: String(g.verificationLevel), inline: true }, { name: 'Raid mode', value: d.security.raid.active ? '🚨 ενεργό' : '✅ ανενεργό', inline: true },
      )] });
    }

    // user
    const m = i.options.getMember('member') ?? i.member;
    const staff = h.isCommand(i.member);
    const r = h.rankIndex(m);
    const roles = m.roles.cache.filter((x) => x.id !== i.guild.id).sort((a, b) => b.position - a.position).first(10).map((x) => `${x}`).join(' ') || '—';
    const ageDays = Math.floor((Date.now() - m.user.createdTimestamp) / 86400000);
    const e = h.baseEmbed().setTitle(`🔎 ${m.displayName}`).setThumbnail(m.displayAvatarURL())
      .setDescription(`${m} • \`${m.id}\``)
      .addFields(
        { name: 'Λογαριασμός', value: `<t:${h.unix(m.user.createdTimestamp)}:D> (${ageDays} ημέρες)${ageDays < 7 ? ' ⚠️' : ''}`, inline: true },
        { name: 'Μπήκε', value: `<t:${h.unix(m.joinedTimestamp)}:D>`, inline: true },
        { name: 'Βαθμός', value: r >= 0 ? `🎖️ ${h.rankName(i.guild, r)}` : 'Πολίτης', inline: true },
        { name: 'Ρόλοι', value: h.cut(roles, 1000) },
      );
    if (h.isStaff(m)) {
      const rec = d.duty[m.id];
      e.addFields(
        { name: 'Σήμα', value: sig.callsignOf(m.id) ?? '—', inline: true },
        { name: 'Μονάδα', value: h.unitsOf(m).map((u) => `<@&${u.roleId}>`).join(' ') || '—', inline: true },
        { name: 'Κλήση (εβδομάδα)', value: h.fmtDuration(duty.weekMs(m.id)), inline: true },
        { name: 'Έπαινοι', value: String((d.commends[m.id] || []).length), inline: true },
        { name: 'Αποστολές / Εκπαιδεύσεις', value: `${rec?.events || 0} / ${rec?.trainings || 0}`, inline: true },
      );
    }
    if (staff) {
      e.addFields(
        { name: '⚖️ Strikes', value: String(sec.strikesOf(m.id)), inline: true },
        { name: '⚠️ Προειδοποιήσεις', value: String((d.warnings[m.id] || []).length), inline: true },
        { name: '📝 Σημειώσεις', value: String((d.notes[m.id] || []).length), inline: true },
        { name: 'Κατάσταση', value: [m.isCommunicationDisabled() ? `🔇 timeout έως <t:${h.unix(m.communicationDisabledUntilTimestamp)}:R>` : null, d.quarantine[m.id] ? '🧪 καραντίνα' : null, d.ticketBlacklist[m.id] ? '⛔ αποκλεισμός tickets' : null].filter(Boolean).join(' • ') || '✅ κανονική', inline: false },
      );
    }
    return i.reply({ embeds: [e], flags: staff ? h.EPH : undefined });
  },
};
