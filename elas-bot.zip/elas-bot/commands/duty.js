const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config');
const db = require('../utils/db');
const h = require('../utils/helpers');
const duty = require('../utils/duty');
const { withBanner } = require('../utils/panelart');

const panel = () => withBanner({
  embeds: [
    h.baseEmbed().setTitle('🚔 Πάνελ Υπηρεσίας ΕΛ.ΑΣ.')
      .setDescription(
        'Πάτησε **On Duty** για να αναλάβεις υπηρεσία και να αποκτήσεις πρόσβαση στα **φωνητικά κανάλια** της ΕΛ.ΑΣ.\n' +
        'Πάτησε **Off Duty** όταν τελειώσεις.\n\n' +
        '⏱️ Ο χρόνος υπηρεσίας μετράει **μόνο όσο είσαι σε φωνητική κλήση**.\n' +
        '🔒 Χωρίς **On Duty** δεν μπορείς να μπεις στις κλήσεις.',
      ),
  ],
  components: [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('duty:on').setLabel('On Duty').setEmoji('🟢').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('duty:off').setLabel('Off Duty').setEmoji('🔴').setStyle(ButtonStyle.Danger),
    ),
  ],
}, 'duty');

const bar = (pct) => {
  const n = Math.max(0, Math.min(10, Math.round(pct / 10)));
  return `${'▰'.repeat(n)}${'▱'.repeat(10 - n)} ${Math.min(100, Math.round(pct))}%`;
};

module.exports = {
  prefix: 'duty',
  panel,
  data: new SlashCommandBuilder()
    .setName('duty')
    .setDescription('Go On/Off Duty and see call time')
    .addSubcommand((s) => s.setName('on').setDescription('Go On Duty (unlocks the duty voice channels)'))
    .addSubcommand((s) => s.setName('off').setDescription('Go Off Duty'))
    .addSubcommand((s) =>
      s.setName('time').setDescription('Show call time')
        .addUserOption((o) => o.setName('officer').setDescription('Officer (default: you)')))
    .addSubcommand((s) =>
      s.setName('leaderboard').setDescription('Top 10 officers by call time')
        .addStringOption((o) =>
          o.setName('period').setDescription('Period').addChoices(
            { name: 'This week', value: 'week' },
            { name: 'All time', value: 'all' },
          )))
    .addSubcommand((s) => s.setName('active').setDescription('Who is On Duty right now'))
    .addSubcommand((s) => s.setName('panel').setDescription('Post the On/Off Duty buttons (command staff)').addChannelOption((o) => h.channelOpt(o, 'Where to post the panel (default: here)')))
    .addSubcommand((s) => s.setName('inactive').setDescription('Officers below the weekly quota (command staff)'))
    .addSubcommand((s) =>
      s.setName('adjust').setDescription('Add or remove call minutes (command staff)')
        .addUserOption((o) => o.setName('officer').setDescription('Which officer').setRequired(true))
        .addIntegerOption((o) => o.setName('minutes').setDescription('Minutes to add (negative to remove)').setRequired(true).setMinValue(-600).setMaxValue(600))
        .addStringOption((o) => o.setName('reason').setDescription('Reason').setMaxLength(200)))
    .addSubcommand((s) =>
      s.setName('forceoff').setDescription('Force an officer Off Duty (command staff)')
        .addUserOption((o) => o.setName('officer').setDescription('Which officer').setRequired(true)))
    .addSubcommand((s) => s.setName('resetweek').setDescription('Reset everyone\'s weekly time to 0 (command staff)')),

  async execute(i) {
    const sub = i.options.getSubcommand();

    if (sub === 'on' || sub === 'off') {
      if (!h.isOfficer(i.member)) return h.deny(i, 'Μόνο οι αστυνομικοί της ΕΛ.ΑΣ. μπορούν να αναλάβουν υπηρεσία.');
      await i.deferReply({ flags: h.EPH });
      return i.editReply(sub === 'on' ? await duty.goOn(i.member) : await duty.goOff(i.member));
    }

    if (sub === 'time') {
      const m = i.options.getMember('officer') ?? i.member;
      const r = db.get().duty[m.id];
      if (!r) return i.reply({ content: `Ο/Η ${m} δεν έχει καταγεγραμμένο χρόνο ακόμα.`, flags: h.EPH });
      const quota = h.setting('weeklyQuotaMinutes') * 60000;
      const wk = duty.weekMs(m.id);
      const e = h.baseEmbed().setTitle(`🎧 Χρόνος σε κλήση – ${m.displayName}`).addFields(
        { name: 'Κατάσταση', value: r.onDuty ? (duty.inCall(m.id) ? `🟢 On Duty • 🎧 σε κλήση (<#${duty.callChannel(m.id)}>)` : '🟢 On Duty') : '⚫ Off Duty', inline: false },
        { name: 'Αυτή την εβδομάδα', value: quota ? `${h.fmtDuration(wk)} / ${h.fmtDuration(quota)}\n${bar((wk / quota) * 100)}` : h.fmtDuration(wk), inline: false },
        { name: 'Συνολικά', value: h.fmtDuration(duty.totalMs(m.id)), inline: true },
        { name: 'Κλήσεις', value: String(r.calls), inline: true },
        { name: 'Αποστολές', value: String(r.events || 0), inline: true },
      );
      return i.reply({ embeds: [e], flags: h.EPH });
    }

    if (sub === 'leaderboard') {
      const period = i.options.getString('period') ?? 'week';
      const ms = (id) => (period === 'week' ? duty.weekMs(id) : duty.totalMs(id));
      const rows = Object.entries(db.get().duty).map(([id, r]) => ({ id, name: r.name, ms: ms(id) })).filter((r) => r.ms > 0)
        .sort((a, b) => b.ms - a.ms).slice(0, 10);
      const quota = h.setting('weeklyQuotaMinutes') * 60000;
      const medals = ['🥇', '🥈', '🥉'];
      const text = rows.length
        ? rows.map((r, n) => `${medals[n] ?? `**${n + 1}.**`} <@${r.id}> — **${h.fmtDuration(r.ms)}**${period === 'week' && quota ? (r.ms >= quota ? ' ✅' : ' ❌') : ''}`).join('\n')
        : 'Δεν υπάρχει καταγεγραμμένος χρόνος ακόμα.';
      return i.reply({ embeds: [h.baseEmbed().setTitle(`🏆 Κατάταξη κλήσεων – ${period === 'week' ? 'Αυτή την εβδομάδα' : 'Συνολικά'}`).setDescription(text)], allowedMentions: { parse: [] } });
    }

    if (sub === 'active') {
      const rows = Object.entries(db.get().duty).filter(([, r]) => r.onDuty);
      const text = rows.length
        ? rows.map(([id]) => `${duty.inCall(id) ? '🎧' : '🟢'} <@${id}>${duty.inCall(id) ? ` — <#${duty.callChannel(id)}>` : ''}`).join('\n')
        : 'Κανείς δεν είναι On Duty αυτή τη στιγμή.';
      return i.reply({ embeds: [h.baseEmbed().setTitle(`🚔 On Duty τώρα (${rows.length})`).setDescription(text)], allowedMentions: { parse: [] } });
    }

    if (['inactive', 'adjust', 'forceoff', 'resetweek'].includes(sub)) {
      if (!h.isCommand(i.member)) return h.deny(i, 'Μόνο η Διοίκηση μπορεί να το κάνει αυτό.');

      if (sub === 'inactive') {
        await i.deferReply({ flags: h.EPH });
        const quota = h.setting('weeklyQuotaMinutes') * 60000;
        const members = await i.guild.members.fetch();
        const rows = members.filter((m) => !m.user.bot && h.isStaff(m) && duty.weekMs(m.id) < quota)
          .map((m) => ({ m, ms: duty.weekMs(m.id) })).sort((a, b) => a.ms - b.ms);
        const text = rows.length ? rows.slice(0, 40).map((r) => `❌ ${r.m} — **${h.fmtDuration(r.ms)}** / ${h.fmtDuration(quota)}`).join('\n') : '✅ Όλοι πέτυχαν τον εβδομαδιαίο στόχο.';
        return i.editReply({ embeds: [h.baseEmbed().setTitle(`📉 Κάτω από τον στόχο (${rows.length})`).setDescription(h.cut(text, 4000))], allowedMentions: { parse: [] } });
      }
      if (sub === 'adjust') {
        const m = i.options.getMember('officer');
        if (!m) return h.deny(i, 'Ο χρήστης δεν βρίσκεται στον server.');
        const mins = i.options.getInteger('minutes');
        const r = duty.rec(m.id, m.displayName);
        r.callMs = Math.max(0, r.callMs + mins * 60000);
        r.week.ms = Math.max(0, r.week.ms + mins * 60000);
        db.save();
        await h.sendTo(i.guild, 'dutyLog', { embeds: [h.baseEmbed().setColor(0x3498db).setDescription(`🛠️ Ο/Η ${i.member} ${mins >= 0 ? 'πρόσθεσε' : 'αφαίρεσε'} **${Math.abs(mins)}λ** ${mins >= 0 ? 'στον/στην' : 'από τον/την'} ${m}.\nΛόγος: ${i.options.getString('reason') ?? '—'}`)] });
        return i.reply({ content: `✅ Ενημερώθηκε ο χρόνος του/της ${m}: εβδομάδα **${h.fmtDuration(r.week.ms)}**, σύνολο **${h.fmtDuration(r.callMs)}**.`, flags: h.EPH });
      }
      if (sub === 'forceoff') {
        const m = i.options.getMember('officer');
        if (!m) return h.deny(i, 'Ο χρήστης δεν βρίσκεται στον server.');
        await i.deferReply({ flags: h.EPH });
        return i.editReply(`${m}: ${await duty.goOff(m)}`);
      }
      // resetweek
      for (const r of Object.values(db.get().duty)) r.week = { key: duty.weekKey(), ms: 0 };
      db.save();
      return i.reply({ content: '✅ Ο εβδομαδιαίος χρόνος όλων μηδενίστηκε.', flags: h.EPH });
    }

    if (sub === 'panel') {
      if (!h.isCommand(i.member)) return h.deny(i, 'Μόνο η Διοίκηση μπορεί να δημοσιεύσει το πάνελ.');
      const target = i.options.getChannel('channel') ?? i.channel;
      await target.send(panel());
      return i.reply({ content: `✅ Το πάνελ δημοσιεύτηκε στο ${target}.`, flags: h.EPH });
    }
  },

  async button(i, [action]) {
    if (!h.isOfficer(i.member)) return h.deny(i, 'Μόνο οι αστυνομικοί της ΕΛ.ΑΣ. μπορούν να το χρησιμοποιήσουν.');
    await i.deferReply({ flags: h.EPH });
    return i.editReply(action === 'on' ? await duty.goOn(i.member) : await duty.goOff(i.member));
  },
};
