const { SlashCommandBuilder } = require('discord.js');
const config = require('../config');
const db = require('../utils/db');
const h = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('discipline')
    .setDescription('Warnings and disciplinary record (command staff)')
    .addSubcommand((s) =>
      s.setName('warn').setDescription('Give a member a warning')
        .addUserOption((o) => o.setName('member').setDescription('Who').setRequired(true))
        .addStringOption((o) => o.setName('reason').setDescription('Reason').setRequired(true).setMaxLength(500)))
    .addSubcommand((s) =>
      s.setName('history').setDescription('Show a member\'s warnings')
        .addUserOption((o) => o.setName('member').setDescription('Who').setRequired(true)))
    .addSubcommand((s) =>
      s.setName('remove').setDescription('Remove a warning')
        .addUserOption((o) => o.setName('member').setDescription('Who').setRequired(true))
        .addIntegerOption((o) => o.setName('number').setDescription('Warning number (see history)').setRequired(true).setMinValue(1))),

  async execute(i) {
    if (!h.isCommand(i.member)) return h.deny(i, 'Μόνο η Διοίκηση έχει πρόσβαση στο πειθαρχικό αρχείο.');
    const d = db.get();
    const sub = i.options.getSubcommand();
    const user = i.options.getUser('member');
    const list = (d.warnings[user.id] ??= []);

    if (sub === 'history') {
      const text = list.length
        ? list.map((w) => `**#${w.id}** — ${h.cut(w.reason, 200)} (<t:${h.unix(w.at)}:d> • από <@${w.by}>)`).join('\n')
        : 'Καθαρό πειθαρχικό αρχείο. ✅';
      return i.reply({ embeds: [h.baseEmbed().setTitle(`⚠️ Προειδοποιήσεις – ${user.username} (${list.length})`).setDescription(h.cut(text, 4000))], flags: h.EPH });
    }

    if (sub === 'remove') {
      const id = i.options.getInteger('number');
      const idx = list.findIndex((w) => w.id === id);
      if (idx === -1) return h.deny(i, 'Δεν βρέθηκε προειδοποίηση με αυτόν τον αριθμό.');
      list.splice(idx, 1);
      db.save();
      await h.sendTo(i.guild, 'staffLog', { embeds: [h.baseEmbed().setTitle('🧹 Αφαίρεση προειδοποίησης').setDescription(`Ο/Η ${i.member} αφαίρεσε την προειδοποίηση **#${id}** του ${user}.`)] });
      return i.reply({ content: `✅ Η προειδοποίηση #${id} αφαιρέθηκε.`, flags: h.EPH });
    }

    // προειδοποίηση
    if (user.bot) return h.deny(i, 'Δεν μπορείς να προειδοποιήσεις bot.');
    if (user.id === i.user.id) return h.deny(i, 'Δεν μπορείς να προειδοποιήσεις τον εαυτό σου.');
    const target = await i.guild.members.fetch(user.id).catch(() => null);
    if (target && !h.isAdmin(i.member) && h.rankIndex(target) >= h.rankIndex(i.member) && h.rankIndex(target) >= 0) {
      return h.deny(i, 'Ο στόχος έχει ίσο ή ανώτερο βαθμό από εσένα.');
    }

    const reason = i.options.getString('reason');
    const w = { id: ++d.counters.warning, reason, by: i.user.id, at: Date.now() };
    list.push(w);
    db.save();

    const embed = h.baseEmbed().setColor(0xe67e22).setTitle(`⚠️ Προειδοποίηση #${w.id}`)
      .setDescription(`${user}`)
      .addFields(
        { name: 'Λόγος', value: reason },
        { name: 'Σύνολο προειδοποιήσεων', value: String(list.length), inline: true },
        { name: 'Από', value: `${i.member}`, inline: true },
      );
    await h.sendTo(i.guild, 'staffLog', { embeds: [embed] });
    const sent = await h.dm(user, { embeds: [embed] });

    let note = '';
    if (list.length >= config.warnThreshold) {
      note = `\n🚨 Ο/Η ${user} έχει **${list.length}** προειδοποιήσεις — εξετάστε υποβιβασμό ή αποβολή.`;
    }
    return i.reply({ embeds: [embed], content: `${sent ? '' : '*(Δεν ήταν δυνατή η αποστολή ιδιωτικού μηνύματος.)*'}${note}` || undefined });
  },
};
