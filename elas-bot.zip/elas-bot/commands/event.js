const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config');
const db = require('../utils/db');
const h = require('../utils/helpers');
const { rec } = require('../utils/duty');

const DANGER = {
  low: { label: '🟢 Χαμηλή', color: 0x2ecc71 },
  medium: { label: '🟡 Μέτρια', color: 0xf1c40f },
  high: { label: '🟠 Υψηλή', color: 0xe67e22 },
  extreme: { label: '🔴 Ακραία', color: 0xe74c3c },
};
const STATUS = {
  open: '🟢 Δηλώσεις συμμετοχής',
  deployed: '🚀 Σε εξέλιξη',
  completed: '🏁 Ολοκληρώθηκε',
  cancelled: '✖️ Ακυρώθηκε',
};

function eventEmbed(m) {
  const team = m.members.length ? m.members.map((id, n) => `${n + 1}. <@${id}>`).join('\n') : '*Κανείς ακόμα*';
  const e = h.baseEmbed()
    .setColor(DANGER[m.danger].color)
    .setTitle(`⚔️ Αποστολή #${m.id} — ${m.title}`)
    .addFields(
      { name: '📍 Τοποθεσία', value: m.location, inline: true },
      { name: '☠️ Επικινδυνότητα', value: DANGER[m.danger].label, inline: true },
      { name: '🕐 Ώρα', value: m.time, inline: true },
      { name: '📋 Κατάσταση', value: STATUS[m.status], inline: true },
      { name: '🎖️ Επικεφαλής', value: `<@${m.creator}>`, inline: true },
      { name: `👮 Ομάδα (${m.members.length}/${m.slots})`, value: team },
    );
  if (m.briefing) e.setDescription(m.briefing);
  return e;
}

function buttons(m) {
  const b = (action, label, style) => new ButtonBuilder().setCustomId(`event:${action}:${m.id}`).setLabel(label).setStyle(style);
  if (m.status === 'open') {
    return [new ActionRowBuilder().addComponents(
      b('join', 'Συμμετοχή', ButtonStyle.Success), b('leave', 'Αποχώρηση', ButtonStyle.Secondary),
      b('deploy', 'Εκκίνηση', ButtonStyle.Primary), b('cancel', 'Ακύρωση', ButtonStyle.Danger),
    )];
  }
  if (m.status === 'deployed') {
    return [new ActionRowBuilder().addComponents(
      b('complete', 'Ολοκλήρωση', ButtonStyle.Success), b('cancel', 'Ακύρωση', ButtonStyle.Danger),
    )];
  }
  return [];
}

module.exports = {
  prefix: 'event',
  data: new SlashCommandBuilder()
    .setName('event')
    .setDescription('Missions and events outside the safe zone')
    .addSubcommand((s) =>
      s.setName('create').setDescription('Create an event with sign-up buttons')
        .addStringOption((o) => o.setName('title').setDescription('e.g. Supply run – Pharmacy').setRequired(true).setMaxLength(100))
        .addStringOption((o) => o.setName('location').setDescription('Where are you going?').setRequired(true).setMaxLength(100))
        .addStringOption((o) =>
          o.setName('danger').setDescription('Danger level').setRequired(true).addChoices(
            { name: '🟢 Low', value: 'low' }, { name: '🟡 Medium', value: 'medium' },
            { name: '🟠 High', value: 'high' }, { name: '🔴 Extreme', value: 'extreme' },
          ))
        .addIntegerOption((o) => o.setName('slots').setDescription('Max team size (default 6)').setMinValue(1).setMaxValue(25))
        .addStringOption((o) => o.setName('time').setDescription('When? e.g. 21:00 or in 30 minutes').setMaxLength(50))
        .addStringOption((o) => o.setName('briefing').setDescription('Objective / what to bring').setMaxLength(1000))
        .addBooleanOption((o) => o.setName('ping').setDescription('Ping the mission notification role?'))
        .addChannelOption((o) => h.channelOpt(o, 'Post the event in this channel')))
    .addSubcommand((s) => s.setName('list').setDescription('Show active events')),

  async execute(i) {
    if (!h.isOfficer(i.member)) return h.deny(i, 'Μόνο οι αστυνομικοί της ΕΛ.ΑΣ. έχουν πρόσβαση στις αποστολές.');
    const d = db.get();

    if (i.options.getSubcommand() === 'list') {
      const active = Object.values(d.events).filter((m) => ['open', 'deployed'].includes(m.status));
      if (!active.length) return i.reply({ content: 'Δεν υπάρχουν ενεργές αποστολές.', flags: h.EPH });
      const lines = active.map((m) => `**#${m.id}** [${m.title}](https://discord.com/channels/${i.guildId}/${m.channelId}/${m.messageId}) — ${STATUS[m.status]} • ${m.members.length}/${m.slots}`);
      return i.reply({ embeds: [h.baseEmbed().setTitle('⚔️ Ενεργές Αποστολές').setDescription(lines.join('\n'))], flags: h.EPH });
    }

    const ch = i.options.getChannel('channel') ?? await h.getChannel(i.guild, 'events');
    if (!ch) return h.deny(i, 'Δεν βρέθηκε το κανάλι αποστολών. Τρέξε πρώτα `/config`.');

    const id = ++d.counters.event;
    const m = {
      id, title: i.options.getString('title'), location: i.options.getString('location'),
      danger: i.options.getString('danger'), slots: i.options.getInteger('slots') ?? 6,
      time: i.options.getString('time') ?? 'Άμεσα', briefing: i.options.getString('briefing'),
      creator: i.user.id, status: 'open', members: [i.user.id], channelId: ch.id, messageId: null,
    };
    const role = i.options.getBoolean('ping') ? h.roleFor(i.guild, 'eventPing') : null;
    const msg = await ch.send({
      content: role ? `${role}` : undefined, embeds: [eventEmbed(m)], components: buttons(m),
      allowedMentions: { roles: role ? [role.id] : [] },
    });
    m.messageId = msg.id;
    d.events[id] = m;
    db.save();
    await i.reply({ content: `✅ Η αποστολή #${id} δημοσιεύτηκε στο ${ch}.`, flags: h.EPH });
  },

  async button(i, [action, id]) {
    const m = db.get().events[id];
    if (!m) return h.deny(i, 'Η αποστολή δεν υπάρχει πια.');

    if (action === 'join' || action === 'leave') {
      if (!h.isOfficer(i.member)) return h.deny(i, 'Μόνο αστυνομικοί μπορούν να συμμετέχουν.');
      if (m.status !== 'open') return h.deny(i, 'Η αποστολή δεν δέχεται πια συμμετοχές.');
      const has = m.members.includes(i.user.id);
      if (action === 'join') {
        if (has) return h.deny(i, 'Είσαι ήδη στην ομάδα.');
        if (m.members.length >= m.slots) return h.deny(i, 'Η ομάδα είναι πλήρης.');
        m.members.push(i.user.id);
      } else {
        if (!has) return h.deny(i, 'Δεν είσαι στην ομάδα.');
        m.members = m.members.filter((x) => x !== i.user.id);
      }
    } else {
      if (m.creator !== i.user.id && !h.isCommand(i.member)) return h.deny(i, 'Μόνο ο επικεφαλής ή η Διοίκηση μπορεί να το κάνει αυτό.');
      if (action === 'deploy' && m.status === 'open') m.status = 'deployed';
      else if (action === 'complete' && m.status === 'deployed') m.status = 'completed';
      else if (action === 'cancel' && ['open', 'deployed'].includes(m.status)) m.status = 'cancelled';
      else return h.deny(i, 'Αυτή η ενέργεια δεν είναι διαθέσιμη τώρα.');
    }
    if (action === 'complete') for (const uid of m.members) rec(uid).events++;
    db.save();
    await i.update({ embeds: [eventEmbed(m)], components: buttons(m) });

    const pings = m.members.map((x) => `<@${x}>`).join(' ');
    if (action === 'deploy') await i.channel?.send(`🚀 **Η αποστολή #${m.id} ξεκινά!** ${pings}\nΜπείτε στο φωνητικό **Αποστολές** και μείνετε μαζί.`).catch(() => {});
    if (action === 'complete') await i.channel?.send(`🏁 **Η αποστολή #${m.id} ολοκληρώθηκε!** Μπράβο ${pings}.\nΥποβάλετε \`/report\` για την αποστολή.`).catch(() => {});
  },
};
