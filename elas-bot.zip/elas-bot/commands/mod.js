const { SlashCommandBuilder, ChannelType, PermissionFlagsBits: P } = require('discord.js');
const config = require('../config');
const db = require('../utils/db');
const duty = require('../utils/duty');
const h = require('../utils/helpers');
const sec = require('../utils/security');

const log = (i, title, color, target, fields = []) =>
  sec.logSec(i.guild, { color, title, description: `${target}`, fields: [...fields, { name: 'Από', value: `${i.member}`, inline: true }], channelKey: 'modLog' });

// Safety checks before acting on a member
function guard(i, target) {
  if (!target) return 'Ο χρήστης δεν βρίσκεται στον server.';
  if (target.id === i.user.id) return 'Δεν μπορείς να το κάνεις στον εαυτό σου.';
  if (target.id === i.guild.ownerId) return 'Δεν μπορείς να το κάνεις στον ιδιοκτήτη του server.';
  if (target.id === i.client.user.id) return 'Δεν μπορείς να το κάνεις στο bot.';
  if (!h.isAdmin(i.member)) {
    if (h.isAdmin(target)) return 'Ο στόχος είναι διαχειριστής.';
    if (h.rankIndex(target) >= 0 && h.rankIndex(target) >= h.rankIndex(i.member)) return 'Ο στόχος έχει ίσο ή ανώτερο βαθμό από εσένα.';
  }
  return null;
}

const member = (o) => o.setName('member').setDescription('Which member').setRequired(true);
const reason = (o) => o.setName('reason').setDescription('Reason').setMaxLength(300);

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mod')
    .setDescription('Moderation tools (command staff)')
    .addSubcommand((s) =>
      s.setName('timeout').setDescription('Timeout (mute) a member')
        .addUserOption(member)
        .addIntegerOption((o) => o.setName('minutes').setDescription('Duration in minutes (max 40320 = 28 days)').setRequired(true).setMinValue(1).setMaxValue(40320))
        .addStringOption(reason))
    .addSubcommand((s) => s.setName('untimeout').setDescription('Remove a timeout').addUserOption(member))
    .addSubcommand((s) => s.setName('kick').setDescription('Kick a member').addUserOption(member).addStringOption(reason))
    .addSubcommand((s) =>
      s.setName('ban').setDescription('Ban a user (optionally delete their recent messages)')
        .addUserOption((o) => o.setName('user').setDescription('Which user').setRequired(true))
        .addStringOption(reason)
        .addIntegerOption((o) => o.setName('delete_days').setDescription('Delete their messages from the last N days (0-7)').setMinValue(0).setMaxValue(7)))
    .addSubcommand((s) =>
      s.setName('unban').setDescription('Unban a user by ID')
        .addStringOption((o) => o.setName('user_id').setDescription('The user ID').setRequired(true))
        .addStringOption(reason))
    .addSubcommand((s) =>
      s.setName('clear').setDescription('Bulk-delete recent messages in this channel')
        .addIntegerOption((o) => o.setName('amount').setDescription('How many messages (1-100)').setRequired(true).setMinValue(1).setMaxValue(100))
        .addUserOption((o) => o.setName('member').setDescription('Only delete messages from this member')))
    .addSubcommand((s) =>
      s.setName('purge').setDescription('Delete a member\'s recent messages in ALL channels')
        .addUserOption((o) => o.setName('user').setDescription('Whose messages').setRequired(true))
        .addIntegerOption((o) => o.setName('hours').setDescription('Look back N hours (1-336, default 24)').setMinValue(1).setMaxValue(336)))
    .addSubcommand((s) =>
      s.setName('slowmode').setDescription('Set slowmode in this channel')
        .addIntegerOption((o) => o.setName('seconds').setDescription('0 = off (max 21600)').setRequired(true).setMinValue(0).setMaxValue(21600)))
    .addSubcommand((s) => s.setName('lock').setDescription('Lock this channel (nobody can write)').addStringOption(reason))
    .addSubcommand((s) => s.setName('unlock').setDescription('Unlock this channel'))
    .addSubcommand((s) =>
      s.setName('nick').setDescription('Change or reset a member\'s nickname')
        .addUserOption(member)
        .addStringOption((o) => o.setName('nickname').setDescription('New nickname (empty = reset)').setMaxLength(32)))
    .addSubcommand((s) =>
      s.setName('role_add').setDescription('Give a (non-rank) role to a member')
        .addUserOption(member).addRoleOption((o) => o.setName('role').setDescription('Which role').setRequired(true)))
    .addSubcommand((s) =>
      s.setName('role_remove').setDescription('Remove a (non-rank) role from a member')
        .addUserOption(member).addRoleOption((o) => o.setName('role').setDescription('Which role').setRequired(true)))
    .addSubcommand((s) => s.setName('vkick').setDescription('Disconnect a member from voice').addUserOption(member))
    .addSubcommand((s) =>
      s.setName('quarantine').setDescription('Strip all roles + long timeout (roles are saved)').addUserOption(member).addStringOption(reason))
    .addSubcommand((s) => s.setName('unquarantine').setDescription('Restore roles and lift the quarantine').addUserOption(member))
    .addSubcommand((s) =>
      s.setName('note').setDescription('Add a private staff note about a user')
        .addUserOption((o) => o.setName('user').setDescription('Which user').setRequired(true))
        .addStringOption((o) => o.setName('text').setDescription('The note').setRequired(true).setMaxLength(500)))
    .addSubcommand((s) =>
      s.setName('notes').setDescription('Show staff notes about a user')
        .addUserOption((o) => o.setName('user').setDescription('Which user').setRequired(true))),

  async execute(i) {
    if (!h.isCommand(i.member)) return h.deny(i, 'Μόνο η Διοίκηση μπορεί να χρησιμοποιήσει αυτές τις εντολές.');
    const sub = i.options.getSubcommand();
    const why = i.options.getString('reason') ?? 'Δεν δόθηκε λόγος';
    const tag = `${why} | από ${i.user.tag}`;

    try {
      if (sub === 'clear') {
        const n = i.options.getInteger('amount');
        const only = i.options.getUser('member');
        await i.deferReply({ flags: h.EPH });
        let msgs = await i.channel.messages.fetch({ limit: 100 });
        if (only) msgs = msgs.filter((m) => m.author.id === only.id);
        const done = await i.channel.bulkDelete([...msgs.values()].slice(0, n), true);
        await log(i, '🧹 Καθαρισμός', 0x95a5a6, `${i.channel}`, [{ name: 'Μηνύματα', value: `${done.size}${only ? ` (από ${only})` : ''}`, inline: true }]);
        return i.editReply(`🧹 Διαγράφηκαν **${done.size}** μηνύματα (τα παλαιότερα των 14 ημερών δεν διαγράφονται).`);
      }

      if (sub === 'purge') {
        const user = i.options.getUser('user');
        const hours = i.options.getInteger('hours') ?? 24;
        await i.deferReply({ flags: h.EPH });
        const since = Date.now() - hours * 3600000;
        let total = 0;
        for (const ch of i.guild.channels.cache.values()) {
          if (![ChannelType.GuildText, ChannelType.GuildAnnouncement, ChannelType.GuildVoice].includes(ch.type)) continue;
          if (!ch.viewable || !ch.permissionsFor(i.guild.members.me)?.has(P.ManageMessages)) continue;
          const msgs = (await ch.messages.fetch({ limit: 100 }).catch(() => null))?.filter((m) => m.author.id === user.id && m.createdTimestamp > since);
          if (msgs?.size) { const d = await ch.bulkDelete([...msgs.values()], true).catch(() => null); total += d?.size ?? 0; }
        }
        await log(i, '🧹 Purge μελούς', 0x95a5a6, `${user}`, [{ name: 'Μηνύματα', value: `${total} (τελευταίες ${hours} ώρες)`, inline: true }]);
        return i.editReply(`🧹 Διαγράφηκαν **${total}** μηνύματα του/της ${user} από όλα τα κανάλια.`);
      }

      if (sub === 'slowmode') {
        const s = i.options.getInteger('seconds');
        await i.channel.setRateLimitPerUser(s, tag);
        await log(i, '🐌 Slowmode', 0x3498db, `${i.channel}`, [{ name: 'Δευτερόλεπτα', value: String(s), inline: true }]);
        return i.reply({ content: s ? `🐌 Slowmode **${s}δ** στο κανάλι.` : '✅ Το slowmode απενεργοποιήθηκε.', flags: h.EPH });
      }

      if (sub === 'lock' || sub === 'unlock') {
        const lock = sub === 'lock';
        await i.channel.permissionOverwrites.edit(i.guild.roles.everyone, { SendMessages: lock ? false : null, AddReactions: lock ? false : null }, { reason: tag });
        await log(i, lock ? '🔒 Κλείδωμα καναλιού' : '🔓 Ξεκλείδωμα καναλιού', lock ? 0xe67e22 : 0x2ecc71, `${i.channel}`, lock ? [{ name: 'Λόγος', value: why }] : []);
        return i.reply({ content: lock ? '🔒 Το κανάλι κλειδώθηκε.' : '🔓 Το κανάλι ξεκλειδώθηκε.' });
      }

      if (sub === 'unban') {
        const id = i.options.getString('user_id').trim();
        await i.guild.members.unban(id, tag);
        await log(i, '🔓 Άρση αποκλεισμού', 0x2ecc71, `<@${id}> (${id})`, [{ name: 'Λόγος', value: why }]);
        return i.reply({ content: `✅ Ο αποκλεισμός του \`${id}\` άρθηκε.`, flags: h.EPH });
      }

      if (sub === 'ban') {
        const user = i.options.getUser('user');
        const days = i.options.getInteger('delete_days') ?? 0;
        const target = await i.guild.members.fetch(user.id).catch(() => null);
        if (target) {
          const err = guard(i, target);
          if (err) return h.deny(i, err);
          if (!target.bannable) return h.deny(i, 'Δεν μπορώ να αποκλείσω αυτόν τον χρήστη (ο ρόλος του είναι πάνω από τον δικό μου).');
          await h.dm(user, { content: `🔨 Αποκλείστηκες από τον **${i.guild.name}**.\nΛόγος: ${why}` });
        }
        await i.guild.members.ban(user.id, { reason: tag, deleteMessageSeconds: days * 86400 });
        await log(i, '🔨 Αποκλεισμός', 0xc0392b, `${user} (${user.id})`, [{ name: 'Λόγος', value: why }, { name: 'Διαγραφή μηνυμάτων', value: `${days} ημέρες`, inline: true }]);
        return i.reply({ content: `🔨 Ο/Η **${user.tag}** αποκλείστηκε.`, flags: h.EPH });
      }

      if (sub === 'note' || sub === 'notes') {
        const u = i.options.getUser('user');
        const list = (db.get().notes[u.id] ??= []);
        if (sub === 'note') {
          list.push({ by: i.user.id, text: i.options.getString('text'), at: Date.now() });
          db.save();
          await log(i, '📝 Σημείωση προσωπικού', 0x95a5a6, `${u}`, [{ name: 'Σημείωση', value: i.options.getString('text') }]);
          return i.reply({ content: `✅ Η σημείωση για τον/την ${u} αποθηκεύτηκε (σύνολο ${list.length}).`, flags: h.EPH });
        }
        const text = list.slice(-10).reverse().map((n) => `<t:${h.unix(n.at)}:d> • <@${n.by}>: ${h.cut(n.text, 200)}`).join('\n') || 'Δεν υπάρχουν σημειώσεις.';
        return i.reply({ embeds: [h.baseEmbed().setTitle(`📝 Σημειώσεις – ${u.username} (${list.length})`).setDescription(text)], flags: h.EPH, allowedMentions: { parse: [] } });
      }

      const target = i.options.getMember('member');
      const err = guard(i, target);
      if (err) return h.deny(i, err);

      if (sub === 'nick') {
        if (!target.manageable) return h.deny(i, 'Δεν μπορώ να αλλάξω το ψευδώνυμο αυτού του μέλους.');
        const nick = i.options.getString('nickname');
        await target.setNickname(nick || null, tag);
        await log(i, '✏️ Αλλαγή ψευδωνύμου', 0x3498db, target, [{ name: 'Νέο', value: nick || '(επαναφορά)', inline: true }]);
        return i.reply({ content: nick ? `✅ Νέο ψευδώνυμο: **${nick}**.` : '✅ Το ψευδώνυμο επανήλθε.', flags: h.EPH });
      }

      if (sub === 'role_add' || sub === 'role_remove') {
        const role = i.options.getRole('role');
        if (h.protectedRoleIds(i.guild).has(role.id)) return h.deny(i, 'Οι ρόλοι βαθμών και υπηρεσίας αλλάζουν μόνο με `/promote`, `/demote` και `/duty`.');
        if (role.managed || role.id === i.guild.id) return h.deny(i, 'Αυτός ο ρόλος δεν μπορεί να δοθεί χειροκίνητα.');
        if (role.permissions.has('Administrator') && !h.isAdmin(i.member)) return h.deny(i, 'Μόνο διαχειριστές δίνουν ρόλους με Administrator.');
        if (role.position >= i.guild.members.me.roles.highest.position) return h.deny(i, 'Ο ρόλος είναι πάνω από τον ρόλο του bot.');
        if (!h.isAdmin(i.member) && role.position >= i.member.roles.highest.position) return h.deny(i, 'Ο ρόλος είναι ίσος ή πάνω από τον δικό σου.');
        if (sub === 'role_add') await target.roles.add(role, tag); else await target.roles.remove(role, tag);
        await log(i, sub === 'role_add' ? '➕ Ρόλος δόθηκε' : '➖ Ρόλος αφαιρέθηκε', 0x3498db, target, [{ name: 'Ρόλος', value: role.name, inline: true }]);
        return i.reply({ content: `✅ ${sub === 'role_add' ? 'Δόθηκε' : 'Αφαιρέθηκε'} ο ρόλος **${role.name}** ${sub === 'role_add' ? 'στον/στην' : 'από τον/την'} ${target}.`, flags: h.EPH });
      }

      if (sub === 'vkick') {
        if (!target.voice.channelId) return h.deny(i, 'Το μέλος δεν είναι σε φωνητικό κανάλι.');
        await target.voice.disconnect(tag);
        await log(i, '🔇 Αποσύνδεση από φωνητικό', 0xe67e22, target);
        return i.reply({ content: `✅ Ο/Η ${target} αποσυνδέθηκε από το φωνητικό.`, flags: h.EPH });
      }

      if (sub === 'quarantine') {
        const d = db.get();
        if (d.quarantine[target.id]) return h.deny(i, 'Το μέλος είναι ήδη σε καραντίνα.');
        await duty.forceOff(target.id, i.guild);
        const roles = target.roles.cache.filter((r) => !r.managed && r.id !== i.guild.id);
        d.quarantine[target.id] = { roles: [...roles.keys()], at: Date.now(), by: i.user.id };
        db.save();
        await target.roles.remove([...roles.values()], tag).catch(() => {});
        if (target.moderatable) await target.timeout(27 * 24 * 3600000, tag).catch(() => {});
        if (target.voice.channelId) await target.voice.disconnect(tag).catch(() => {});
        await h.dm(target.user, { content: `🧪 Μπήκες σε **καραντίνα** στον **${i.guild.name}**.\nΛόγος: ${why}` });
        await log(i, '🧪 Καραντίνα', 0xc0392b, target, [{ name: 'Ρόλοι που αποθηκεύτηκαν', value: String(roles.size), inline: true }, { name: 'Λόγος', value: why }]);
        return i.reply({ content: `🧪 Ο/Η ${target} μπήκε σε καραντίνα (**${roles.size}** ρόλοι αποθηκεύτηκαν). Επαναφορά: \`/mod unquarantine\`.`, flags: h.EPH });
      }
      if (sub === 'unquarantine') {
        const d = db.get();
        const q = d.quarantine[target.id];
        if (!q) return h.deny(i, 'Το μέλος δεν είναι σε καραντίνα.');
        const roles = q.roles.map((id) => i.guild.roles.cache.get(id)).filter((r) => r && r.position < i.guild.members.me.roles.highest.position);
        await target.roles.add(roles, `Άρση καραντίνας από ${i.user.tag}`).catch(() => {});
        await target.timeout(null, `Άρση καραντίνας από ${i.user.tag}`).catch(() => {});
        delete d.quarantine[target.id];
        db.save();
        await log(i, '✅ Άρση καραντίνας', 0x2ecc71, target, [{ name: 'Ρόλοι που επανήλθαν', value: String(roles.length), inline: true }]);
        return i.reply({ content: `✅ Ο/Η ${target} βγήκε από την καραντίνα (**${roles.length}** ρόλοι επανήλθαν).`, flags: h.EPH });
      }

      if (sub === 'timeout') {
        if (!target.moderatable) return h.deny(i, 'Δεν μπορώ να κάνω σίγαση σε αυτό το μέλος.');
        const mins = i.options.getInteger('minutes');
        await h.dm(target.user, { content: `🔇 Σου έγινε σίγαση στον **${i.guild.name}** για ${mins} λεπτά.\nΛόγος: ${why}` });
        await target.timeout(mins * 60000, tag);
        await log(i, '🔇 Σίγαση', 0xf1c40f, target, [{ name: 'Διάρκεια', value: `${mins} λεπτά`, inline: true }, { name: 'Λόγος', value: why }]);
        return i.reply({ content: `🔇 Ο/Η ${target} σιγάστηκε για **${mins}** λεπτά.`, flags: h.EPH });
      }
      if (sub === 'untimeout') {
        await target.timeout(null, `Άρση σίγασης από ${i.user.tag}`);
        await log(i, '🔊 Άρση σίγασης', 0x2ecc71, target);
        return i.reply({ content: `🔊 Η σίγαση του/της ${target} άρθηκε.`, flags: h.EPH });
      }
      if (sub === 'kick') {
        if (!target.kickable) return h.deny(i, 'Δεν μπορώ να αποβάλω αυτό το μέλος.');
        await h.dm(target.user, { content: `👢 Αποβλήθηκες από τον **${i.guild.name}**.\nΛόγος: ${why}` });
        await target.kick(tag);
        await log(i, '👢 Αποβολή', 0xe67e22, target.user, [{ name: 'Λόγος', value: why }]);
        return i.reply({ content: `👢 Ο/Η **${target.user.tag}** αποβλήθηκε.`, flags: h.EPH });
      }
    } catch (e) {
      console.error(e);
      const msg = '⚠️ Η ενέργεια απέτυχε. Έλεγξε τα δικαιώματα και τη θέση του ρόλου του bot.';
      return i.replied || i.deferred ? i.followUp({ content: msg, flags: h.EPH }) : i.reply({ content: msg, flags: h.EPH });
    }
  },
};
