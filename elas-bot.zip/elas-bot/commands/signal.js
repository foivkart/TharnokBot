const { SlashCommandBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
const config = require('../config');
const db = require('../utils/db');
const h = require('../utils/helpers');
const sig = require('../utils/signals');
const { withBanner } = require('../utils/panelart');

// Posts the header + one board per range and remembers the message ids
async function postBoards(channel) {
  const s = sig.S();
  for (const b of [...s.boards, ...(s.header ? [s.header] : [])]) {
    const ch = await channel.guild.channels.fetch(b.channelId).catch(() => null);
    await ch?.messages.delete(b.messageId).catch(() => {});
  }
  s.boards = [];
  const head = await channel.send(withBanner({
    embeds: [h.baseEmbed().setColor(config.signals.color).setTitle('📻 Επιλογή Σήματος (Callsign)')
      .setDescription('Πάτησε **Επιλογή σήματος** κάτω από τον σωστό πίνακα, γράψε τον αριθμό που θέλεις και (προαιρετικά) τον κωδικό μονάδας **xx**.\nΤο ψευδώνυμό σου θα γίνει **[xx-αριθμός] Όνομα**. Ένα σήμα ανά αστυνομικό.')],
  }, 'signals'));
  s.header = { channelId: channel.id, messageId: head.id };
  for (let idx = 0; idx < sig.ranges().length; idx++) {
    const msg = await channel.send({ embeds: [sig.boardEmbed(idx)], components: sig.boardButtons(idx) });
    s.boards.push({ channelId: channel.id, messageId: msg.id, range: idx });
  }
  db.save();
  return s.boards.length;
}

const num = (o) => o.setName('number').setDescription('Signal number (1-200)').setRequired(true).setMinValue(1).setMaxValue(999);
const member = (o) => o.setName('member').setDescription('Which member').setRequired(true);

module.exports = {
  prefix: 'signal',
  postBoards,
  data: new SlashCommandBuilder()
    .setName('signal')
    .setDescription('Signal (callsign) boards 1-100 and 101-200')
    .addSubcommand((s) => s.setName('panel').setDescription('Post the signal boards (command staff)').addChannelOption((o) => h.channelOpt(o, 'Where to post the boards (default: here)')))
    .addSubcommand((s) => s.setName('refresh').setDescription('Redraw the boards (command staff)'))
    .addSubcommand((s) =>
      s.setName('assign').setDescription('Give a member a signal (command staff)')
        .addUserOption(member).addIntegerOption(num)
        .addStringOption((o) => o.setName('unit').setDescription('Unit code xx (e.g. 05)').setMaxLength(2)))
    .addSubcommand((s) => s.setName('release').setDescription('Free a member\'s signal (command staff)').addUserOption(member))
    .addSubcommand((s) => s.setName('retire').setDescription('Retire a number so nobody can pick it (command staff)').addIntegerOption(num))
    .addSubcommand((s) => s.setName('unretire').setDescription('Make a retired number available again (command staff)').addIntegerOption(num))
    .addSubcommand((s) =>
      s.setName('lookup').setDescription('Who has this signal? / which signal does this member have?')
        .addIntegerOption((o) => o.setName('number').setDescription('Signal number').setMinValue(1).setMaxValue(999))
        .addUserOption((o) => o.setName('member').setDescription('Member')))
    .addSubcommand((s) => s.setName('stats').setDescription('How many signals are taken / free')),

  async execute(i) {
    const sub = i.options.getSubcommand();
    const S = sig.S();
    const staffOnly = !['lookup', 'stats'].includes(sub);
    if (staffOnly && !h.isCommand(i.member)) return h.deny(i, 'Μόνο η Διοίκηση μπορεί να διαχειριστεί τα σήματα.');
    if (!staffOnly && !h.isOfficer(i.member)) return h.deny(i, 'Μόνο οι αστυνομικοί έχουν πρόσβαση στα σήματα.');

    if (sub === 'panel') {
      await i.deferReply({ flags: h.EPH });
      const target = i.options.getChannel('channel') ?? i.channel;
      const n = await postBoards(target);
      return i.editReply(`✅ Δημοσιεύτηκαν **${n}** πίνακες σημάτων στο ${target}.`);
    }
    if (sub === 'refresh') {
      await i.deferReply({ flags: h.EPH });
      await sig.refreshBoards(i.guild);
      return i.editReply('✅ Οι πίνακες ανανεώθηκαν.');
    }

    if (sub === 'stats') {
      const lines = sig.ranges().map((r) => {
        let t = 0; let x = 0;
        for (let n = r.from; n <= r.to; n++) { if (S.assignments[n]) t++; if (S.retired.includes(n)) x++; }
        return `**${r.from}–${r.to}:** ${t} κατειλημμένα • ${r.to - r.from + 1 - t - x} ελεύθερα${x ? ` • ${x} αποσυρμένα` : ''}`;
      });
      return i.reply({ embeds: [h.baseEmbed().setColor(config.signals.color).setTitle('📻 Στατιστικά σημάτων').setDescription(lines.join('\n'))], flags: h.EPH });
    }

    if (sub === 'lookup') {
      const n = i.options.getInteger('number');
      const u = i.options.getUser('member');
      if (n) {
        const a = S.assignments[n];
        if (S.retired.includes(n)) return i.reply({ content: `✕ Το **${sig.pad3(n)}** είναι αποσυρμένο.`, flags: h.EPH });
        return i.reply({ content: a ? `■ Το **${sig.callsign(n, a.unit)}** το έχει ο/η <@${a.userId}>.` : `✅ Το **${sig.pad3(n)}** είναι ελεύθερο.`, flags: h.EPH, allowedMentions: { parse: [] } });
      }
      const target = u ?? i.user;
      const cs = sig.callsignOf(target.id);
      return i.reply({ content: cs ? `🎫 Ο/Η <@${target.id}> έχει το σήμα **${cs}**.` : `Ο/Η <@${target.id}> δεν έχει σήμα.`, flags: h.EPH, allowedMentions: { parse: [] } });
    }

    if (sub === 'retire' || sub === 'unretire') {
      const n = i.options.getInteger('number');
      if (sig.rangeOf(n) === -1) return h.deny(i, 'Ο αριθμός είναι εκτός των πινάκων (1-200).');
      S.retired = S.retired.filter((x) => x !== n);
      if (sub === 'retire') {
        const a = S.assignments[n];
        if (a) { delete S.assignments[n]; const m = await i.guild.members.fetch(a.userId).catch(() => null); await sig.clearNickname(m); }
        S.retired.push(n);
      }
      db.save();
      await sig.refreshBoards(i.guild);
      await h.sendTo(i.guild, 'staffLog', { embeds: [h.baseEmbed().setDescription(`📻 Ο/Η ${i.member} ${sub === 'retire' ? 'απέσυρε' : 'επανέφερε'} το σήμα **${sig.pad3(n)}**.`)] });
      return i.reply({ content: `✅ Το **${sig.pad3(n)}** ${sub === 'retire' ? 'αποσύρθηκε ✕' : 'είναι ξανά διαθέσιμο'}.`, flags: h.EPH });
    }

    const target = i.options.getMember('member');
    if (!target) return h.deny(i, 'Ο χρήστης δεν βρίσκεται στον server.');

    if (sub === 'release') {
      const n = sig.release(target.id);
      if (n == null) return h.deny(i, 'Το μέλος δεν έχει σήμα.');
      await sig.clearNickname(target);
      await sig.refreshBoards(i.guild);
      await h.sendTo(i.guild, 'staffLog', { embeds: [h.baseEmbed().setDescription(`📻 Ο/Η ${i.member} αποδέσμευσε το σήμα **${sig.pad3(n)}** του/της ${target}.`)] });
      return i.reply({ content: `✅ Το σήμα **${sig.pad3(n)}** του/της ${target} αποδεσμεύτηκε.`, flags: h.EPH });
    }

    // assign
    if (!h.isStaff(target) && !h.isAdmin(target)) return h.deny(i, 'Μόνο αστυνομικοί μπορούν να έχουν σήμα.');
    const n = i.options.getInteger('number');
    const unit = i.options.getString('unit');
    const res = sig.assign(target.id, n, unit ?? h.unitCode(target) ?? sig.S().assignments[sig.numberOf(target.id)]?.unit);
    if (!res.ok) return h.deny(i, res.error === 'taken' ? `Το σήμα το έχει ήδη <@${res.by}>.` : res.error === 'retired' ? 'Το σήμα είναι αποσυρμένο.' : 'Ο αριθμός είναι εκτός των πινάκων (1-200).');
    await sig.applyNickname(target, n, S.assignments[n].unit);
    await sig.refreshBoards(i.guild);
    await h.sendTo(i.guild, 'staffLog', { embeds: [h.baseEmbed().setDescription(`📻 Ο/Η ${i.member} έδωσε το σήμα **${sig.callsign(n, S.assignments[n].unit)}** στον/στην ${target}.`)] });
    return i.reply({ content: `✅ Ο/Η ${target} έχει πλέον το σήμα **${sig.callsign(n, S.assignments[n].unit)}**.`, flags: h.EPH });
  },

  async button(i, [action, idx]) {
    const range = Number(idx);
    if (!h.isOfficer(i.member)) return h.deny(i, 'Μόνο οι αστυνομικοί της ΕΛ.ΑΣ. μπορούν να επιλέξουν σήμα.');

    if (action === 'release') {
      const n = sig.release(i.user.id);
      if (n == null) return h.deny(i, 'Δεν έχεις σήμα για να αποδεσμεύσεις.');
      await sig.clearNickname(i.member);
      await i.reply({ content: `🔓 Αποδέσμευσες το σήμα **${sig.pad3(n)}**.`, flags: h.EPH });
      return sig.refreshBoards(i.guild);
    }

    const { from, to } = sig.ranges()[range];
    const mine = sig.callsignOf(i.user.id);
    return i.showModal(
      new ModalBuilder().setCustomId(`signal:modal:${range}`).setTitle(`Επιλογή σήματος (${from}-${to})`).addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId('number').setLabel(`Αριθμός σήματος (${from}-${to})`).setStyle(TextInputStyle.Short)
            .setRequired(true).setMinLength(1).setMaxLength(3).setPlaceholder(String(from + 41 > to ? from : from + 41))),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId('unit').setLabel('Κωδικός μονάδας xx (προαιρετικό)').setStyle(TextInputStyle.Short)
            .setRequired(false).setMaxLength(2).setPlaceholder(h.unitCode(i.member) ?? (mine ? mine.split('-')[0] : String(h.setting('signalsDefaultUnit')).padStart(2, '0')))),
      ),
    );
  },

  async modal(i, [, idx]) {
    const range = Number(idx);
    const { from, to } = sig.ranges()[range];
    if (!h.isOfficer(i.member)) return h.deny(i, 'Μόνο οι αστυνομικοί της ΕΛ.ΑΣ. μπορούν να επιλέξουν σήμα.');
    const n = parseInt(i.fields.getTextInputValue('number').replace(/\D/g, ''), 10);
    if (!Number.isInteger(n) || n < from || n > to) return h.deny(i, `Ο αριθμός πρέπει να είναι από **${from}** έως **${to}** (αυτός ο πίνακας).`);
    const unitRaw = i.fields.getTextInputValue('unit');
    const prev = sig.numberOf(i.user.id);
    const unit = unitRaw?.trim() ? unitRaw : (h.unitCode(i.member) ?? sig.S().assignments[prev]?.unit);
    const res = sig.assign(i.user.id, n, unit);
    if (!res.ok) {
      return h.deny(i, res.error === 'taken' ? `Το σήμα **${sig.pad3(n)}** το έχει ήδη <@${res.by}>.` : res.error === 'retired' ? `Το σήμα **${sig.pad3(n)}** είναι αποσυρμένο ✕.` : 'Μη έγκυρος αριθμός.');
    }
    const a = sig.S().assignments[n];
    const nick = await sig.applyNickname(i.member, n, a.unit);
    await i.reply({
      content: `🎫 Το σήμα σου είναι **${sig.callsign(n, a.unit)}**${res.prev != null && res.prev !== n ? ` (αποδεσμεύτηκε το ${sig.pad3(res.prev)})` : ''}.${nick === 'locked' ? '\n⚠️ Δεν μπόρεσα να αλλάξω το ψευδώνυμό σου — άλλαξέ το χειροκίνητα σε `[' + sig.callsign(n, a.unit) + '] Όνομα`.' : ''}`,
      flags: h.EPH,
    });
    await sig.refreshBoards(i.guild);
  },
};
