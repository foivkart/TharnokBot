const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const db = require('../utils/db');
const h = require('../utils/helpers');
const { rec } = require('../utils/duty');

const STATUS = { open: '🟢 Εγγραφές', running: '🎓 Σε εξέλιξη', done: '🏁 Ολοκληρώθηκε', cancelled: '✖️ Ακυρώθηκε' };

const embed = (t) =>
  h.baseEmbed().setColor(t.status === 'done' ? 0x2ecc71 : 0x9b59b6).setTitle(`🎓 Εκπαίδευση #${t.id} — ${t.title}`)
    .setDescription(t.notes || null)
    .addFields(
      { name: '🕐 Ώρα', value: t.time, inline: true }, { name: '📋 Κατάσταση', value: STATUS[t.status], inline: true },
      { name: '👨‍🏫 Εκπαιδευτής', value: `<@${t.trainer}>`, inline: true },
      { name: `👮 Εκπαιδευόμενοι (${t.members.length}/${t.slots})`, value: t.members.length ? t.members.map((id, n) => `${n + 1}. <@${id}>`).join('\n') : '*Κανείς ακόμα*' },
    );

function buttons(t) {
  const b = (a, l, s) => new ButtonBuilder().setCustomId(`training:${a}:${t.id}`).setLabel(l).setStyle(s);
  if (t.status === 'open') return [new ActionRowBuilder().addComponents(b('join', 'Εγγραφή', ButtonStyle.Success), b('leave', 'Αποχώρηση', ButtonStyle.Secondary), b('start', 'Έναρξη', ButtonStyle.Primary), b('cancel', 'Ακύρωση', ButtonStyle.Danger))];
  if (t.status === 'running') return [new ActionRowBuilder().addComponents(b('done', 'Ολοκλήρωση', ButtonStyle.Success), b('cancel', 'Ακύρωση', ButtonStyle.Danger))];
  return [];
}

module.exports = {
  prefix: 'training',
  data: new SlashCommandBuilder()
    .setName('training')
    .setDescription('Training sessions for officers')
    .addSubcommand((s) =>
      s.setName('schedule').setDescription('Schedule a training session (command staff)')
        .addStringOption((o) => o.setName('title').setDescription('e.g. Firearms basics').setRequired(true).setMaxLength(100))
        .addStringOption((o) => o.setName('time').setDescription('When? e.g. Friday 21:00').setRequired(true).setMaxLength(60))
        .addIntegerOption((o) => o.setName('slots').setDescription('Max trainees (default 10)').setMinValue(1).setMaxValue(50))
        .addStringOption((o) => o.setName('notes').setDescription('What will be covered').setMaxLength(800))
        .addChannelOption((o) => h.channelOpt(o, 'Post the training in this channel')))
    .addSubcommand((s) => s.setName('list').setDescription('Show upcoming trainings'))
    .addSubcommand((s) => s.setName('stats').setDescription('Trainings completed by an officer').addUserOption((o) => o.setName('officer').setDescription('Which officer (default: you)'))),

  async execute(i) {
    if (!h.isOfficer(i.member)) return h.deny(i, 'Μόνο οι αστυνομικοί έχουν πρόσβαση στις εκπαιδεύσεις.');
    const d = db.get();
    const sub = i.options.getSubcommand();
    if (sub === 'list') {
      const act = Object.values(d.trainings).filter((t) => ['open', 'running'].includes(t.status));
      const text = act.map((t) => `**#${t.id}** [${t.title}](https://discord.com/channels/${i.guildId}/${t.channelId}/${t.messageId}) — ${t.time} • ${t.members.length}/${t.slots}`).join('\n') || 'Δεν υπάρχουν προγραμματισμένες εκπαιδεύσεις.';
      return i.reply({ embeds: [h.baseEmbed().setTitle('🎓 Εκπαιδεύσεις').setDescription(text)], flags: h.EPH });
    }
    if (sub === 'stats') {
      const u = i.options.getUser('officer') ?? i.user;
      return i.reply({ content: `🎓 Ο/Η <@${u.id}> έχει ολοκληρώσει **${rec(u.id).trainings || 0}** εκπαιδεύσεις.`, flags: h.EPH, allowedMentions: { parse: [] } });
    }
    if (!h.isCommand(i.member)) return h.deny(i, 'Μόνο η Διοίκηση μπορεί να προγραμματίσει εκπαιδεύσεις.');
    const ch = i.options.getChannel('channel') ?? await h.getChannel(i.guild, 'training');
    if (!ch) return h.deny(i, 'Δεν βρέθηκε το κανάλι εκπαιδεύσεων. Τρέξε `/config`.');
    const t = { id: ++d.counters.training, title: i.options.getString('title'), time: i.options.getString('time'), slots: i.options.getInteger('slots') ?? 10, notes: i.options.getString('notes'), trainer: i.user.id, members: [], status: 'open', channelId: ch.id, messageId: null };
    const msg = await ch.send({ embeds: [embed(t)], components: buttons(t) });
    t.messageId = msg.id; d.trainings[t.id] = t; db.save();
    return i.reply({ content: `✅ Η εκπαίδευση #${t.id} δημοσιεύτηκε στο ${ch}.`, flags: h.EPH });
  },

  async button(i, [action, id]) {
    const t = db.get().trainings[id];
    if (!t) return h.deny(i, 'Η εκπαίδευση δεν υπάρχει πια.');
    if (action === 'join' || action === 'leave') {
      if (!h.isOfficer(i.member)) return h.deny(i, 'Μόνο αστυνομικοί μπορούν να εγγραφούν.');
      if (t.status !== 'open') return h.deny(i, 'Οι εγγραφές έχουν κλείσει.');
      const has = t.members.includes(i.user.id);
      if (action === 'join') { if (has) return h.deny(i, 'Είσαι ήδη εγγεγραμμένος/η.'); if (t.members.length >= t.slots) return h.deny(i, 'Η εκπαίδευση είναι πλήρης.'); t.members.push(i.user.id); }
      else { if (!has) return h.deny(i, 'Δεν είσαι εγγεγραμμένος/η.'); t.members = t.members.filter((x) => x !== i.user.id); }
    } else {
      if (t.trainer !== i.user.id && !h.isCommand(i.member)) return h.deny(i, 'Μόνο ο εκπαιδευτής ή η Διοίκηση μπορεί να το κάνει αυτό.');
      if (action === 'start' && t.status === 'open') t.status = 'running';
      else if (action === 'done' && t.status === 'running') { t.status = 'done'; for (const uid of t.members) { const r = rec(uid); r.trainings = (r.trainings || 0) + 1; } }
      else if (action === 'cancel' && ['open', 'running'].includes(t.status)) t.status = 'cancelled';
      else return h.deny(i, 'Αυτή η ενέργεια δεν είναι διαθέσιμη τώρα.');
    }
    db.save();
    await i.update({ embeds: [embed(t)], components: buttons(t) });
    const pings = t.members.map((x) => `<@${x}>`).join(' ');
    if (action === 'start') await i.channel?.send(`🎓 **Η εκπαίδευση #${t.id} ξεκινά!** ${pings}`).catch(() => {});
    if (action === 'done') await i.channel?.send(`🏁 **Η εκπαίδευση #${t.id} ολοκληρώθηκε!** Συγχαρητήρια ${pings}`).catch(() => {});
  },
};
