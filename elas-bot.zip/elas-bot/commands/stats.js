const { SlashCommandBuilder } = require('discord.js');
const config = require('../config');
const db = require('../utils/db');
const h = require('../utils/helpers');
const duty = require('../utils/duty');

const LEVEL = { green: '🟢 Πράσινο', yellow: '🟡 Κίτρινο', orange: '🟠 Πορτοκαλί', red: '🔴 Κόκκινο' };

module.exports = {
  data: new SlashCommandBuilder().setName('stats').setDescription('Statistics of the ΕΛ.ΑΣ. and the safe zone'),

  async execute(i) {
    await i.deferReply();
    const members = await i.guild.members.fetch();
    const humans = members.filter((m) => !m.user.bot);
    const officers = humans.filter((m) => h.isStaff(m)).size;
    const d = db.get();
    const onDuty = Object.values(d.duty).filter((x) => x.onDuty).length;
    const inCall = Object.keys(d.duty).filter((id) => duty.inCall(id)).length;
    const events = Object.values(d.events).filter((m) => ['open', 'deployed'].includes(m.status)).length;
    const tickets = Object.values(d.tickets).filter((t) => t.status === 'open').length;
    const apps = Object.values(d.applications).filter((a) => ['pending', 'interview'].includes(a.status)).length;
    const e = h.baseEmbed().setTitle(`🛡️ ${config.department} – Στατιστικά`).addFields(
      { name: '👥 Μέλη', value: String(humans.size), inline: true },
      { name: '👮 Αστυνομικοί', value: String(officers), inline: true },
      { name: '🟢 On Duty', value: `${onDuty} (🎧 ${inCall} σε κλήση)`, inline: true },
      { name: '⚠️ Επίπεδο απειλής', value: LEVEL[d.threat.level], inline: true },
      { name: '⚔️ Ενεργές αποστολές', value: String(events), inline: true },
      { name: '📩 Ανοιχτά αιτήματα', value: String(tickets), inline: true },
      { name: '📝 Αιτήσεις σε αναμονή', value: String(apps), inline: true },
    );
    await i.editReply({ embeds: [e] });
  },
};
