const {
  SlashCommandBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder,
  ButtonBuilder, ButtonStyle,
} = require('discord.js');
const db = require('../utils/db');
const h = require('../utils/helpers');

const STATUS = { pending: '🟡 Σε αναμονή', approved: '✅ Εγκρίθηκε', denied: '❌ Απορρίφθηκε' };
const COLOR = { pending: 0xf1c40f, approved: 0x2ecc71, denied: 0xe74c3c };

const input = (id, label, style, max) =>
  new ActionRowBuilder().addComponents(
    new TextInputBuilder().setCustomId(id).setLabel(label).setStyle(style).setRequired(true).setMaxLength(max),
  );

const embed = (l) =>
  h.baseEmbed().setColor(COLOR[l.status]).setTitle(`🏖️ Αίτημα άδειας #${l.id}`)
    .setDescription(`Αιτών/ούσα: <@${l.userId}>`)
    .addFields(
      { name: 'Από', value: l.from, inline: true },
      { name: 'Έως', value: l.to, inline: true },
      { name: 'Κατάσταση', value: STATUS[l.status], inline: true },
      { name: 'Λόγος', value: h.cut(l.reason, 1024) },
    );

const buttons = (l) =>
  l.status !== 'pending' ? [] : [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`leave:approve:${l.id}`).setLabel('Έγκριση').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`leave:deny:${l.id}`).setLabel('Απόρριψη').setStyle(ButtonStyle.Danger),
  )];

module.exports = {
  prefix: 'leave',
  data: new SlashCommandBuilder().setName('loa').setDescription('Request a leave of absence (officers)'),

  async execute(i) {
    if (!h.isOfficer(i.member)) return h.deny(i, 'Μόνο οι αστυνομικοί μπορούν να ζητήσουν άδεια.');
    await i.showModal(
      new ModalBuilder().setCustomId('leave:form').setTitle('Αίτημα άδειας').addComponents(
        input('from', 'Από (ημερομηνία)', TextInputStyle.Short, 40),
        input('to', 'Έως (ημερομηνία)', TextInputStyle.Short, 40),
        input('reason', 'Λόγος απουσίας', TextInputStyle.Paragraph, 500),
      ),
    );
  },

  async modal(i) {
    const ch = await h.getChannel(i.guild, 'leaves');
    if (!ch) return i.reply({ content: '⚠️ Δεν βρέθηκε το κανάλι αδειών. Τρέξε `/config`.', flags: h.EPH });
    const d = db.get();
    const l = {
      id: ++d.counters.leave,
      userId: i.user.id,
      from: i.fields.getTextInputValue('from').trim(),
      to: i.fields.getTextInputValue('to').trim(),
      reason: i.fields.getTextInputValue('reason').trim(),
      status: 'pending',
    };
    await ch.send({ embeds: [embed(l)], components: buttons(l) });
    d.leaves[l.id] = l;
    db.save();
    await i.reply({ content: `✅ Το αίτημα άδειας **#${l.id}** υποβλήθηκε. Θα ενημερωθείς με μήνυμα.`, flags: h.EPH });
  },

  async button(i, [action, id]) {
    if (!h.isCommand(i.member)) return h.deny(i, 'Μόνο η Διοίκηση μπορεί να εγκρίνει άδειες.');
    const l = db.get().leaves[id];
    if (!l || l.status !== 'pending') return h.deny(i, 'Το αίτημα έχει ήδη αξιολογηθεί.');
    l.status = action === 'approve' ? 'approved' : 'denied';
    l.by = i.user.id;
    db.save();
    await i.update({ embeds: [embed(l).addFields({ name: 'Αξιολογήθηκε από', value: `${i.member}`, inline: true })], components: [] });
    const user = await i.client.users.fetch(l.userId).catch(() => null);
    if (user) await h.dm(user, { content: `🏖️ Το αίτημα άδειάς σου **#${l.id}** (${l.from} → ${l.to}) **${l.status === 'approved' ? 'εγκρίθηκε ✅' : 'απορρίφθηκε ❌'}**.` });
  },
};
