const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, AttachmentBuilder } = require('discord.js');
const db = require('../utils/db');
const h = require('../utils/helpers');

const STATUS = {
  open: '🟡 Νέα',
  review: '🔍 Υπό εξέταση',
  resolved: '✅ Επιλύθηκε',
  dismissed: '🗑️ Απορρίφθηκε',
};
const COLOR = { open: 0xf1c40f, review: 0x3498db, resolved: 0x2ecc71, dismissed: 0x7f8c8d };
const cooldown = new Map(); // userId -> timestamp
const COOLDOWN_MS = 5 * 60 * 1000;

function embed(c) {
  const e = h.baseEmbed()
    .setColor(COLOR[c.status])
    .setTitle(`📢 Καταγγελία #${h.pad(c.id)}`)
    .addFields(
      { name: 'Καταγγέλλων', value: `<@${c.reporterId}>`, inline: true },
      { name: 'Καταγγελλόμενος', value: `<@${c.targetId}>`, inline: true },
      { name: 'Κατάσταση', value: STATUS[c.status], inline: true },
      { name: 'Λόγος', value: h.cut(c.reason, 1024) },
    );
  if (c.handledBy) e.addFields({ name: 'Χειρίστηκε', value: `<@${c.handledBy}>`, inline: true });
  if (c.evidenceName && c.evidenceImage) e.setImage(`attachment://${c.evidenceName}`);
  else if (c.evidenceName) e.addFields({ name: 'Απόδειξη', value: 'Δες το συνημμένο αρχείο.' });
  return e;
}

function buttons(c) {
  const b = (action, label, style) => new ButtonBuilder().setCustomId(`complaint:${action}:${c.id}`).setLabel(label).setStyle(style);
  if (c.status === 'open') {
    return [new ActionRowBuilder().addComponents(
      b('review', 'Εξέταση', ButtonStyle.Primary),
      b('resolve', 'Επιλύθηκε', ButtonStyle.Success),
      b('dismiss', 'Απόρριψη', ButtonStyle.Danger),
    )];
  }
  if (c.status === 'review') {
    return [new ActionRowBuilder().addComponents(
      b('resolve', 'Επιλύθηκε', ButtonStyle.Success),
      b('dismiss', 'Απόρριψη', ButtonStyle.Danger),
    )];
  }
  return [];
}

// Ξανα-ανεβάζει την απόδειξη (τα links συνημμένων λήγουν μετά από λίγο)
async function evidenceFile(att) {
  try {
    if (att.size > 8 * 1024 * 1024) return null;
    const res = await fetch(att.url);
    if (!res.ok) return null;
    const ext = (att.name?.match(/\.[a-z0-9]{2,5}$/i) || ['.png'])[0].toLowerCase();
    const name = `evidence${ext}`;
    return { file: new AttachmentBuilder(Buffer.from(await res.arrayBuffer()), { name }), name, image: !!att.contentType?.startsWith('image/') };
  } catch {
    return null;
  }
}

module.exports = {
  prefix: 'complaint',
  data: new SlashCommandBuilder()
    .setName('complaint')
    .setDescription('Report a member to command staff (evidence optional)')
    .addUserOption((o) => o.setName('member').setDescription('Who are you reporting?').setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('What happened? Be detailed').setRequired(true).setMaxLength(1000))
    .addAttachmentOption((o) => o.setName('evidence').setDescription('Screenshot or file as evidence (optional)')),

  async execute(i) {
    const target = i.options.getUser('member');
    if (target.id === i.user.id) return h.deny(i, 'Δεν μπορείς να καταγγείλεις τον εαυτό σου.');
    if (target.bot) return h.deny(i, 'Δεν μπορείς να καταγγείλεις bot.');

    const last = cooldown.get(i.user.id) ?? 0;
    if (Date.now() - last < COOLDOWN_MS) {
      return h.deny(i, `Περίμενε λίγο πριν υποβάλεις νέα καταγγελία (<t:${h.unix(last + COOLDOWN_MS)}:R>).`);
    }
    const ch = await h.getChannel(i.guild, 'complaints');
    if (!ch) return h.deny(i, 'Δεν βρέθηκε το κανάλι καταγγελιών. Ζήτα από διαχειριστή να τρέξει `/config`.');

    await i.deferReply({ flags: h.EPH });
    const d = db.get();
    const c = {
      id: ++d.counters.complaint,
      reporterId: i.user.id,
      targetId: target.id,
      reason: i.options.getString('reason'),
      status: 'open',
      handledBy: null,
      evidenceName: null,
      evidenceImage: false,
      createdAt: Date.now(),
      channelId: ch.id,
      messageId: null,
    };

    const att = i.options.getAttachment('evidence');
    const ev = att ? await evidenceFile(att) : null;
    if (ev) { c.evidenceName = ev.name; c.evidenceImage = ev.image; }

    const msg = await ch.send({ embeds: [embed(c)], components: buttons(c), files: ev ? [ev.file] : [] });
    c.messageId = msg.id;
    d.complaints[c.id] = c;
    cooldown.set(i.user.id, Date.now());
    db.save();
    await i.editReply(`✅ Η καταγγελία σου καταχωρήθηκε με αριθμό **#${h.pad(c.id)}**. Η Διοίκηση θα την εξετάσει.`);
  },

  async button(i, [action, id]) {
    if (!h.isCommand(i.member)) return h.deny(i, 'Μόνο η Διοίκηση μπορεί να χειριστεί καταγγελίες.');
    const c = db.get().complaints[id];
    if (!c) return h.deny(i, 'Η καταγγελία δεν βρέθηκε.');
    if (['resolved', 'dismissed'].includes(c.status)) return h.deny(i, 'Η καταγγελία έχει ήδη κλείσει.');

    c.status = { review: 'review', resolve: 'resolved', dismiss: 'dismissed' }[action];
    c.handledBy = i.user.id;
    db.save();
    await i.update({ embeds: [embed(c)], components: buttons(c) });

    if (action !== 'review') {
      const reporter = await i.client.users.fetch(c.reporterId).catch(() => null);
      if (reporter) {
        await h.dm(reporter, {
          content: action === 'resolve'
            ? `✅ Η καταγγελία σου **#${h.pad(c.id)}** εξετάστηκε και επιλύθηκε. Ευχαριστούμε!`
            : `ℹ️ Η καταγγελία σου **#${h.pad(c.id)}** εξετάστηκε και δεν προχώρησε περαιτέρω.`,
        });
      }
    }
  },
};
