const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const h = require('../utils/helpers');
const { withBanner } = require('../utils/panelart');

function panel(guild) {
  const list = h.selfRoleList(guild).slice(0, 25);
  const e = h.baseEmbed().setTitle('🎭 Επιλογή Ρόλων')
    .setDescription('Πάτησε ένα κουμπί για να **πάρεις** ή να **αφαιρέσεις** τον ρόλο.\n\n' + (list.length ? list.map((x) => `${x.emoji} **${x.role.name}**`).join('\n') : '*Δεν έχουν οριστεί ρόλοι (`/config selfrole`).*'));
  const rows = [];
  for (let n = 0; n < list.length; n += 5) {
    rows.push(new ActionRowBuilder().addComponents(
      ...list.slice(n, n + 5).map((x) => new ButtonBuilder().setCustomId(`role:toggle:${x.role.id}`).setLabel(h.cut(x.role.name, 80)).setEmoji(x.emoji).setStyle(ButtonStyle.Secondary)),
    ));
  }
  return withBanner({ embeds: [e], components: rows }, 'roles');
}

module.exports = {
  prefix: 'role',
  panel,
  data: new SlashCommandBuilder()
    .setName('roles')
    .setDescription('Self-assignable roles (command staff)')
    .addSubcommand((s) => s.setName('panel').setDescription('Post the role-selection panel').addChannelOption((o) => h.channelOpt(o, 'Where to post the panel (default: here)'))),

  async execute(i) {
    if (!h.isCommand(i.member)) return h.deny(i, 'Μόνο η Διοίκηση μπορεί να δημοσιεύσει το πάνελ.');
    if (!h.selfRoleList(i.guild).length) return h.deny(i, 'Δεν έχουν οριστεί ρόλοι επιλογής. Πρόσθεσέ τους με `/config selfrole`.');
    const target = i.options.getChannel('channel') ?? i.channel;
    await target.send(panel(i.guild));
    await i.reply({ content: `✅ Το πάνελ ρόλων δημοσιεύτηκε στο ${target}.`, flags: h.EPH });
  },

  async button(i, [, roleId]) {
    const allowed = h.selfRoleList(i.guild).find((x) => x.role.id === roleId);
    if (!allowed) return h.deny(i, 'Αυτός ο ρόλος δεν είναι πια διαθέσιμος για επιλογή.');
    const role = allowed.role;
    try {
      if (i.member.roles.cache.has(role.id)) {
        await i.member.roles.remove(role);
        return i.reply({ content: `➖ Αφαιρέθηκε ο ρόλος **${role.name}**.`, flags: h.EPH });
      }
      await i.member.roles.add(role);
      return i.reply({ content: `✅ Πήρες τον ρόλο **${role.name}**.`, flags: h.EPH });
    } catch {
      return h.deny(i, 'Δεν μπόρεσα να αλλάξω τον ρόλο. Ο ρόλος του bot πρέπει να είναι πάνω από αυτόν.');
    }
  },
};
