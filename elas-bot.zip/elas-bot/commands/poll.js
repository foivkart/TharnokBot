const { SlashCommandBuilder } = require('discord.js');
const h = require('../utils/helpers');

const NUM = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣'];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('poll')
    .setDescription('Create a poll with reactions (officers)')
    .addStringOption((o) => o.setName('question').setDescription('The question').setRequired(true).setMaxLength(250))
    .addStringOption((o) => o.setName('option_1').setDescription('First option').setRequired(true).setMaxLength(100))
    .addStringOption((o) => o.setName('option_2').setDescription('Second option').setRequired(true).setMaxLength(100))
    .addStringOption((o) => o.setName('option_3').setDescription('Third option').setMaxLength(100))
    .addStringOption((o) => o.setName('option_4').setDescription('Fourth option').setMaxLength(100))
    .addStringOption((o) => o.setName('option_5').setDescription('Fifth option').setMaxLength(100))
    .addChannelOption((o) => h.channelOpt(o, 'Post the poll in this channel')),

  async execute(i) {
    if (!h.isOfficer(i.member)) return h.deny(i, 'Μόνο οι αστυνομικοί μπορούν να δημιουργήσουν δημοσκοπήσεις.');
    const options = [1, 2, 3, 4, 5].map((n) => i.options.getString(`option_${n}`)).filter(Boolean);
    const e = h.baseEmbed().setTitle(`📊 ${i.options.getString('question')}`)
      .setDescription(options.map((o, n) => `${NUM[n]} ${o}`).join('\n\n'))
      .setAuthor({ name: i.member.displayName, iconURL: i.user.displayAvatarURL() });
    const where = i.options.getChannel('channel');
    let msg;
    if (where) { msg = await where.send({ embeds: [e] }); await i.reply({ content: `✅ Η δημοσκόπηση δημοσιεύτηκε στο ${where}.`, flags: h.EPH }); }
    else { await i.reply({ embeds: [e] }); msg = await i.fetchReply(); }
    for (let n = 0; n < options.length; n++) await msg.react(NUM[n]).catch(() => {});
  },
};
