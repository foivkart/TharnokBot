const { SlashCommandBuilder } = require('discord.js');
const db = require('../utils/db');
const h = require('../utils/helpers');

const LEVELS = {
  green: { label: '🟢 ΠΡΑΣΙΝΟ — Η Ασφαλής Ζώνη είναι ασφαλής', color: 0x2ecc71, advice: 'Κανονική ζωή. Μείνε σε επιφυλακή και ανάφερε οτιδήποτε ύποπτο σε αστυνομικό.' },
  yellow: { label: '🟡 ΚΙΤΡΙΝΟ — Αυξημένη επιφυλακή', color: 0xf1c40f, advice: 'Δραστηριότητα μολυσμένων ή εχθρικών κοντά στην περίμετρο. Αποφύγετε να βγείτε από την Ασφαλή Ζώνη.' },
  orange: { label: '🟠 ΠΟΡΤΟΚΑΛΙ — Υψηλός κίνδυνος', color: 0xe67e22, advice: 'Η περίμετρος δέχεται πίεση. Μείνετε μέσα και ακολουθείτε τις οδηγίες των αστυνομικών.' },
  red: { label: '🔴 ΚΟΚΚΙΝΟ — ΚΡΙΣΙΜΟ', color: 0xe74c3c, advice: 'Διάρρηξη περιμέτρου, δράση στρατού ή πλήρες lockdown. Παραμείνετε στο σημείο σας ΑΜΕΣΩΣ και υπακούστε σε όλες τις εντολές.' },
};
const short = { green: 'Green', yellow: 'Yellow', orange: 'Orange', red: 'Red' };

const statusEmbed = (t) =>
  h.baseEmbed().setColor(LEVELS[t.level].color)
    .setTitle(`🛡️ Κατάσταση Ασφαλούς Ζώνης: ${LEVELS[t.level].label}`)
    .setDescription(`**Κατάσταση:** ${t.reason ?? 'Όλα ήρεμα.'}\n\n**Οδηγίες:** ${LEVELS[t.level].advice}`)
    .addFields({ name: 'Ενημερώθηκε', value: t.at ? `<t:${h.unix(t.at)}:R> από <@${t.by}>` : '—' });

module.exports = {
  data: new SlashCommandBuilder()
    .setName('threat')
    .setDescription('Safe zone threat level')
    .addSubcommand((s) => s.setName('view').setDescription('Show the current threat level'))
    .addSubcommand((s) =>
      s.setName('set').setDescription('Change the threat level (command staff)')
        .addStringOption((o) =>
          o.setName('level').setDescription('New level').setRequired(true).addChoices(
            ...Object.keys(LEVELS).map((value) => ({ name: short[value], value })),
          ))
        .addStringOption((o) => o.setName('reason').setDescription('What is happening?').setRequired(true).setMaxLength(500))
        .addBooleanOption((o) => o.setName('ping').setDescription('Ping @everyone?'))
        .addChannelOption((o) => h.channelOpt(o, 'Post the alert in this channel'))),

  async execute(i) {
    const d = db.get();
    if (i.options.getSubcommand() === 'view') return i.reply({ embeds: [statusEmbed(d.threat)] });
    if (!h.isCommand(i.member)) return h.deny(i, 'Μόνο η Διοίκηση μπορεί να αλλάξει το επίπεδο απειλής.');

    d.threat = { level: i.options.getString('level'), reason: i.options.getString('reason'), by: i.user.id, at: Date.now() };
    db.save();
    const ping = i.options.getBoolean('ping');
    const ch = i.options.getChannel('channel') ?? await h.getChannel(i.guild, 'status');
    if (ch) {
      await ch.send({ content: ping ? '@everyone' : undefined, embeds: [statusEmbed(d.threat)], allowedMentions: { parse: ping ? ['everyone'] : [] } }).catch(() => {});
      await ch.setTopic(`Επίπεδο απειλής: ${LEVELS[d.threat.level].label}`.slice(0, 1000)).catch(() => {});
    }
    await i.reply({ content: `✅ Επίπεδο απειλής: **${short[d.threat.level]}**${ch ? ` — δημοσιεύτηκε στο ${ch}` : ' (τρέξε /setup για το κανάλι κατάστασης)'}.`, flags: h.EPH });
  },
};
