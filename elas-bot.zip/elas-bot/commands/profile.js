const { SlashCommandBuilder } = require('discord.js');
const config = require('../config');
const db = require('../utils/db');
const h = require('../utils/helpers');
const duty = require('../utils/duty');
const sig = require('../utils/signals');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('profile')
    .setDescription('Show a member\'s profile')
    .addUserOption((o) => o.setName('member').setDescription('Member (default: you)')),

  async execute(i) {
    const m = i.options.getMember('member') ?? i.member;
    const r = h.rankIndex(m);
    const d = db.get();
    const e = h.baseEmbed().setTitle(`👤 ${m.displayName}`).setThumbnail(m.displayAvatarURL())
      .addFields(
        { name: 'Βαθμός', value: r >= 0 ? `🎖️ ${h.rankName(i.guild, r)}` : 'Πολίτης', inline: true },
        { name: 'Μέλος από', value: `<t:${h.unix(m.joinedTimestamp)}:D>`, inline: true },
      );
    if (h.isStaff(m)) {
      const rec = d.duty[m.id];
      e.addFields({ name: 'Σήμα', value: sig.callsignOf(m.id) ? `🎫 ${sig.callsignOf(m.id)}` : '—', inline: true });
      const us = h.unitsOf(m);
      if (us.length) e.addFields({ name: 'Μονάδα', value: us.map((u) => `<@&${u.roleId}>`).join(' '), inline: true });
      e.addFields(
        { name: 'Κατάσταση', value: rec?.onDuty ? (duty.inCall(m.id) ? '🟢 On Duty • 🎧 σε κλήση' : '🟢 On Duty') : '⚫ Off Duty', inline: true },
        { name: 'Χρόνος σε κλήση (εβδομάδα)', value: h.fmtDuration(duty.weekMs(m.id)), inline: true },
        { name: 'Χρόνος σε κλήση (σύνολο)', value: h.fmtDuration(duty.totalMs(m.id)), inline: true },
        { name: 'Αποστολές / Εκπαιδεύσεις', value: `${rec?.events || 0} / ${rec?.trainings || 0}`, inline: true },
        { name: 'Έπαινοι', value: String((d.commends[m.id] || []).length), inline: true },
        { name: 'Προειδοποιήσεις', value: String((d.warnings[m.id] || []).length), inline: true },
      );
    }
    await i.reply({ embeds: [e] });
  },
};
