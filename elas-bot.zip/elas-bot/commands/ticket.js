const {
  SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType,
  PermissionFlagsBits: P, AttachmentBuilder,
} = require('discord.js');
const config = require('../config');
const db = require('../utils/db');
const h = require('../utils/helpers');
const { withBanner } = require('../utils/panelart');

const cats = config.tickets.categories;
const PRIORITY = {
  low: { emoji: '🟢', label: 'Χαμηλή' }, normal: { emoji: '🟡', label: 'Κανονική' },
  high: { emoji: '🟠', label: 'Υψηλή' }, urgent: { emoji: '🔴', label: 'ΕΠΕΙΓΟΝ' },
};

function panel() {
  const e = h.baseEmbed().setTitle('📩 Κέντρο Αιτημάτων ΕΛ.ΑΣ.')
    .setDescription(`${config.tickets.description}\n\n${cats.map((c) => `${c.emoji} **${c.label}** — ${c.description}`).join('\n')}`);
  const rows = [];
  for (let n = 0; n < cats.length; n += 5) {
    rows.push(new ActionRowBuilder().addComponents(
      ...cats.slice(n, n + 5).map((c) => new ButtonBuilder().setCustomId(`ticket:open:${c.key}`).setLabel(c.label).setEmoji(c.emoji).setStyle(ButtonStyle.Primary)),
    ));
  }
  return withBanner({ embeds: [e], components: rows }, 'tickets');
}

const controls = (t) =>
  new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket:claim').setLabel(t.claimedBy ? 'Έχει αναληφθεί' : 'Ανάληψη').setEmoji('🙋').setStyle(ButtonStyle.Success).setDisabled(!!t.claimedBy),
    new ButtonBuilder().setCustomId('ticket:close').setLabel('Κλείσιμο').setEmoji('🔒').setStyle(ButtonStyle.Danger),
  );

const chanName = (t) => `${t.priority && t.priority !== 'normal' ? PRIORITY[t.priority].emoji : ''}αίτημα-${h.pad(t.id)}${t.suffix ? `-${t.suffix}` : ''}`;
const snowTime = (id) => Number((BigInt(id) >> 22n) + 1420070400000n);
const openTicketOf = (channelId) => { const t = db.get().tickets[channelId]; return t && t.status === 'open' ? t : null; };

async function transcript(channel) {
  const all = [];
  let before;
  for (let n = 0; n < 5; n++) {
    const batch = await channel.messages.fetch({ limit: 100, before }).catch(() => null);
    if (!batch || !batch.size) break;
    all.push(...batch.values());
    before = batch.last().id;
  }
  return all.reverse().map((m) => {
    const time = new Date(m.createdTimestamp).toLocaleString('el-GR');
    const files = m.attachments.size ? ` ${m.attachments.map((a) => a.url).join(' ')}` : '';
    return `[${time}] ${m.author.tag}: ${m.content}${files}${!m.content && m.embeds.length ? ' [embed]' : ''}`;
  }).join('\n') || '(κενό)';
}
const txtFile = (text, name) => new AttachmentBuilder(Buffer.from(text, 'utf8'), { name: `${name}.txt` });

async function openTicket(i, key) {
  const cat = cats.find((c) => c.key === key);
  if (!cat) return;
  const d = db.get();
  const blRole = h.roleFor(i.guild, 'blacklisted');
  if (blRole && i.member.roles.cache.has(blRole.id)) return h.deny(i, 'Δεν μπορείς να ανοίξεις αιτήματα.');
  const bl = d.ticketBlacklist[i.user.id];
  if (bl) return h.deny(i, `Έχεις αποκλειστεί από τα αιτήματα.${bl.reason ? `\nΛόγος: ${bl.reason}` : ''}`);
  const mine = Object.values(d.tickets).filter((t) => t.userId === i.user.id && t.status === 'open');
  if (mine.length >= h.setting('maxOpenTickets')) return h.deny(i, `Έχεις ήδη ανοιχτό αίτημα: <#${mine[0].channelId}>`);

  await i.deferReply({ flags: h.EPH });
  const guild = i.guild;
  const parent = await h.categoryFor(guild, 'tickets');
  const staff = cat.commandOnly ? h.commandRoleList(guild) : h.ticketStaffRoles(guild);
  const allow = [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.AttachFiles];
  try {
    const n = ++d.counters.ticket;
    const t = { id: n, channelId: null, userId: i.user.id, category: key, claimedBy: null, priority: 'normal', suffix: '', status: 'open', openedAt: Date.now(), warned: false };
    const ch = await guild.channels.create({
      name: chanName(t), type: ChannelType.GuildText, parent: parent?.id, topic: `Αίτημα #${n} • ${cat.label} • ${i.user.tag}`,
      permissionOverwrites: [
        { id: guild.roles.everyone.id, deny: [P.ViewChannel] },
        { id: i.user.id, allow },
        ...staff.map((r) => ({ id: r.id, allow })),
        { id: guild.members.me.id, allow: [...allow, P.EmbedLinks, P.ManageChannels] },
      ],
    });
    t.channelId = ch.id;
    d.tickets[ch.id] = t;
    db.save();
    await ch.send({
      content: `${i.user}`,
      embeds: [h.baseEmbed().setTitle(`${cat.emoji} Αίτημα #${n} — ${cat.label}`)
        .setDescription(`Γεια σου ${i.user}! Περιέγραψε αναλυτικά το θέμα σου και ένας αστυνομικός θα σε εξυπηρετήσει σύντομα.`)],
      components: [controls(t)],
    });
    await h.sendTo(guild, 'ticketLog', { embeds: [h.baseEmbed().setColor(0x2ecc71).setDescription(`📂 Άνοιξε το αίτημα **#${n}** (${cat.label}) ο/η ${i.user} → ${ch}`)] });
    return i.editReply(`✅ Το αίτημά σου δημιουργήθηκε: ${ch}`);
  } catch (e) {
    console.error('Ticket create:', e);
    return i.editReply('⚠️ Δεν μπόρεσα να δημιουργήσω το αίτημα. Ειδοποίησε έναν διαχειριστή.');
  }
}

// Closes a ticket (used by the button, /ticket close and the inactivity job)
async function finish(client, guild, channel, t, closer, why) {
  t.status = 'closed';
  t.closedBy = closer?.id ?? null;
  t.closedAt = Date.now();
  db.save();
  const text = await transcript(channel);
  await h.sendTo(guild, 'ticketLog', {
    embeds: [h.baseEmbed().setColor(0xe74c3c).setTitle(`🔒 Αίτημα #${t.id} έκλεισε`).addFields(
      { name: 'Δημιουργός', value: `<@${t.userId}>`, inline: true },
      { name: 'Έκλεισε από', value: closer ? `${closer}` : '⏱️ αυτόματα', inline: true },
      { name: 'Ανάληψη', value: t.claimedBy ? `<@${t.claimedBy}>` : '—', inline: true },
      { name: 'Προτεραιότητα', value: PRIORITY[t.priority ?? 'normal'].label, inline: true },
      { name: 'Αιτιολογία', value: why ?? '—', inline: true },
    )],
    files: [txtFile(text, channel.name)],
  });
  const creator = await client.users.fetch(t.userId).catch(() => null);
  if (creator) await h.dm(creator, { content: `📄 Αντίγραφο του αιτήματός σου **#${t.id}** στον ${guild.name}:`, files: [txtFile(text, channel.name)] });
  setTimeout(() => channel.delete('Κλείσιμο αιτήματος').catch(() => {}), 5000);
}

async function closeTicket(i, why) {
  const t = openTicketOf(i.channelId);
  if (!t) return h.deny(i, 'Αυτό το κανάλι δεν είναι ανοιχτό αίτημα.');
  if (t.userId !== i.user.id && !h.isOfficer(i.member)) return h.deny(i, 'Δεν έχεις δικαίωμα να κλείσεις αυτό το αίτημα.');
  await i.reply('🔒 Το αίτημα κλείνει σε **5 δευτερόλεπτα**… Αποθηκεύεται αντίγραφο της συζήτησης.');
  await finish(i.client, i.guild, i.channel, t, i.member, why);
}

// Runs every 15 minutes: warns and closes inactive tickets
async function tick(client) {
  const hours = h.setting('ticketAutoCloseHours');
  if (!hours) return;
  for (const t of Object.values(db.get().tickets)) {
    if (t.status !== 'open') continue;
    const guild = client.guilds.cache.first();
    const ch = guild?.channels.cache.get(t.channelId);
    if (!ch) { t.status = 'closed'; db.save(); continue; }
    const last = ch.lastMessageId ? snowTime(ch.lastMessageId) : t.openedAt;
    const idle = (Date.now() - last) / 3600000;
    if (idle >= hours) {
      await ch.send('🔒 Το αίτημα κλείνει λόγω **αδράνειας**.').catch(() => {});
      await finish(client, guild, ch, t, null, 'Αδράνεια');
    } else if (idle >= hours * 0.75 && !t.warned) {
      t.warned = true;
      db.save();
      await ch.send(`⏱️ <@${t.userId}> το αίτημα δεν έχει δραστηριότητα και θα κλείσει αυτόματα σε ~${Math.ceil(hours - idle)} ώρες.`).catch(() => {});
    }
  }
}

const user = (o) => o.setName('user').setDescription('Which user').setRequired(true);

module.exports = {
  prefix: 'ticket',
  panel,
  tick,
  data: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Private support tickets to the ΕΛ.ΑΣ.')
    .addSubcommand((s) => s.setName('panel').setDescription('Post the ticket panel (command staff)').addChannelOption((o) => h.channelOpt(o, 'Where to post the panel (default: here)')))
    .addSubcommand((s) => s.setName('add').setDescription('Add a user to this ticket').addUserOption(user))
    .addSubcommand((s) => s.setName('remove').setDescription('Remove a user from this ticket').addUserOption(user))
    .addSubcommand((s) => s.setName('close').setDescription('Close this ticket (saves a transcript)').addStringOption((o) => o.setName('reason').setDescription('Closing reason').setMaxLength(200)))
    .addSubcommand((s) => s.setName('rename').setDescription('Add a label to this ticket\'s channel name').addStringOption((o) => o.setName('name').setDescription('Label').setRequired(true).setMaxLength(30)))
    .addSubcommand((s) => s.setName('claim').setDescription('Take this ticket'))
    .addSubcommand((s) => s.setName('unclaim').setDescription('Release this ticket'))
    .addSubcommand((s) =>
      s.setName('priority').setDescription('Set the priority of this ticket')
        .addStringOption((o) => o.setName('level').setDescription('Priority').setRequired(true).addChoices(...Object.entries(PRIORITY).map(([value, p]) => ({ name: `${p.emoji} ${p.label}`, value })))))
    .addSubcommand((s) => s.setName('transfer').setDescription('Hand this ticket to another officer').addUserOption((o) => o.setName('officer').setDescription('Which officer').setRequired(true)))
    .addSubcommand((s) => s.setName('list').setDescription('List all open tickets'))
    .addSubcommand((s) => s.setName('transcript').setDescription('Get a transcript of this ticket without closing it'))
    .addSubcommand((s) =>
      s.setName('blacklist_add').setDescription('Stop a user from opening tickets (command staff)').addUserOption(user)
        .addStringOption((o) => o.setName('reason').setDescription('Reason').setMaxLength(200)))
    .addSubcommand((s) => s.setName('blacklist_remove').setDescription('Allow a user to open tickets again (command staff)').addUserOption(user))
    .addSubcommand((s) => s.setName('stats').setDescription('Ticket statistics')),

  async execute(i) {
    const sub = i.options.getSubcommand();
    const d = db.get();

    if (sub === 'panel') {
      if (!h.isCommand(i.member)) return h.deny(i, 'Μόνο η Διοίκηση μπορεί να δημοσιεύσει το πάνελ.');
      const target = i.options.getChannel('channel') ?? i.channel;
      await target.send(panel());
      return i.reply({ content: `✅ Το πάνελ αιτημάτων δημοσιεύτηκε στο ${target}.`, flags: h.EPH });
    }
    if (sub === 'close') return closeTicket(i, i.options.getString('reason'));

    if (!h.isOfficer(i.member)) return h.deny(i, 'Μόνο οι αστυνομικοί της ΕΛ.ΑΣ. μπορούν να το κάνουν αυτό.');

    if (sub === 'list') {
      const open = Object.values(d.tickets).filter((t) => t.status === 'open');
      const lines = open.map((t) => `${PRIORITY[t.priority ?? 'normal'].emoji} **#${h.pad(t.id)}** <#${t.channelId}> • <@${t.userId}> • ${cats.find((c) => c.key === t.category)?.label ?? t.category}${t.claimedBy ? ` • 🙋 <@${t.claimedBy}>` : ' • ⏳ αδέσμευτο'}`);
      return i.reply({ embeds: [h.baseEmbed().setTitle(`📩 Ανοιχτά αιτήματα (${open.length})`).setDescription(h.cut(lines.join('\n') || 'Δεν υπάρχουν ανοιχτά αιτήματα. 🎉', 4000))], flags: h.EPH, allowedMentions: { parse: [] } });
    }
    if (sub === 'stats') {
      const all = Object.values(d.tickets);
      const by = cats.map((c) => `${c.emoji} ${c.label}: **${all.filter((t) => t.category === c.key).length}**`).join(' • ');
      const e = h.baseEmbed().setTitle('📊 Στατιστικά αιτημάτων').addFields(
        { name: 'Ανοιχτά', value: String(all.filter((t) => t.status === 'open').length), inline: true },
        { name: 'Κλειστά', value: String(all.filter((t) => t.status === 'closed').length), inline: true },
        { name: 'Αποκλεισμένοι', value: String(Object.keys(d.ticketBlacklist).length), inline: true },
        { name: 'Ανά κατηγορία', value: by || '—' },
      );
      return i.reply({ embeds: [e], flags: h.EPH });
    }
    if (sub === 'blacklist_add' || sub === 'blacklist_remove') {
      if (!h.isCommand(i.member)) return h.deny(i, 'Μόνο η Διοίκηση μπορεί να το κάνει αυτό.');
      const u = i.options.getUser('user');
      if (sub === 'blacklist_add') d.ticketBlacklist[u.id] = { by: i.user.id, reason: i.options.getString('reason') ?? null, at: Date.now() };
      else delete d.ticketBlacklist[u.id];
      db.save();
      return i.reply({ content: sub === 'blacklist_add' ? `⛔ Ο/Η ${u} δεν μπορεί πια να ανοίξει αιτήματα.` : `✅ Ο/Η ${u} μπορεί ξανά να ανοίξει αιτήματα.`, flags: h.EPH });
    }

    // everything below works inside a ticket channel
    const t = openTicketOf(i.channelId);
    if (!t) return h.deny(i, 'Χρησιμοποίησε αυτή την εντολή μέσα σε ένα ανοιχτό αίτημα.');

    if (sub === 'add') {
      const u = i.options.getUser('user');
      await i.channel.permissionOverwrites.edit(u.id, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true, AttachFiles: true });
      return i.reply(`➕ Ο/Η ${u} προστέθηκε στο αίτημα.`);
    }
    if (sub === 'remove') {
      const u = i.options.getUser('user');
      if (u.id === t.userId) return h.deny(i, 'Δεν μπορείς να αφαιρέσεις τον δημιουργό του αιτήματος.');
      await i.channel.permissionOverwrites.delete(u.id);
      return i.reply(`➖ Ο/Η ${u} αφαιρέθηκε από το αίτημα.`);
    }
    if (sub === 'claim') {
      if (t.claimedBy) return h.deny(i, `Το αίτημα το έχει ήδη ο/η <@${t.claimedBy}>.`);
      t.claimedBy = i.user.id; db.save();
      return i.reply(`🙋 Ο/Η ${i.member} ανέλαβε το αίτημα.`);
    }
    if (sub === 'unclaim') {
      if (!t.claimedBy) return h.deny(i, 'Το αίτημα δεν έχει αναληφθεί.');
      if (t.claimedBy !== i.user.id && !h.isCommand(i.member)) return h.deny(i, 'Μόνο όποιος ανέλαβε το αίτημα (ή η Διοίκηση) μπορεί να το αποδεσμεύσει.');
      t.claimedBy = null; db.save();
      return i.reply('🔓 Το αίτημα αποδεσμεύτηκε.');
    }
    if (sub === 'transfer') {
      const m = i.options.getMember('officer');
      if (!m || !h.isOfficer(m)) return h.deny(i, 'Ο χρήστης πρέπει να είναι αστυνομικός.');
      t.claimedBy = m.id; db.save();
      return i.reply(`🔁 Το αίτημα μεταφέρθηκε στον/στην ${m}.`);
    }
    if (sub === 'priority') {
      t.priority = i.options.getString('level'); db.save();
      await i.reply({ embeds: [h.baseEmbed().setDescription(`${PRIORITY[t.priority].emoji} Προτεραιότητα: **${PRIORITY[t.priority].label}** (από ${i.member})`)] });
      return i.channel.setName(chanName(t)).catch(() => {});
    }
    if (sub === 'rename') {
      t.suffix = i.options.getString('name').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '-').replace(/^-|-$/g, '').slice(0, 30);
      db.save();
      await i.channel.setName(chanName(t)).catch(() => {});
      return i.reply({ content: `✅ Το όνομα του καναλιού ενημερώθηκε.`, flags: h.EPH });
    }
    if (sub === 'transcript') {
      await i.deferReply({ flags: h.EPH });
      return i.editReply({ content: '📄 Αντίγραφο της συζήτησης:', files: [txtFile(await transcript(i.channel), i.channel.name)] });
    }
  },

  async button(i, [action, key]) {
    if (action === 'open') return openTicket(i, key);
    if (action === 'close') return closeTicket(i);
    if (action === 'claim') {
      const t = openTicketOf(i.channelId);
      if (!t) return h.deny(i, 'Αυτό το αίτημα δεν είναι ανοιχτό.');
      if (!h.isOfficer(i.member)) return h.deny(i, 'Μόνο αστυνομικοί μπορούν να αναλάβουν αιτήματα.');
      t.claimedBy = i.user.id; db.save();
      await i.update({ components: [controls(t)] });
      await i.channel.send(`🙋 Ο/Η ${i.member} ανέλαβε το αίτημα.`);
    }
  },
};
