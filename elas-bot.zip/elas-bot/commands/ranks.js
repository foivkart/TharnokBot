const { SlashCommandBuilder } = require('discord.js');
const h = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder().setName('ranks').setDescription('Show the rank structure and how many officers hold each rank'),

  async execute(i) {
    await i.deferReply();
    const L = h.ladder(i.guild);
    if (!L.length) return i.editReply('Δεν έχουν οριστεί βαθμοί. Η Διοίκηση μπορεί να τους ορίσει με `/config rank_range`.');
    const members = await i.guild.members.fetch();
    const counts = L.map((r) => members.filter((m) => !m.user.bot && h.rankIndex(m) === L.indexOf(r)).size);
    const cmd = h.commandIndex(i.guild);
    const lines = [];
    for (let r = L.length - 1; r >= 0; r--) {
      if (r === cmd - 1 && cmd > 0) lines.push('— — — — — — — — — — — — — — —');
      lines.push(`${r >= cmd ? '⭐' : '▫️'} ${L[r]} — **${counts[r]}**`);
    }
    return i.editReply({ embeds: [h.baseEmbed().setTitle('🎖️ Ιεραρχία ΕΛ.ΑΣ.').setDescription(`${lines.join('\n')}\n\n⭐ = Διοίκηση (από **${L[cmd]?.name ?? '—'}** και πάνω)`)], allowedMentions: { parse: [] } });
  },
};
