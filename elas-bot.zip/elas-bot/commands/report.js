const { SlashCommandBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
const db = require('../utils/db');
const h = require('../utils/helpers');

const TYPES = {
  arrest: { title: 'Αναφορά Σύλληψης', label: 'Arrest report', emoji: '⛓️', channel: 'reports', prefix: 'ΣΥ', counter: 'report', color: 0xe74c3c },
  incident: { title: 'Αναφορά Συμβάντος', label: 'Incident report', emoji: '🚨', channel: 'reports', prefix: 'ΑΝ', counter: 'report', color: 0xe67e22 },
  patrol: { title: 'Αναφορά Περιπολίας', label: 'Patrol log', emoji: '🚔', channel: 'reports', prefix: 'ΠΕ', counter: 'report', color: 0x0d5eaf },
  intel: { title: 'Πληροφορίες για τον Στρατό', label: 'Military intel', emoji: '🪖', channel: 'intel', prefix: 'ΠΛ', counter: 'intel', color: 0x7f8c8d },
};

const input = (id, label, style, required, max) =>
  new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId(id).setLabel(label).setStyle(style).setRequired(required).setMaxLength(max));

module.exports = {
  prefix: 'report',
  data: new SlashCommandBuilder()
    .setName('report')
    .setDescription('File an arrest / incident / patrol report or military intel')
    .addStringOption((o) =>
      o.setName('type').setDescription('Type of report').setRequired(true).addChoices(
        ...Object.entries(TYPES).map(([value, t]) => ({ name: `${t.emoji} ${t.label}`, value })),
      )),

  async execute(i) {
    if (!h.isOfficer(i.member)) return h.deny(i, 'Μόνο οι αστυνομικοί της ΕΛ.ΑΣ. υποβάλλουν αναφορές.');
    const type = i.options.getString('type');
    await i.showModal(
      new ModalBuilder().setCustomId(`report:${type}`).setTitle(h.cut(TYPES[type].title, 45)).addComponents(
        input('location', 'Τοποθεσία', TextInputStyle.Short, true, 100),
        input('involved', 'Εμπλεκόμενοι / ύποπτοι / μονάδες', TextInputStyle.Short, false, 200),
        input('details', 'Τι συνέβη / τι είδατε;', TextInputStyle.Paragraph, true, 1000),
        input('action', 'Ενέργειες / επόμενα βήματα', TextInputStyle.Paragraph, false, 500),
      ),
    );
  },

  async modal(i, [type]) {
    const t = TYPES[type];
    if (!t) return;
    const d = db.get();
    d.counters[t.counter] = (d.counters[t.counter] || 0) + 1;
    const code = `${t.prefix}-${h.pad(d.counters[t.counter])}`;
    const f = (id) => i.fields.getTextInputValue(id)?.trim() || '—';
    const embed = h.baseEmbed().setColor(t.color).setTitle(`${t.emoji} ${code} • ${t.title}`)
      .setAuthor({ name: i.member.displayName, iconURL: i.user.displayAvatarURL() })
      .addFields(
        { name: '📍 Τοποθεσία', value: f('location'), inline: true },
        { name: '👥 Εμπλεκόμενοι', value: f('involved'), inline: true },
        { name: '📝 Λεπτομέρειες', value: f('details') },
        { name: '✅ Ενέργειες / επόμενα βήματα', value: f('action') },
      );
    const msg = await h.sendTo(i.guild, t.channel, { embeds: [embed] });
    db.save();
    if (!msg) return i.reply({ content: '⚠️ Δεν βρέθηκε το κανάλι αναφορών. Όρισέ το με `/config channel`.', flags: h.EPH });
    await i.reply({ content: `✅ Η αναφορά καταχωρήθηκε ως **${code}** → ${msg.url}`, flags: h.EPH });
  },
};
