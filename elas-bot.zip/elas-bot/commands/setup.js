const { SlashCommandBuilder, PermissionFlagsBits: P, ChannelType } = require('discord.js');
const config = require('../config');
const db = require('../utils/db');
const h = require('../utils/helpers');
const { rulesPayload } = require('../utils/welcome');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setup')
    .setDescription('OPTIONAL: auto-create roles/channels/panels. Existing server? Use /config instead (admins)')
    .addBooleanOption((o) => o.setName('confirm').setDescription('Yes, create everything automatically').setRequired(true))
    .addBooleanOption((o) => o.setName('repost_panels').setDescription('Post all panels again (with the new banners)'))
    .setDefaultMemberPermissions(P.Administrator),

  async execute(i) {
    if (!h.isAdmin(i.member)) return h.deny(i, 'Μόνο για διαχειριστές.');
    if (!i.options.getBoolean('confirm')) return h.deny(i, 'Δεν έγινε τίποτα. Αν ο server σου υπάρχει ήδη, χρησιμοποίησε `/config` για να δείξεις στο bot τα δικά σου κανάλια και ρόλους.');
    await i.deferReply({ flags: h.EPH });

    const guild = i.guild;
    await guild.roles.fetch();
    await guild.channels.fetch();
    const made = { roles: 0, channels: 0, panels: 0 };

    // ── Roles ──────────────────────────────────────────────
    const ensureRole = async (name, opts = {}) => {
      let role = h.findRole(guild, name);
      if (!role) {
        role = await guild.roles.create({ name, reason: 'ΕΛ.ΑΣ. bot setup', ...opts });
        made.roles++;
      }
      return role;
    };
    const rankRoles = [];
    for (const name of config.ranks) rankRoles.push(await ensureRole(name, { color: config.color }));
    const onRole = await ensureRole(config.onDutyRole, { color: 0x2ecc71, hoist: true });
    await ensureRole(config.offDutyRole, { color: 0xe74c3c, hoist: true });
    for (const name of config.autoRoles.onJoin) await ensureRole(name, { color: 0x95a5a6 });
    for (const r of config.selfRoles) await ensureRole(r.name, { mentionable: true });

    // remember the roles in the runtime config so /config can change them later
    const C = h.cfg();
    C.ranks = rankRoles.map((r) => r.id);
    C.roles.onDuty = onRole.id;
    C.roles.offDuty = h.findRole(guild, config.offDutyRole)?.id;
    C.autoRoles.onJoin = config.autoRoles.onJoin.map((n) => h.findRole(guild, n)?.id).filter(Boolean);
    C.selfRoles = config.selfRoles.map((s) => ({ roleId: h.findRole(guild, s.name)?.id, emoji: s.emoji })).filter((s) => s.roleId);

    // ── Permissions ────────────────────────────────────────
    const everyone = guild.roles.everyone.id;
    const botAllow = {
      id: guild.members.me.id,
      allow: [P.ViewChannel, P.SendMessages, P.EmbedLinks, P.AttachFiles, P.ReadMessageHistory, P.AddReactions, P.Connect, P.MoveMembers, P.ManageChannels],
    };
    const hidden = (roles) => [
      { id: everyone, deny: [P.ViewChannel] },
      ...roles.map((r) => ({ id: r.id, allow: [P.ViewChannel, P.ReadMessageHistory], deny: [P.SendMessages] })),
      botAllow,
    ];
    const OW = {
      public: [{ id: everyone, allow: [P.ViewChannel, P.ReadMessageHistory], deny: [P.SendMessages] }, botAllow],
      staff: hidden(rankRoles),
      command: hidden(rankRoles.slice(Math.max(0, config.ranks.indexOf(config.commandFrom)))),
      tickets: [
        { id: everyone, deny: [P.ViewChannel] },
        ...rankRoles.map((r) => ({ id: r.id, allow: [P.ViewChannel, P.ReadMessageHistory, P.SendMessages] })),
        botAllow,
      ],
      // Duty voice: everyone locked out, officers can SEE the channels, only On Duty can CONNECT
      voice: [
        { id: everyone, deny: [P.ViewChannel, P.Connect] },
        ...rankRoles.map((r) => ({ id: r.id, allow: [P.ViewChannel] })),
        { id: onRole.id, allow: [P.ViewChannel, P.Connect, P.Speak, P.Stream, P.UseVAD] },
        botAllow,
      ],
    };
    const loungeOW = [
      { id: everyone, deny: [P.ViewChannel, P.Connect] },
      ...rankRoles.map((r) => ({ id: r.id, allow: [P.ViewChannel, P.Connect, P.Speak, P.UseVAD] })),
      botAllow,
    ];

    // ── Categories ─────────────────────────────────────────
    const ensureCategory = async (name, overwrites) => {
      let c = guild.channels.cache.find((x) => x.type === ChannelType.GuildCategory && x.name === name);
      if (!c) {
        c = await guild.channels.create({ name, type: ChannelType.GuildCategory, permissionOverwrites: overwrites });
        made.channels++;
      }
      return c;
    };
    const cats = {};
    for (const key of Object.keys(OW)) cats[key] = await ensureCategory(config.categories[key], OW[key]);

    const d = db.get();
    d.channels.ticketCategory = cats.tickets.id;
    C.categories.tickets = cats.tickets.id;

    // ── Text channels ──────────────────────────────────────
    for (const [key, cfg] of Object.entries(config.channels)) {
      if (d.channels[key] && guild.channels.cache.get(d.channels[key])) continue;
      const parent = cats[cfg.access];
      let ch = guild.channels.cache.find((x) => x.parentId === parent.id && x.name === cfg.name);
      if (!ch) {
        ch = await guild.channels.create({
          name: cfg.name, type: ChannelType.GuildText, parent: parent.id, topic: cfg.topic,
          permissionOverwrites: OW[cfg.access],
        });
        made.channels++;
      }
      d.channels[key] = ch.id;
    }

    // ── Duty voice channels ────────────────────────────────
    d.voiceChannels = {};
    for (const v of config.voiceChannels) {
      let ch = guild.channels.cache.find((x) => x.parentId === cats.voice.id && x.name === v.name && x.type === ChannelType.GuildVoice);
      if (!ch) {
        ch = await guild.channels.create({
          name: v.name, type: ChannelType.GuildVoice, parent: cats.voice.id,
          permissionOverwrites: v.open ? loungeOW : OW.voice,
        });
        made.channels++;
      }
      d.voiceChannels[ch.id] = { key: v.key, counted: !!v.counted, commandOnly: !!v.commandOnly, open: !!v.open };
    }
    db.save();

    // ── Panels (posted once) ───────────────────────────────
    const panels = {
      rules: () => rulesPayload(),
      duty: () => require('./duty').panel(),
      tickets: () => require('./ticket').panel(),
      applications: () => require('./application').panel(),
      roles: () => require('./roles').panel(guild),
    };
    const repost = i.options.getBoolean('repost_panels');
    for (const [key, build] of Object.entries(panels)) {
      if (d.settings.panels[key] && !repost) continue;
      const ch = await h.getChannel(guild, key);
      if (!ch) continue;
      const msg = await ch.send(await build()).catch((e) => { console.error(`Panel ${key}:`, e.message); return null; });
      if (msg) { d.settings.panels[key] = true; made.panels++; }
    }
    // Signal boards (1-100 and 101-200)
    if (!d.settings.panels.signals || repost) {
      const sch = await h.getChannel(guild, 'signals');
      if (sch) {
        try { await require('./signal').postBoards(sch); d.settings.panels.signals = true; made.panels++; }
        catch (e) { console.error('Signal boards:', e.message); }
      }
    }
    db.save();

    await i.editReply(
      `✅ **Η εγκατάσταση ολοκληρώθηκε!**\n` +
      `Νέοι ρόλοι: **${made.roles}** • Νέα κανάλια/κατηγορίες: **${made.channels}** • Νέα πάνελ: **${made.panels}**\n\n` +
      `**Επόμενα βήματα:**\n` +
      `1. Ρυθμίσεις server → Ρόλοι → σύρε τον **ρόλο του bot στην κορυφή** (πάνω από όλους τους ρόλους).\n` +
      `2. Δώσε βαθμούς με \`/promote @user\`.\n` +
      `3. Ενεργοποίησε το native AutoMod του Discord: \`/security automod_setup\`.\n` +
      `4. Οι αστυνομικοί διαλέγουν σήμα στο #σήματα (πίνακες 1-100 και 101-200).\n` +
      `5. Δες την κατάσταση ασφαλείας: \`/security status\`.\n` +
      `Αν ανανέωσες τα banners: \`/setup repost_panels:True\` ξαναδημοσιεύει όλα τα πάνελ.`,
    );
  },
};
