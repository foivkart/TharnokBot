const { SlashCommandBuilder } = require('discord.js');
const h = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('suggest')
    .setDescription('Send a suggestion for the server or the ΕΛ.ΑΣ.')
    .addStringOption((o) => o.setName('text').setDescription('Your suggestion').setRequired(true).setMaxLength(1500)),

  async execute(i) {
    const ch = await h.getChannel(i.guild, 'suggestions');
    if (!ch) return h.deny(i, 'Δεν βρέθηκε το κανάλι προτάσεων. Ζήτα από διαχειριστή να τρέξει `/config`.');
    const e = h.baseEmbed().setTitle('💡 Νέα πρόταση').setDescription(i.options.getString('text'))
      .setAuthor({ name: i.member.displayName, iconURL: i.user.displayAvatarURL() });
    const msg = await ch.send({ embeds: [e] });
    await msg.react('👍').catch(() => {});
    await msg.react('👎').catch(() => {});
    await i.reply({ content: `✅ Η πρότασή σου δημοσιεύτηκε: ${msg.url}`, flags: h.EPH });
  },
};
