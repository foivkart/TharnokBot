const { SlashCommandBuilder } = require('discord.js');
const h = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('announce')
    .setDescription('Post an official ΕΛ.ΑΣ. announcement in any channel (command staff)')
    .addStringOption((o) => o.setName('title').setDescription('Headline').setRequired(true).setMaxLength(200))
    .addStringOption((o) => o.setName('message').setDescription('Text (write \\n for a new line)').setRequired(true).setMaxLength(3000))
    .addChannelOption((o) => h.channelOpt(o, 'Which channel to announce in (default: the announcements channel)'))
    .addRoleOption((o) => o.setName('ping_role').setDescription('Role to ping'))
    .addBooleanOption((o) => o.setName('ping').setDescription('Ping @everyone?')),

  async execute(i) {
    if (!h.isCommand(i.member)) return h.deny(i, 'Μόνο η Διοίκηση μπορεί να δημοσιεύει ανακοινώσεις.');
    const ch = i.options.getChannel('channel') ?? await h.getChannel(i.guild, 'announcements');
    if (!ch) return h.deny(i, 'Διάλεξε κανάλι με την επιλογή `channel`, ή όρισε το κανάλι ανακοινώσεων με `/config channel`.');

    const everyone = i.options.getBoolean('ping');
    const role = i.options.getRole('ping_role');
    const embed = h.baseEmbed().setTitle(`📢 ${i.options.getString('title')}`)
      .setDescription(i.options.getString('message').replace(/\\n/g, '\n'))
      .setAuthor({ name: i.member.displayName, iconURL: i.user.displayAvatarURL() });
    await ch.send({
      content: [everyone ? '@everyone' : null, role ? `${role}` : null].filter(Boolean).join(' ') || undefined,
      embeds: [embed],
      allowedMentions: { parse: everyone ? ['everyone'] : [], roles: role ? [role.id] : [] },
    });
    await i.reply({ content: `✅ Η ανακοίνωση δημοσιεύτηκε στο ${ch}.`, flags: h.EPH });
  },
};
