const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const db = require('../utils/db');
const h = require('../utils/helpers');

const timers = new Map();

const embed = (g, ended) =>
  h.baseEmbed().setColor(ended ? 0x7f8c8d : 0xf1c40f).setTitle(`🎉 ${g.prize}`)
    .setDescription(ended
      ? `Η κλήρωση **έληξε**.\n🏆 Νικητές: ${g.winnerIds.length ? g.winnerIds.map((x) => `<@${x}>`).join(', ') : '— κανείς (δεν υπήρχαν συμμετοχές)'}`
      : `Πάτησε το κουμπί για να συμμετάσχεις!\n⏰ Λήγει <t:${h.unix(g.endsAt)}:R>\n🏆 Νικητές: **${g.winners}**`)
    .addFields({ name: 'Διοργανωτής', value: `<@${g.hostId}>`, inline: true }, { name: 'Συμμετοχές', value: String(g.entries.length), inline: true });

const button = (g, ended) => [new ActionRowBuilder().addComponents(
  new ButtonBuilder().setCustomId(`giveaway:join:${g.id}`).setLabel(`Συμμετοχή (${g.entries.length})`).setEmoji('🎉').setStyle(ButtonStyle.Primary).setDisabled(ended),
)];

const pick = (entries, n) => [...entries].sort(() => Math.random() - 0.5).slice(0, n);

async function finish(client, g) {
  clearTimeout(timers.get(g.id));
  if (g.ended) return;
  g.ended = true;
  g.winnerIds = pick(g.entries, g.winners);
  db.save();
  const ch = await client.channels.fetch(g.channelId).catch(() => null);
  const msg = await ch?.messages.fetch(g.messageId).catch(() => null);
  if (msg) await msg.edit({ embeds: [embed(g, true)], components: button(g, true) }).catch(() => {});
  if (ch) await ch.send({ content: g.winnerIds.length ? `🎉 Συγχαρητήρια ${g.winnerIds.map((x) => `<@${x}>`).join(', ')}! Κερδίσατε **${g.prize}**!` : `😕 Η κλήρωση για **${g.prize}** έληξε χωρίς συμμετοχές.`, allowedMentions: { users: g.winnerIds } }).catch(() => {});
}

function schedule(client, g) {
  clearTimeout(timers.get(g.id));
  const ms = Math.max(1000, g.endsAt - Date.now());
  timers.set(g.id, setTimeout(() => finish(client, g), Math.min(ms, 2147000000)));
}

module.exports = {
  prefix: 'giveaway',
  resume(client) { for (const g of Object.values(db.get().giveaways)) if (!g.ended) schedule(client, g); },
  data: new SlashCommandBuilder()
    .setName('giveaway')
    .setDescription('Giveaways (command staff)')
    .addSubcommand((s) =>
      s.setName('start').setDescription('Start a giveaway')
        .addStringOption((o) => o.setName('prize').setDescription('What is the prize?').setRequired(true).setMaxLength(150))
        .addIntegerOption((o) => o.setName('minutes').setDescription('Duration in minutes (max 10080 = 7 days)').setRequired(true).setMinValue(1).setMaxValue(10080))
        .addIntegerOption((o) => o.setName('winners').setDescription('Number of winners (default 1)').setMinValue(1).setMaxValue(20)))
    .addSubcommand((s) => s.setName('end').setDescription('End a giveaway now').addIntegerOption((o) => o.setName('id').setDescription('Giveaway number').setRequired(true).setMinValue(1)))
    .addSubcommand((s) => s.setName('reroll').setDescription('Pick new winners').addIntegerOption((o) => o.setName('id').setDescription('Giveaway number').setRequired(true).setMinValue(1))),

  async execute(i) {
    if (!h.isCommand(i.member)) return h.deny(i, 'Μόνο η Διοίκηση μπορεί να διαχειριστεί κληρώσεις.');
    const d = db.get();
    const sub = i.options.getSubcommand();
    if (sub === 'start') {
      const g = { id: ++d.counters.giveaway, prize: i.options.getString('prize'), winners: i.options.getInteger('winners') ?? 1, endsAt: Date.now() + i.options.getInteger('minutes') * 60000, hostId: i.user.id, channelId: i.channelId, messageId: null, entries: [], ended: false, winnerIds: [] };
      await i.reply({ embeds: [embed(g, false)], components: button(g, false) });
      const msg = await i.fetchReply();
      g.messageId = msg.id; d.giveaways[g.id] = g; db.save(); schedule(i.client, g);
      return;
    }
    const g = d.giveaways[i.options.getInteger('id')];
    if (!g) return h.deny(i, 'Δεν βρέθηκε κλήρωση με αυτόν τον αριθμό.');
    if (sub === 'end') {
      if (g.ended) return h.deny(i, 'Η κλήρωση έχει ήδη λήξει.');
      await i.reply({ content: '✅ Η κλήρωση λήγει τώρα.', flags: h.EPH });
      return finish(i.client, g);
    }
    if (!g.ended) return h.deny(i, 'Η κλήρωση δεν έχει λήξει ακόμα (χρησιμοποίησε `/giveaway end`).');
    g.winnerIds = pick(g.entries, g.winners); db.save();
    return i.reply({ content: g.winnerIds.length ? `🎉 Νέοι νικητές για **${g.prize}**: ${g.winnerIds.map((x) => `<@${x}>`).join(', ')}` : 'Δεν υπήρχαν συμμετοχές.', allowedMentions: { users: g.winnerIds } });
  },

  async button(i, [, id]) {
    const g = db.get().giveaways[id];
    if (!g || g.ended) return h.deny(i, 'Η κλήρωση έχει λήξει.');
    const has = g.entries.includes(i.user.id);
    g.entries = has ? g.entries.filter((x) => x !== i.user.id) : [...g.entries, i.user.id];
    db.save();
    await i.update({ embeds: [embed(g, false)], components: button(g, false) });
    await i.followUp({ content: has ? '➖ Αποσύρθηκες από την κλήρωση.' : '🎉 Συμμετέχεις στην κλήρωση! Καλή τύχη!', flags: h.EPH });
  },
};
