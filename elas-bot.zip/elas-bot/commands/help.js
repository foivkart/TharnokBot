const { SlashCommandBuilder } = require('discord.js');
const h = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder().setName('help').setDescription('Show all commands of the ΕΛ.ΑΣ. bot'),

  async execute(i) {
    const e = h.baseEmbed().setTitle('🛡️ Bot ΕΛ.ΑΣ. – Εντολές').addFields(
      { name: '👥 Για όλους', value: '`/complaint` • `/suggest` • `/profile` • `/stats` • `/ranks` • `/info user|server|avatar|bot` • `/remind set|list|cancel` • `/application status`' },
      { name: '🕐 Υπηρεσία', value: '`/duty on|off|time|leaderboard|active|panel|inactive|adjust|forceoff|resetweek`\nΟ χρόνος μετράει μόνο όσο είσαι **On Duty και σε φωνητική κλήση**.' },
      { name: '🏷️ Μονάδες', value: '`/unit list|roster|leaderboard` — στατιστικά ανά μονάδα (ΕΚΑΜ, ΟΠΚΕ...)' },
      { name: '📻 Σήματα', value: '`/signal panel|refresh|assign|release|retire|unretire|lookup|stats` — ο πίνακας σημάτων 1-100 / 101-200' },
      { name: '👮 Προσωπικό', value: '`/roster` • `/promote` • `/demote` • `/loa` • `/commend give|list` • `/discipline warn|history|remove`' },
      { name: '⚔️ Επιχειρήσεις', value: '`/event create|list` • `/training schedule|list|stats` • `/bolo add|list|resolve` • `/report` • `/threat view|set`' },
      { name: '📣 Κοινότητα', value: '`/announce` • `/poll` • `/say text|embed` • `/giveaway start|end|reroll`' },
      { name: '📩 Αιτήματα', value: '`/ticket panel|add|remove|close|rename|claim|unclaim|priority|transfer|list|transcript|blacklist_add|blacklist_remove|stats`' },
      { name: '📝 Αιτήσεις', value: '`/application panel|toggle|list|view|interview|accept|reject|note|schedule|stats`' },
      { name: '🔨 Διαχείριση', value: '`/mod timeout|untimeout|kick|ban|unban|clear|purge|slowmode|lock|unlock|nick|role_add|role_remove|vkick|quarantine|unquarantine|note|notes`' },
      { name: '🛡️ Ασφάλεια', value: '`/security status|toggle|word_*|strikes|strikes_clear|trust_*|raidmode|lockdown|audit|exempt_*|nuke_limit|nuke_punishment|automod_setup`' },
      { name: '⚙️ Ρυθμίσεις (διαχειριστές)', value: '`/config view|channel|role|rank|rank_range|command_from|command_role|officer_role|autorole|selfrole|category|ticket_role|voice|setting` — δείχνεις στο bot τα ΔΙΚΑ ΣΟΥ κανάλια και ρόλους\n`/welcome test|rules` • `/roles panel` • `/setup` (προαιρετικό, δημιουργεί τα πάντα αυτόματα)' },
    );
    await i.reply({ embeds: [e], flags: h.EPH });
  },
};
