const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const db = require('../utils/db');
const h = require('../utils/helpers');

const DANGER = { low: { label: '🟢 Χαμηλός', color: 0x2ecc71 }, medium: { label: '🟡 Μέτριος', color: 0xf1c40f }, high: { label: '🔴 Υψηλός', color: 0xe74c3c } };
const STATUS = { active: '🚨 Ενεργό', captured: '⛓️ Συνελήφθη', cancelled: '✖️ Ακυρώθηκε' };

const embed = (b) =>
  h.baseEmbed().setColor(b.status === 'active' ? DANGER[b.danger].color : 0x7f8c8d).setTitle(`🚨 BOLO #${h.pad(b.id)} — ${b.name}`)
    .setDescription(b.description)
    .addFields(
      { name: 'Κίνδυνος', value: DANGER[b.danger].label, inline: true },
      { name: 'Κατάσταση', value: STATUS[b.status], inline: true },
      { name: 'Τελευταία θέση', value: b.location || '—', inline: true },
      { name: 'Καταχωρήθηκε από', value: `<@${b.by}> • <t:${h.unix(b.at)}:R>`, inline: false },
    );

const buttons = (b) => b.status !== 'active' ? [] : [new ActionRowBuilder().addComponents(
  new ButtonBuilder().setCustomId(`bolo:captured:${b.id}`).setLabel('Συνελήφθη').setEmoji('⛓️').setStyle(ButtonStyle.Success),
  new ButtonBuilder().setCustomId(`bolo:cancelled:${b.id}`).setLabel('Ακύρωση').setEmoji('✖️').setStyle(ButtonStyle.Secondary),
)];

async function resolve(guild, b, status, by) {
  b.status = status; b.resolvedBy = by.id; db.save();
  const ch = await guild.channels.fetch(b.channelId).catch(() => null);
  const msg = await ch?.messages.fetch(b.messageId).catch(() => null);
  if (msg) await msg.edit({ embeds: [embed(b)], components: [] }).catch(() => {});
}

module.exports = {
  prefix: 'bolo',
  data: new SlashCommandBuilder()
    .setName('bolo')
    .setDescription('Be-on-the-lookout board for wanted people')
    .addSubcommand((s) =>
      s.setName('add').setDescription('Add a wanted person')
        .addStringOption((o) => o.setName('name').setDescription('Name / description of the person').setRequired(true).setMaxLength(100))
        .addStringOption((o) => o.setName('description').setDescription('Why are they wanted? Appearance, vehicle...').setRequired(true).setMaxLength(800))
        .addStringOption((o) => o.setName('danger').setDescription('Danger level').setRequired(true).addChoices({ name: '🟢 Low', value: 'low' }, { name: '🟡 Medium', value: 'medium' }, { name: '🔴 High', value: 'high' }))
        .addStringOption((o) => o.setName('location').setDescription('Last known location').setMaxLength(100))
        .addChannelOption((o) => h.channelOpt(o, 'Post the BOLO in this channel')))
    .addSubcommand((s) => s.setName('list').setDescription('Show all active BOLOs'))
    .addSubcommand((s) =>
      s.setName('resolve').setDescription('Close a BOLO')
        .addIntegerOption((o) => o.setName('id').setDescription('BOLO number').setRequired(true).setMinValue(1))
        .addStringOption((o) => o.setName('outcome').setDescription('Outcome').setRequired(true).addChoices({ name: 'Captured', value: 'captured' }, { name: 'Cancelled', value: 'cancelled' }))),

  async execute(i) {
    if (!h.isOfficer(i.member)) return h.deny(i, 'Μόνο οι αστυνομικοί έχουν πρόσβαση στα BOLO.');
    const d = db.get();
    const sub = i.options.getSubcommand();

    if (sub === 'list') {
      const act = Object.values(d.bolos).filter((b) => b.status === 'active');
      const text = act.map((b) => `**#${h.pad(b.id)}** ${DANGER[b.danger].label} — **${b.name}** (${b.location || '—'}) [↗](https://discord.com/channels/${i.guildId}/${b.channelId}/${b.messageId})`).join('\n') || 'Δεν υπάρχουν ενεργά BOLO. 🎉';
      return i.reply({ embeds: [h.baseEmbed().setTitle(`🚨 Ενεργά BOLO (${act.length})`).setDescription(h.cut(text, 4000))], flags: h.EPH });
    }
    if (sub === 'resolve') {
      const b = d.bolos[i.options.getInteger('id')];
      if (!b || b.status !== 'active') return h.deny(i, 'Δεν βρέθηκε ενεργό BOLO με αυτόν τον αριθμό.');
      await resolve(i.guild, b, i.options.getString('outcome'), i.member);
      return i.reply({ content: `✅ Το BOLO #${h.pad(b.id)} έκλεισε (${STATUS[b.status]}).`, flags: h.EPH });
    }
    const ch = i.options.getChannel('channel') ?? await h.getChannel(i.guild, 'bolo');
    if (!ch) return h.deny(i, 'Δεν βρέθηκε το κανάλι BOLO. Τρέξε `/config`.');
    const b = { id: ++d.counters.bolo, name: i.options.getString('name'), description: i.options.getString('description'), danger: i.options.getString('danger'), location: i.options.getString('location'), status: 'active', by: i.user.id, at: Date.now(), channelId: ch.id, messageId: null };
    const msg = await ch.send({ embeds: [embed(b)], components: buttons(b) });
    b.messageId = msg.id; d.bolos[b.id] = b; db.save();
    return i.reply({ content: `✅ BOLO #${h.pad(b.id)} δημοσιεύτηκε στο ${ch}.`, flags: h.EPH });
  },

  async button(i, [outcome, id]) {
    if (!h.isOfficer(i.member)) return h.deny(i, 'Μόνο αστυνομικοί μπορούν να το κάνουν αυτό.');
    const b = db.get().bolos[id];
    if (!b || b.status !== 'active') return h.deny(i, 'Το BOLO έχει ήδη κλείσει.');
    b.status = outcome; b.resolvedBy = i.user.id; db.save();
    await i.update({ embeds: [embed(b)], components: [] });
  },
};
