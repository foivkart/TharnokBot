const {
  SlashCommandBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, ButtonBuilder, ButtonStyle,
  ChannelType, PermissionFlagsBits: P,
} = require('discord.js');
const config = require('../config');
const db = require('../utils/db');
const h = require('../utils/helpers');
const { enlist } = require('../utils/rank');
const { withBanner } = require('../utils/panelart');

const STATUS = { pending: '🟡 Σε αναμονή', interview: '🗣️ Σε συνέντευξη', accepted: '✅ Εγκρίθηκε', rejected: '❌ Απορρίφθηκε' };
const COLOR = { pending: 0xf1c40f, interview: 0x3498db, accepted: 0x2ecc71, rejected: 0xe74c3c };
const OPEN = ['pending', 'interview'];

const input = (id, label, style, max) =>
  new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId(id).setLabel(label).setStyle(style).setRequired(true).setMaxLength(max));

const panel = () => withBanner({
  embeds: [h.baseEmbed().setTitle('📝 Αίτηση Ένταξης στην ΕΛ.ΑΣ.').setDescription(config.application.info)],
  components: [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('apply:start').setLabel('Υποβολή αίτησης').setEmoji('📝').setStyle(ButtonStyle.Success),
  )],
}, 'applications');

function appEmbed(a) {
  const e = h.baseEmbed().setColor(COLOR[a.status]).setTitle(`📝 Αίτηση #${a.id} — ${a.name}`)
    .setDescription(`Υποψήφιος/α: <@${a.userId}>`)
    .addFields(
      { name: 'Κατάσταση', value: STATUS[a.status], inline: true },
      { name: 'Ηλικίες (χαρακτήρας / παίκτης)', value: a.age, inline: true },
      { name: 'Εμπειρία σε Roleplay', value: h.cut(a.experience, 1024) },
      { name: 'Ιστορικό χαρακτήρα', value: h.cut(a.story, 1024) },
      { name: 'Γιατί θέλει να ενταχθεί', value: h.cut(a.why, 1024) },
    );
  if (a.interviewAt) e.addFields({ name: '🗓️ Ραντεβού συνέντευξης', value: a.interviewAt, inline: true });
  if (a.interviewText) e.addFields({ name: 'Κανάλια συνέντευξης', value: `<#${a.interviewText}> • <#${a.interviewVoice}>`, inline: true });
  if (a.notes?.length) e.addFields({ name: `📝 Σημειώσεις (${a.notes.length})`, value: h.cut(a.notes.slice(-3).map((n) => `• <@${n.by}>: ${h.cut(n.text, 150)}`).join('\n'), 1024) });
  if (a.reviewedBy) e.addFields({ name: 'Αξιολογήθηκε από', value: `<@${a.reviewedBy}>`, inline: true });
  if (a.reason) e.addFields({ name: 'Αιτιολογία απόρριψης', value: h.cut(a.reason, 1024) });
  return e;
}

function appButtons(a) {
  const b = (action, label, style) => new ButtonBuilder().setCustomId(`apply:${action}:${a.id}`).setLabel(label).setStyle(style);
  if (a.status === 'pending') return [new ActionRowBuilder().addComponents(b('interview', 'Συνέντευξη', ButtonStyle.Primary), b('accept', 'Έγκριση', ButtonStyle.Success), b('reject', 'Απόρριψη', ButtonStyle.Danger))];
  if (a.status === 'interview') return [new ActionRowBuilder().addComponents(b('accept', 'Έγκριση', ButtonStyle.Success), b('reject', 'Απόρριψη', ButtonStyle.Danger))];
  return [];
}

async function refreshReview(guild, a) {
  const ch = await guild.channels.fetch(a.channelId).catch(() => null);
  const msg = await ch?.messages.fetch(a.messageId).catch(() => null);
  if (msg) await msg.edit({ embeds: [appEmbed(a)], components: appButtons(a) }).catch(() => {});
}

// ── core actions (used by buttons AND commands) ────────────
async function doInterview(guild, a, by) {
  const applicant = await guild.members.fetch(a.userId).catch(() => null);
  if (!applicant) return { error: 'Ο υποψήφιος δεν βρίσκεται πια στον server.' };
  const d = db.get();
  const parent = await h.categoryFor(guild, 'interviews');
  const cmdRoles = h.commandRoleList(guild);
  const textP = [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.AttachFiles];
  const voiceP = [P.ViewChannel, P.Connect, P.Speak, P.UseVAD];
  const ow = (perms) => [
    { id: guild.roles.everyone.id, deny: [P.ViewChannel] },
    { id: applicant.id, allow: perms },
    ...cmdRoles.map((r) => ({ id: r.id, allow: perms })),
    { id: guild.members.me.id, allow: [...perms, P.ManageChannels, P.MoveMembers] },
  ];
  try {
    const t = await guild.channels.create({ name: `interview-${h.pad(a.id)}`, type: ChannelType.GuildText, parent: parent?.id, topic: `Συνέντευξη αίτησης #${a.id} • ${a.name}`, permissionOverwrites: ow(textP) });
    const v = await guild.channels.create({ name: `🎙️ Συνέντευξη ${a.id}`, type: ChannelType.GuildVoice, parent: parent?.id, permissionOverwrites: ow(voiceP) });
    a.interviewText = t.id;
    a.interviewVoice = v.id;
    a.status = 'interview';
    a.reviewedBy = by.id;
    db.save();
    const waitRole = h.roleFor(guild, 'interviewWait');
    if (waitRole) await applicant.roles.add(waitRole).catch(() => {});
    await t.send({
      content: `${applicant}`,
      embeds: [h.baseEmbed().setColor(0x3498db).setTitle(`🗣️ Συνέντευξη — ${a.name}`)
        .setDescription(`Καλώς ήρθες ${applicant}! Η Διοίκηση θα σε συνεντεύξει εδώ.\nΜπες στο φωνητικό ${v} όταν σου πουν.${a.interviewAt ? `\n🗓️ Ραντεβού: **${a.interviewAt}**` : ''}`)],
      components: [new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`apply:accept:${a.id}`).setLabel('Έγκριση').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId(`apply:reject:${a.id}`).setLabel('Απόρριψη').setStyle(ButtonStyle.Danger),
      )],
    });
    await refreshReview(guild, a);
    await h.dm(applicant.user, { content: `🗣️ Η αίτησή σου **#${a.id}** πέρασε στη **συνέντευξη**! Πήγαινε στο ${t} και μπες στο φωνητικό ${v} όταν σου πουν.` });
    return { text: t, voice: v };
  } catch (e) {
    console.error('Interview channels:', e);
    return { error: 'Δεν μπόρεσα να δημιουργήσω τα κανάλια συνέντευξης (λείπουν δικαιώματα).' };
  }
}

async function closeInterview(guild, a, note) {
  const t = a.interviewText ? await guild.channels.fetch(a.interviewText).catch(() => null) : null;
  if (t) await t.send(note).catch(() => {});
  setTimeout(async () => {
    for (const id of [a.interviewText, a.interviewVoice]) if (id) await guild.channels.delete(id, 'Τέλος συνέντευξης').catch(() => {});
  }, 20000);
}

async function doAccept(guild, client, a, by) {
  const member = await guild.members.fetch(a.userId).catch(() => null);
  if (!member) return 'Ο υποψήφιος δεν βρίσκεται πια στον server.';
  try { await enlist(member, `Έγκριση αίτησης #${a.id} από ${by.user.tag}`); }
  catch { return 'Δεν μπόρεσα να δώσω τον ρόλο. Ο ρόλος του bot πρέπει να είναι πάνω από τους βαθμούς (και τρέξε /setup αν λείπουν).'; }
  a.status = 'accepted'; a.reviewedBy = by.id; a.reviewedAt = Date.now(); db.save();
  await refreshReview(guild, a);
  await h.sendTo(guild, 'staffLog', { embeds: [h.baseEmbed().setColor(0x2ecc71).setTitle('🎖️ Νέος αστυνομικός').setDescription(`${member} εντάχθηκε ως **${h.rankName(guild, 0)}** (αίτηση #${a.id}, έγκριση από ${by}).`)] });
  await h.dm(member.user, { content: `🎉 Συγχαρητήρια! Η αίτησή σου στην ΕΛ.ΑΣ. **εγκρίθηκε**. Είσαι πλέον **${h.rankName(guild, 0)}**. Πάτησε **On Duty** στο πάνελ υπηρεσίας για να ξεκινήσεις!` });
  if (db.get().channels.appAccepted) await h.sendTo(guild, 'appAccepted', { embeds: [appEmbed(a)] });
  await closeInterview(guild, a, '✅ **Η αίτηση εγκρίθηκε!** Τα κανάλια θα διαγραφούν σε 20 δευτερόλεπτα.');
  return null;
}

async function doReject(guild, client, a, by, reason) {
  a.status = 'rejected'; a.reviewedBy = by.id; a.reviewedAt = Date.now(); a.reason = reason; db.save();
  await refreshReview(guild, a);
  const applicantM = await guild.members.fetch(a.userId).catch(() => null);
  if (applicantM) {
    const wait = h.roleFor(guild, 'interviewWait');
    const denied = h.roleFor(guild, 'interviewDenied');
    if (wait) await applicantM.roles.remove(wait).catch(() => {});
    if (denied) await applicantM.roles.add(denied).catch(() => {});
  }
  if (db.get().channels.appDenied) await h.sendTo(guild, 'appDenied', { embeds: [appEmbed(a)] });
  const user = await client.users.fetch(a.userId).catch(() => null);
  if (user) await h.dm(user, { content: `❌ Λυπούμαστε, η αίτησή σου **#${a.id}** στην ΕΛ.ΑΣ. απορρίφθηκε.\n**Αιτιολογία:** ${reason}\nΜπορείς να υποβάλεις νέα αίτηση${h.setting('applicationCooldownDays') ? ` μετά από ${h.setting('applicationCooldownDays')} ημέρες` : ' αργότερα'}.` });
  await closeInterview(guild, a, '❌ **Η αίτηση απορρίφθηκε.** Τα κανάλια θα διαγραφούν σε 20 δευτερόλεπτα.');
}

const idOpt = (o) => o.setName('id').setDescription('Application number').setRequired(true).setMinValue(1);

module.exports = {
  prefix: 'apply',
  panel,
  data: new SlashCommandBuilder()
    .setName('application')
    .setDescription('Recruitment applications and interviews')
    .addSubcommand((s) => s.setName('panel').setDescription('Post the application panel (command staff)').addChannelOption((o) => h.channelOpt(o, 'Where to post the panel (default: here)')))
    .addSubcommand((s) => s.setName('status').setDescription('Check the status of your application'))
    .addSubcommand((s) =>
      s.setName('toggle').setDescription('Open or close applications (command staff)')
        .addStringOption((o) => o.setName('state').setDescription('New state').setRequired(true).addChoices({ name: 'Open', value: 'open' }, { name: 'Closed', value: 'closed' })))
    .addSubcommand((s) =>
      s.setName('list').setDescription('List applications (command staff)')
        .addStringOption((o) => o.setName('status').setDescription('Filter').addChoices(
          { name: 'Pending', value: 'pending' }, { name: 'Interview', value: 'interview' }, { name: 'Accepted', value: 'accepted' }, { name: 'Rejected', value: 'rejected' }, { name: 'All', value: 'all' })))
    .addSubcommand((s) => s.setName('view').setDescription('Show one application (command staff)').addIntegerOption(idOpt))
    .addSubcommand((s) => s.setName('interview').setDescription('Start the interview (creates private channels)').addIntegerOption(idOpt))
    .addSubcommand((s) => s.setName('accept').setDescription('Accept an application (command staff)').addIntegerOption(idOpt))
    .addSubcommand((s) =>
      s.setName('reject').setDescription('Reject an application (command staff)').addIntegerOption(idOpt)
        .addStringOption((o) => o.setName('reason').setDescription('Reason').setRequired(true).setMaxLength(500)))
    .addSubcommand((s) =>
      s.setName('note').setDescription('Add a private staff note to an application').addIntegerOption(idOpt)
        .addStringOption((o) => o.setName('text').setDescription('The note').setRequired(true).setMaxLength(500)))
    .addSubcommand((s) =>
      s.setName('schedule').setDescription('Set the interview date/time and notify the applicant').addIntegerOption(idOpt)
        .addStringOption((o) => o.setName('when').setDescription('e.g. Friday 21:00').setRequired(true).setMaxLength(100)))
    .addSubcommand((s) => s.setName('stats').setDescription('Application statistics (command staff)')),

  async execute(i) {
    const sub = i.options.getSubcommand();
    const d = db.get();
    if (sub === 'status') {
      const mine = Object.values(d.applications).filter((a) => a.userId === i.user.id).at(-1);
      return mine ? i.reply({ embeds: [appEmbed(mine)], flags: h.EPH }) : i.reply({ content: 'Δεν έχεις υποβάλει αίτηση ακόμα.', flags: h.EPH });
    }
    if (!h.isCommand(i.member)) return h.deny(i, 'Μόνο η Διοίκηση μπορεί να το κάνει αυτό.');

    if (sub === 'panel') { const target = i.options.getChannel('channel') ?? i.channel; await target.send(panel()); return i.reply({ content: `✅ Το πάνελ αιτήσεων δημοσιεύτηκε στο ${target}.`, flags: h.EPH }); }
    if (sub === 'toggle') {
      d.settings.applicationsOpen = i.options.getString('state') === 'open';
      db.save();
      return i.reply({ content: `✅ Οι αιτήσεις είναι τώρα **${d.settings.applicationsOpen ? 'ανοιχτές 🟢' : 'κλειστές 🔴'}**.`, flags: h.EPH });
    }
    if (sub === 'stats') {
      const all = Object.values(d.applications);
      const c = (s) => all.filter((a) => a.status === s).length;
      const decided = c('accepted') + c('rejected');
      return i.reply({ embeds: [h.baseEmbed().setTitle('📊 Στατιστικά αιτήσεων').addFields(
        { name: 'Σύνολο', value: String(all.length), inline: true }, { name: '🟡 Σε αναμονή', value: String(c('pending')), inline: true },
        { name: '🗣️ Συνέντευξη', value: String(c('interview')), inline: true }, { name: '✅ Εγκρίθηκαν', value: String(c('accepted')), inline: true },
        { name: '❌ Απορρίφθηκαν', value: String(c('rejected')), inline: true }, { name: 'Ποσοστό αποδοχής', value: decided ? `${Math.round((c('accepted') / decided) * 100)}%` : '—', inline: true },
        { name: 'Αιτήσεις', value: d.settings.applicationsOpen ? '🟢 ανοιχτές' : '🔴 κλειστές', inline: true },
      )], flags: h.EPH });
    }
    if (sub === 'list') {
      const f = i.options.getString('status') ?? 'pending';
      const rows = Object.values(d.applications).filter((a) => f === 'all' || a.status === f).slice(-20).reverse();
      const text = rows.map((a) => `**#${a.id}** ${a.name} • <@${a.userId}> • ${STATUS[a.status]} • <t:${h.unix(a.createdAt)}:R>`).join('\n') || 'Καμία αίτηση.';
      return i.reply({ embeds: [h.baseEmbed().setTitle(`📋 Αιτήσεις (${f})`).setDescription(h.cut(text, 4000))], flags: h.EPH, allowedMentions: { parse: [] } });
    }

    const a = d.applications[i.options.getInteger('id')];
    if (!a) return h.deny(i, 'Δεν βρέθηκε αίτηση με αυτόν τον αριθμό.');
    if (sub === 'view') return i.reply({ embeds: [appEmbed(a)], flags: h.EPH });
    if (sub === 'note') {
      (a.notes ??= []).push({ by: i.user.id, text: i.options.getString('text'), at: Date.now() });
      db.save(); await refreshReview(i.guild, a);
      return i.reply({ content: `✅ Σημείωση προστέθηκε στην αίτηση #${a.id}.`, flags: h.EPH });
    }
    if (!OPEN.includes(a.status)) return h.deny(i, 'Η αίτηση έχει ήδη αξιολογηθεί.');

    if (sub === 'schedule') {
      a.interviewAt = i.options.getString('when'); db.save(); await refreshReview(i.guild, a);
      const u = await i.client.users.fetch(a.userId).catch(() => null);
      if (u) await h.dm(u, { content: `🗓️ Η συνέντευξη για την αίτησή σου **#${a.id}** προγραμματίστηκε: **${a.interviewAt}**.` });
      return i.reply({ content: `✅ Ραντεβού: **${a.interviewAt}** (ο υποψήφιος ειδοποιήθηκε).`, flags: h.EPH });
    }
    await i.deferReply({ flags: h.EPH });
    if (sub === 'interview') {
      if (a.status === 'interview') return i.editReply('⛔ Η συνέντευξη έχει ήδη ξεκινήσει.');
      const r = await doInterview(i.guild, a, i.member);
      return i.editReply(r.error ? `⚠️ ${r.error}` : `✅ Δημιουργήθηκαν ${r.text} και ${r.voice}.`);
    }
    if (sub === 'accept') { const err = await doAccept(i.guild, i.client, a, i.member); return i.editReply(err ? `⛔ ${err}` : '✅ Η αίτηση εγκρίθηκε.'); }
    if (sub === 'reject') { await doReject(i.guild, i.client, a, i.member, i.options.getString('reason')); return i.editReply('✅ Η αίτηση απορρίφθηκε.'); }
  },

  async button(i, [action, id]) {
    const d = db.get();
    if (action === 'start') {
      if (!d.settings.applicationsOpen) return h.deny(i, 'Οι αιτήσεις είναι προς το παρόν **κλειστές**.');
      if (h.isStaff(i.member)) return h.deny(i, 'Είσαι ήδη αστυνομικός της ΕΛ.ΑΣ.');
      const blRole = h.roleFor(i.guild, 'blacklisted');
      if (blRole && i.member.roles.cache.has(blRole.id)) return h.deny(i, 'Δεν μπορείς να υποβάλεις αίτηση.');
      const mine = Object.values(d.applications).filter((a) => a.userId === i.user.id);
      if (mine.some((a) => OPEN.includes(a.status))) return h.deny(i, 'Έχεις ήδη μια αίτηση σε εξέλιξη. Δες την κατάστασή της με `/application status`.');
      const last = mine.filter((a) => a.status === 'rejected').at(-1);
      const wait = h.setting('applicationCooldownDays') * 86400000;
      if (last && wait && Date.now() - (last.reviewedAt ?? 0) < wait) return h.deny(i, `Πρέπει να περιμένεις μέχρι <t:${h.unix(last.reviewedAt + wait)}:R> για νέα αίτηση.`);
      return i.showModal(
        new ModalBuilder().setCustomId('apply:form').setTitle('Αίτηση ένταξης ΕΛ.ΑΣ.').addComponents(
          input('name', 'Όνομα χαρακτήρα', TextInputStyle.Short, 80),
          input('age', 'Ηλικία χαρακτήρα / ηλικία παίκτη', TextInputStyle.Short, 60),
          input('experience', 'Εμπειρία σε Roleplay', TextInputStyle.Paragraph, 1000),
          input('story', 'Ιστορικό χαρακτήρα', TextInputStyle.Paragraph, 1000),
          input('why', 'Γιατί θέλεις να ενταχθείς στην ΕΛ.ΑΣ.;', TextInputStyle.Paragraph, 1000),
        ),
      );
    }
    if (!h.isCommand(i.member)) return h.deny(i, 'Μόνο η Διοίκηση μπορεί να αξιολογήσει αιτήσεις.');
    const a = d.applications[id];
    if (!a) return h.deny(i, 'Η αίτηση δεν βρέθηκε.');
    if (!OPEN.includes(a.status)) return h.deny(i, 'Η αίτηση έχει ήδη αξιολογηθεί.');
    if (action === 'reject') {
      return i.showModal(new ModalBuilder().setCustomId(`apply:reject:${id}`).setTitle('Απόρριψη αίτησης').addComponents(input('reason', 'Αιτιολογία απόρριψης', TextInputStyle.Paragraph, 500)));
    }
    await i.deferReply({ flags: h.EPH });
    if (action === 'interview') {
      if (a.status === 'interview') return i.editReply('⛔ Η συνέντευξη έχει ήδη ξεκινήσει.');
      const r = await doInterview(i.guild, a, i.member);
      return i.editReply(r.error ? `⚠️ ${r.error}` : `✅ Δημιουργήθηκαν ${r.text} και ${r.voice}.`);
    }
    if (action === 'accept') { const err = await doAccept(i.guild, i.client, a, i.member); return i.editReply(err ? `⛔ ${err}` : '✅ Η αίτηση εγκρίθηκε και ο υποψήφιος πήρε τον πρώτο βαθμό.'); }
  },

  async modal(i, [kind, id]) {
    const d = db.get();
    if (kind === 'form') {
      const f = (k) => i.fields.getTextInputValue(k).trim();
      const ch = await h.getChannel(i.guild, 'appReview');
      if (!ch) return i.reply({ content: '⚠️ Δεν βρέθηκε το κανάλι αξιολόγησης. Ειδοποίησε διαχειριστή (`/config`).', flags: h.EPH });
      const a = {
        id: ++d.counters.application, userId: i.user.id, name: f('name'), age: f('age'), experience: f('experience'), story: f('story'), why: f('why'),
        status: 'pending', reviewedBy: null, reviewedAt: null, reason: null, createdAt: Date.now(), notes: [],
        channelId: ch.id, messageId: null, interviewText: null, interviewVoice: null, interviewAt: null,
      };
      const msg = await ch.send({ embeds: [appEmbed(a)], components: appButtons(a) });
      a.messageId = msg.id;
      d.applications[a.id] = a;
      db.save();
      return i.reply({ content: `✅ Η αίτησή σου υποβλήθηκε με αριθμό **#${a.id}**. Θα ενημερωθείς με μήνυμα όταν αξιολογηθεί.`, flags: h.EPH });
    }
    if (kind === 'reject') {
      if (!h.isCommand(i.member)) return h.deny(i, 'Μόνο η Διοίκηση μπορεί να αξιολογήσει αιτήσεις.');
      const a = d.applications[id];
      if (!a || !OPEN.includes(a.status)) return h.deny(i, 'Η αίτηση έχει ήδη αξιολογηθεί.');
      await doReject(i.guild, i.client, a, i.member, i.fields.getTextInputValue('reason').trim());
      return i.reply({ content: '✅ Η αίτηση απορρίφθηκε.', flags: h.EPH });
    }
  },
};
