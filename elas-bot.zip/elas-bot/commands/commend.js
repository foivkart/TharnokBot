const { SlashCommandBuilder } = require('discord.js');
const db = require('../utils/db');
const h = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('commend')
    .setDescription('Commendations for officers')
    .addSubcommand((s) =>
      s.setName('give').setDescription('Give an officer a commendation (command staff)')
        .addUserOption((o) => o.setName('officer').setDescription('Which officer').setRequired(true))
        .addStringOption((o) => o.setName('reason').setDescription('Why?').setRequired(true).setMaxLength(400)))
    .addSubcommand((s) =>
      s.setName('list').setDescription('Show an officer\'s commendations')
        .addUserOption((o) => o.setName('officer').setDescription('Which officer (default: you)'))),

  async execute(i) {
    const d = db.get();
    if (i.options.getSubcommand() === 'list') {
      const u = i.options.getUser('officer') ?? i.user;
      const list = d.commends[u.id] ?? [];
      const text = list.slice(-10).reverse().map((c) => `🏅 <t:${h.unix(c.at)}:d> • <@${c.by}>: ${h.cut(c.reason, 200)}`).join('\n') || 'Δεν υπάρχουν έπαινοι ακόμα.';
      return i.reply({ embeds: [h.baseEmbed().setTitle(`🏅 Έπαινοι – ${u.username} (${list.length})`).setDescription(text)], flags: h.EPH, allowedMentions: { parse: [] } });
    }
    if (!h.isCommand(i.member)) return h.deny(i, 'Μόνο η Διοίκηση μπορεί να δίνει επαίνους.');
    const m = i.options.getMember('officer');
    if (!m || !h.isStaff(m)) return h.deny(i, 'Ο χρήστης πρέπει να είναι αστυνομικός.');
    if (m.id === i.user.id) return h.deny(i, 'Δεν μπορείς να επαινέσεις τον εαυτό σου.');
    const reason = i.options.getString('reason');
    (d.commends[m.id] ??= []).push({ by: i.user.id, reason, at: Date.now() });
    db.save();
    const e = h.baseEmbed().setColor(0xf1c40f).setTitle('🏅 Έπαινος').setDescription(`${m}`).addFields({ name: 'Λόγος', value: reason }, { name: 'Από', value: `${i.member}`, inline: true }, { name: 'Σύνολο', value: String(d.commends[m.id].length), inline: true });
    await h.sendTo(i.guild, 'staffLog', { embeds: [e] });
    await h.dm(m.user, { embeds: [e] });
    return i.reply({ embeds: [e] });
  },
};
