const { SlashCommandBuilder } = require('discord.js');
const db = require('../utils/db');
const h = require('../utils/helpers');
const duty = require('../utils/duty');
const sig = require('../utils/signals');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unit')
    .setDescription('Unit statistics (ΕΚΑΜ, ΟΠΚΕ... set with /config unit)')
    .addSubcommand((s) => s.setName('list').setDescription('All units: members, on duty, call time this week'))
    .addSubcommand((s) =>
      s.setName('roster').setDescription('Members of one unit')
        .addRoleOption((o) => o.setName('unit').setDescription('The unit role').setRequired(true)))
    .addSubcommand((s) => s.setName('leaderboard').setDescription('Units ranked by call time this week')),

  async execute(i) {
    if (!h.isOfficer(i.member)) return h.deny(i, 'Μόνο οι αστυνομικοί έχουν πρόσβαση στις μονάδες.');
    const units = h.unitList(i.guild);
    if (!units.length) return h.deny(i, 'Δεν έχουν οριστεί μονάδες. Η Διοίκηση τις ορίζει με `/config unit`.');
    await i.deferReply();
    const members = await i.guild.members.fetch();
    const d = db.get().duty;
    const stats = units.map((u) => {
      const ms = members.filter((m) => !m.user.bot && m.roles.cache.has(u.roleId));
      let on = 0; let call = 0; let week = 0;
      for (const m of ms.values()) { if (d[m.id]?.onDuty) on++; if (duty.inCall(m.id)) call++; week += duty.weekMs(m.id); }
      return { u, ms, on, call, week };
    });
    const sub = i.options.getSubcommand();

    if (sub === 'list') {
      const text = stats.map((s) => `\`${s.u.code}\` ${s.u.role} — **${s.ms.size}** μέλη • 🟢 ${s.on} On Duty • 🎧 ${s.call} • ${h.fmtDuration(s.week)} αυτή την εβδομάδα`).join('\n');
      return i.editReply({ embeds: [h.baseEmbed().setTitle('🏷️ Μονάδες').setDescription(h.cut(text, 4000))], allowedMentions: { parse: [] } });
    }

    if (sub === 'leaderboard') {
      const medals = ['🥇', '🥈', '🥉'];
      const text = [...stats].sort((a, b) => b.week - a.week).map((s, n) => `${medals[n] ?? `**${n + 1}.**`} ${s.u.role} — **${h.fmtDuration(s.week)}** • ${s.ms.size} μέλη`).join('\n');
      return i.editReply({ embeds: [h.baseEmbed().setTitle('🏆 Κατάταξη μονάδων (εβδομάδα)').setDescription(h.cut(text, 4000))], allowedMentions: { parse: [] } });
    }

    const role = i.options.getRole('unit');
    const s = stats.find((x) => x.u.roleId === role.id);
    if (!s) return i.editReply('⛔ Αυτός ο ρόλος δεν είναι μονάδα. Δες τις μονάδες με `/unit list`.');
    const L = h.ladder(i.guild);
    const rows = [...s.ms.values()].sort((a, b) => h.rankIndex(b) - h.rankIndex(a)).map((m) => {
      const r = h.rankIndex(m);
      const cs = sig.callsignOf(m.id);
      return `${duty.inCall(m.id) ? '🎧' : d[m.id]?.onDuty ? '🟢' : '⚫'} ${m} — ${r >= 0 ? L[r].name : 'χωρίς βαθμό'}${cs ? ` \`${cs}\`` : ''}`;
    });
    return i.editReply({ embeds: [h.baseEmbed().setTitle(`🏷️ ${s.u.name} (${s.u.code}) — ${s.ms.size} μέλη`).setDescription(h.cut(rows.join('\n') || 'Κανένα μέλος.', 4000))], allowedMentions: { parse: [] } });
  },
};
