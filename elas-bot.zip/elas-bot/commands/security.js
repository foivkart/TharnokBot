const {
  SlashCommandBuilder, AutoModerationRuleEventType: ET, AutoModerationRuleTriggerType: TT,
  AutoModerationRuleKeywordPresetType: PT, AutoModerationActionType: AT,
} = require('discord.js');
const config = require('../config');
const db = require('../utils/db');
const h = require('../utils/helpers');
const sec = require('../utils/security');
const filter = require('../utils/textfilter');
const raid = require('../utils/raid');
const lockdown = require('../utils/lockdown');

const MODULES = {
  badWords: 'Bad language filter', invites: 'Invite links', links: 'Link filter', mentions: 'Mass mentions', caps: 'Excessive caps',
  emoji: 'Emoji spam', zalgo: 'Glitch text', spam: 'Message flood', duplicates: 'Duplicate spam', nicknames: 'Nickname filter',
  antiNuke: 'Anti-nuke', antiRaid: 'Anti-raid', accountAge: 'Account age gate',
};
const word = (o) => o.setName('word').setDescription('Word or phrase').setRequired(true).setMaxLength(60);
const member = (o) => o.setName('member').setDescription('Which member').setRequired(true);
const user = (o) => o.setName('user').setDescription('Which user').setRequired(true);

module.exports = {
  data: new SlashCommandBuilder()
    .setName('security')
    .setDescription('Security: AutoMod, anti-nuke, anti-raid (command staff)')
    .addSubcommand((s) => s.setName('status').setDescription('Show all security modules and settings'))
    .addSubcommand((s) =>
      s.setName('toggle').setDescription('Turn a security module on or off (admins)')
        .addStringOption((o) => o.setName('module').setDescription('Module').setRequired(true).addChoices(...Object.entries(MODULES).map(([value, name]) => ({ name, value }))))
        .addBooleanOption((o) => o.setName('enabled').setDescription('On or off').setRequired(true)))
    .addSubcommand((s) =>
      s.setName('word_add').setDescription('Add a custom banned word/phrase').addStringOption(word)
        .addStringOption((o) => o.setName('severity').setDescription('Severity').addChoices({ name: 'Swear (1 strike)', value: 'swear' }, { name: 'Slur (2 strikes)', value: 'slur' })))
    .addSubcommand((s) => s.setName('word_remove').setDescription('Remove a custom banned word').addStringOption(word))
    .addSubcommand((s) => s.setName('word_allow').setDescription('Never flag this word (fixes false positives)').addStringOption(word))
    .addSubcommand((s) => s.setName('word_list').setDescription('Show custom and allowed words'))
    .addSubcommand((s) => s.setName('word_test').setDescription('Test what the filter does with a text').addStringOption((o) => o.setName('text').setDescription('Text to test').setRequired(true).setMaxLength(300)))
    .addSubcommand((s) => s.setName('strikes').setDescription('Show a member\'s AutoMod strikes').addUserOption(member))
    .addSubcommand((s) => s.setName('strikes_clear').setDescription('Reset a member\'s strikes').addUserOption(member))
    .addSubcommand((s) => s.setName('trust_add').setDescription('Trust a user (immune to anti-nuke, can add bots) (admins)').addUserOption(user))
    .addSubcommand((s) => s.setName('trust_remove').setDescription('Remove a trusted user (admins)').addUserOption(user))
    .addSubcommand((s) => s.setName('trust_list').setDescription('List trusted users'))
    .addSubcommand((s) =>
      s.setName('raidmode').setDescription('Manually start/stop raid mode (pauses invites)')
        .addStringOption((o) => o.setName('state').setDescription('On or off').setRequired(true).addChoices({ name: 'On', value: 'on' }, { name: 'Off', value: 'off' })))
    .addSubcommand((s) => s.setName('automod_setup').setDescription('Create Discord native AutoMod rules (admins)'))
    .addSubcommand((s) =>
      s.setName('lockdown').setDescription('Lock ALL public channels (emergency) or lift it')
        .addStringOption((o) => o.setName('state').setDescription('On or off').setRequired(true).addChoices({ name: 'On', value: 'on' }, { name: 'Off', value: 'off' }))
        .addStringOption((o) => o.setName('reason').setDescription('Reason').setMaxLength(200)))
    .addSubcommand((s) =>
      s.setName('audit').setDescription('Latest security events')
        .addIntegerOption((o) => o.setName('count').setDescription('How many (1-25, default 10)').setMinValue(1).setMaxValue(25)))
    .addSubcommand((s) =>
      s.setName('exempt_channel').setDescription('Make a channel immune to the chat filters (admins)')
        .addChannelOption((o) => o.setName('channel').setDescription('Which channel').setRequired(true))
        .addBooleanOption((o) => o.setName('enabled').setDescription('Exempt or not').setRequired(true)))
    .addSubcommand((s) =>
      s.setName('exempt_role').setDescription('Make a role immune to the chat filters (admins)')
        .addRoleOption((o) => o.setName('role').setDescription('Which role').setRequired(true))
        .addBooleanOption((o) => o.setName('enabled').setDescription('Exempt or not').setRequired(true)))
    .addSubcommand((s) =>
      s.setName('nuke_limit').setDescription('Change an anti-nuke threshold (admins)')
        .addStringOption((o) => o.setName('type').setDescription('Action type').setRequired(true).addChoices(...Object.keys(config.security.antiNuke.limits).map((k) => ({ name: k, value: k }))))
        .addIntegerOption((o) => o.setName('value').setDescription('Max allowed within the time window').setRequired(true).setMinValue(1).setMaxValue(50)))
    .addSubcommand((s) =>
      s.setName('nuke_punishment').setDescription('What happens to an attacker (admins)')
        .addStringOption((o) => o.setName('action').setDescription('Punishment').setRequired(true).addChoices({ name: 'Ban', value: 'ban' }, { name: 'Kick', value: 'kick' }, { name: 'Strip all roles', value: 'strip' }))),

  async execute(i) {
    if (!h.isCommand(i.member)) return h.deny(i, 'Μόνο η Διοίκηση έχει πρόσβαση στις ρυθμίσεις ασφαλείας.');
    const sub = i.options.getSubcommand();
    const S = sec.S();
    const adminOnly = ['toggle', 'trust_add', 'trust_remove', 'automod_setup', 'exempt_channel', 'exempt_role', 'nuke_limit', 'nuke_punishment'];
    if (adminOnly.includes(sub) && !h.isAdmin(i.member)) return h.deny(i, 'Μόνο οι διαχειριστές μπορούν να το κάνουν αυτό.');

    if (sub === 'status') {
      const on = (k) => (sec.moduleOn(k) ? '✅' : '❌');
      const keys = Object.keys(MODULES);
      const half = Math.ceil(keys.length / 2);
      const col = (arr) => arr.map((k) => `${on(k)} ${MODULES[k]}`).join('\n');
      const st = filter.stats();
      const nuke = config.security.antiNuke;
      const e = h.baseEmbed().setTitle('🛡️ Κατάσταση Ασφαλείας')
        .addFields(
          { name: 'Modules', value: col(keys.slice(0, half)), inline: true },
          { name: '\u200b', value: col(keys.slice(half)), inline: true },
          { name: 'Φίλτρο λέξεων', value: `${st.languages} γλώσσες • ${st.words} λέξεις • ${S.customWords.length} custom • ${S.allowWords.length} allowed`, inline: false },
          { name: 'Κλίμακα ποινών (strikes)', value: config.security.ladder.map((l) => `**${l.at}** → ${l.action}${l.minutes ? ` ${l.minutes}λ` : ''}`).join(' • '), inline: false },
          { name: 'Anti-nuke', value: `Τιμωρία: **${sec.nukePunishment()}** • παράθυρο ${nuke.windowSeconds}δ • trusted: ${S.trusted.length + nuke.trusted.length}`, inline: false },
          { name: 'Raid mode / Lockdown', value: `${S.raid.active ? `🚨 Raid ΕΝΕΡΓΟ — λήγει <t:${h.unix(S.raid.endsAt)}:R>` : '✅ Raid ανενεργό'} • ${S.lockdown.active ? '🔒 Lockdown ΕΝΕΡΓΟ' : '🔓 Lockdown ανενεργό'}`, inline: false },
        );
      return i.reply({ embeds: [e], flags: h.EPH });
    }

    if (sub === 'toggle') {
      const k = i.options.getString('module');
      const v = i.options.getBoolean('enabled');
      S.modules[k] = v;
      db.save();
      await sec.logSec(i.guild, { color: v ? 0x2ecc71 : 0xe67e22, title: '⚙️ Αλλαγή ρύθμισης ασφαλείας', description: `Ο/Η ${i.member} ${v ? 'ενεργοποίησε' : 'απενεργοποίησε'} το **${MODULES[k]}**.` });
      return i.reply({ content: `${v ? '✅' : '❌'} **${MODULES[k]}**: ${v ? 'ενεργό' : 'ανενεργό'}.`, flags: h.EPH });
    }

    if (sub === 'word_add') {
      const w = i.options.getString('word').trim();
      const severe = i.options.getString('severity') === 'slur';
      if (!S.customWords.some((x) => x.word === w)) S.customWords.push({ word: w, severe });
      S.allowWords = S.allowWords.filter((x) => filter.norm(x) !== filter.norm(w));
      db.save(); sec.loadFilter();
      return i.reply({ content: `✅ Η λέξη/φράση προστέθηκε (${severe ? 'slur' : 'swear'}). Δοκίμασέ την με \`/security word_test\`.`, flags: h.EPH });
    }
    if (sub === 'word_remove') {
      const w = i.options.getString('word').trim();
      const before = S.customWords.length;
      S.customWords = S.customWords.filter((x) => filter.norm(x.word) !== filter.norm(w));
      db.save(); sec.loadFilter();
      return i.reply({ content: before === S.customWords.length ? '⛔ Δεν βρέθηκε στις custom λέξεις (οι ενσωματωμένες λέξεις αποκλείονται με `/security word_allow`).' : '✅ Αφαιρέθηκε.', flags: h.EPH });
    }
    if (sub === 'word_allow') {
      const w = i.options.getString('word').trim();
      if (!S.allowWords.includes(w)) S.allowWords.push(w);
      db.save(); sec.loadFilter();
      return i.reply({ content: `✅ Η λέξη «${w}» δεν θα επισημαίνεται πια.`, flags: h.EPH });
    }
    if (sub === 'word_list') {
      const custom = S.customWords.map((x) => `${x.severe ? '🔴' : '🟠'} ${x.word}`).join('\n') || '—';
      const allow = S.allowWords.map((x) => `✅ ${x}`).join('\n') || '—';
      return i.reply({ embeds: [h.baseEmbed().setTitle('📃 Λέξεις').addFields({ name: 'Custom', value: h.cut(custom, 1000) }, { name: 'Επιτρεπόμενες (allow)', value: h.cut(allow, 1000) })], flags: h.EPH });
    }
    if (sub === 'word_test') {
      const r = filter.check(i.options.getString('text'));
      return i.reply({ content: r ? `🚫 **Θα μπλοκαριζόταν** — γλώσσα: \`${r.lang}\`, λέξη: «${r.word}», βαρύτητα: **${r.severity}** (${r.severity === 'slur' ? config.security.severeStrikes : 1} strike).` : '✅ Δεν θα μπλοκαριζόταν.', flags: h.EPH });
    }

    if (sub === 'strikes' || sub === 'strikes_clear') {
      const u = i.options.getUser('member');
      if (sub === 'strikes_clear') { sec.clearStrikes(u.id); return i.reply({ content: `✅ Τα strikes του/της ${u} μηδενίστηκαν.`, flags: h.EPH }); }
      const n = sec.strikesOf(u.id);
      const log = (S.strikes[u.id]?.log ?? []).slice(-6).reverse().map((x) => `<t:${h.unix(x.at)}:R> +${x.n} — ${x.reason}`).join('\n') || '—';
      return i.reply({ embeds: [h.baseEmbed().setTitle(`⚖️ Strikes – ${u.username}`).setDescription(`Τρέχοντα strikes: **${n}**\n\n${log}`)], flags: h.EPH });
    }

    if (sub === 'trust_add') {
      const u = i.options.getUser('user');
      if (!S.trusted.includes(u.id)) S.trusted.push(u.id);
      db.save();
      return i.reply({ content: `✅ Ο/Η ${u} είναι πλέον **trusted** (ασυλία από anti-nuke, μπορεί να προσθέτει bots).`, flags: h.EPH });
    }
    if (sub === 'trust_remove') {
      const u = i.options.getUser('user');
      S.trusted = S.trusted.filter((x) => x !== u.id);
      db.save();
      return i.reply({ content: `✅ Ο/Η ${u} αφαιρέθηκε από τους trusted.`, flags: h.EPH });
    }
    if (sub === 'trust_list') {
      const ids = [i.guild.ownerId, i.client.user.id, ...config.security.antiNuke.trusted, ...S.trusted];
      return i.reply({ embeds: [h.baseEmbed().setTitle('🔑 Trusted').setDescription([...new Set(ids)].map((id) => `<@${id}>`).join('\n'))], flags: h.EPH, allowedMentions: { parse: [] } });
    }

    if (sub === 'raidmode') {
      await i.deferReply({ flags: h.EPH });
      if (i.options.getString('state') === 'on') {
        const ok = await raid.startRaid(i.guild, `Χειροκίνητη ενεργοποίηση από ${i.member}`, []);
        return i.editReply(ok ? '🚨 Το raid mode ενεργοποιήθηκε.' : 'Το raid mode είναι ήδη ενεργό.');
      }
      const ok = await raid.endRaid(i.guild, `${i.member}`);
      return i.editReply(ok ? '✅ Το raid mode απενεργοποιήθηκε.' : 'Το raid mode δεν ήταν ενεργό.');
    }

    if (sub === 'lockdown') {
      await i.deferReply({ flags: h.EPH });
      if (i.options.getString('state') === 'on') {
        const n = await lockdown.lock(i.guild, `${i.member}`, i.options.getString('reason') ?? 'Χειροκίνητο lockdown');
        return i.editReply(n ? `🔒 Κλειδώθηκαν **${n}** κανάλια. Ξεκλείδωμα: \`/security lockdown off\`.` : 'Το lockdown είναι ήδη ενεργό (ή δεν υπάρχουν κανάλια).');
      }
      const n = await lockdown.unlock(i.guild, `${i.member}`);
      return i.editReply(n ? `🔓 Ξεκλειδώθηκαν **${n}** κανάλια.` : 'Το lockdown δεν ήταν ενεργό.');
    }

    if (sub === 'audit') {
      const n = i.options.getInteger('count') ?? 10;
      const rows = S.events.slice(-n).reverse().map((e) => `<t:${h.unix(e.at)}:R> **${e.title}** — ${e.text || '—'}`);
      return i.reply({ embeds: [h.baseEmbed().setTitle(`🧾 Συμβάντα ασφαλείας (${rows.length})`).setDescription(h.cut(rows.join('\n') || 'Κανένα συμβάν ακόμα.', 4000))], flags: h.EPH, allowedMentions: { parse: [] } });
    }

    if (sub === 'exempt_channel') {
      const ch = i.options.getChannel('channel');
      const on = i.options.getBoolean('enabled');
      S.exemptChannels = S.exemptChannels.filter((x) => x !== ch.id);
      if (on) S.exemptChannels.push(ch.id);
      db.save();
      return i.reply({ content: on ? `✅ Το ${ch} δεν ελέγχεται πια από τα φίλτρα.` : `✅ Το ${ch} ελέγχεται ξανά.`, flags: h.EPH });
    }
    if (sub === 'exempt_role') {
      const role = i.options.getRole('role');
      const on = i.options.getBoolean('enabled');
      S.exemptRoles = S.exemptRoles.filter((x) => x !== role.name);
      if (on) S.exemptRoles.push(role.name);
      db.save();
      return i.reply({ content: on ? `✅ Ο ρόλος **${role.name}** δεν ελέγχεται πια από τα φίλτρα.` : `✅ Ο ρόλος **${role.name}** ελέγχεται ξανά.`, flags: h.EPH });
    }
    if (sub === 'nuke_limit') {
      const k = i.options.getString('type');
      S.nukeLimits[k] = i.options.getInteger('value');
      db.save();
      return i.reply({ content: `✅ Anti-nuke **${k}**: τιμωρία όταν γίνουν ${S.nukeLimits[k]} μέσα σε ${config.security.antiNuke.windowSeconds}δ.`, flags: h.EPH });
    }
    if (sub === 'nuke_punishment') {
      S.nukePunishment = i.options.getString('action');
      db.save();
      return i.reply({ content: `✅ Τιμωρία anti-nuke: **${S.nukePunishment}**.`, flags: h.EPH });
    }

    if (sub === 'automod_setup') {
      await i.deferReply({ flags: h.EPH });
      const alertId = db.get().channels.modLog;
      const exemptRoles = h.commandRoleList(i.guild).map((r) => r.id).slice(0, 20);
      const base = (extra = []) => [
        { type: AT.BlockMessage, metadata: { customMessage: '🚫 Το μήνυμά σου μπλοκαρίστηκε από το AutoMod της ΕΛ.ΑΣ.' } },
        ...(alertId ? [{ type: AT.SendAlertMessage, metadata: { channel: alertId } }] : []),
        ...extra,
      ];
      const rules = [
        { name: 'ΕΛ.ΑΣ. • Profanity / Slurs / Sexual', triggerType: TT.KeywordPreset, triggerMetadata: { presets: [PT.Profanity, PT.SexualContent, PT.Slurs] }, actions: base() },
        { name: 'ΕΛ.ΑΣ. • Mention spam', triggerType: TT.MentionSpam, triggerMetadata: { mentionTotalLimit: config.security.limits.mentions + 1 }, actions: base([{ type: AT.Timeout, metadata: { durationSeconds: 600 } }]) },
        { name: 'ΕΛ.ΑΣ. • Spam', triggerType: TT.Spam, actions: base() },
      ];
      const existing = await i.guild.autoModerationRules.fetch().catch(() => null);
      const lines = [];
      for (const r of rules) {
        try {
          const found = existing?.find((x) => x.name === r.name);
          if (found) await found.edit({ ...r, enabled: true, exemptRoles, reason: 'ΕΛ.ΑΣ. security setup' });
          else await i.guild.autoModerationRules.create({ ...r, eventType: ET.MessageSend, enabled: true, exemptRoles, reason: 'ΕΛ.ΑΣ. security setup' });
          lines.push(`✅ ${r.name}`);
        } catch (e) {
          lines.push(`⚠️ ${r.name} — ${e.message}`);
        }
      }
      return i.editReply(`**Native AutoMod (Discord)**\n${lines.join('\n')}\n\nΤα native rules δουλεύουν ακόμα και αν το bot είναι offline. Το bot κρατάει επιπλέον το δικό του φίλτρο (ελληνικά, Greeklish, leetspeak κ.ά.).`);
    }
  },
};
