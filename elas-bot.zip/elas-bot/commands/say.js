const { SlashCommandBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
const h = require('../utils/helpers');

const field = (id, label, style, required, max, ph) =>
  new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId(id).setLabel(label).setStyle(style).setRequired(required).setMaxLength(max).setPlaceholder(ph ?? ''));

module.exports = {
  prefix: 'say',
  data: new SlashCommandBuilder()
    .setName('say')
    .setDescription('Post a message or a custom embed as the bot (command staff)')
    .addSubcommand((s) =>
      s.setName('text').setDescription('Send a plain message')
        .addStringOption((o) => o.setName('message').setDescription('Text (write \\n for a new line)').setRequired(true).setMaxLength(2000))
        .addChannelOption((o) => o.setName('channel').setDescription('Where (default: here)')))
    .addSubcommand((s) => s.setName('embed').setDescription('Build a custom embed with a form (posts in this channel)')),

  async execute(i) {
    if (!h.isCommand(i.member)) return h.deny(i, 'Μόνο η Διοίκηση μπορεί να το χρησιμοποιήσει.');
    if (i.options.getSubcommand() === 'embed') {
      return i.showModal(new ModalBuilder().setCustomId('say:embed').setTitle('Δημιουργία embed').addComponents(
        field('title', 'Τίτλος', TextInputStyle.Short, false, 200),
        field('description', 'Κείμενο', TextInputStyle.Paragraph, true, 3500),
        field('color', 'Χρώμα (hex, π.χ. #0d5eaf)', TextInputStyle.Short, false, 7, '#0d5eaf'),
        field('image', 'Εικόνα (σύνδεσμος https://…)', TextInputStyle.Short, false, 300),
      ));
    }
    const ch = i.options.getChannel('channel') ?? i.channel;
    if (!ch.isTextBased()) return h.deny(i, 'Διάλεξε κανάλι κειμένου.');
    await ch.send({ content: i.options.getString('message').replace(/\\n/g, '\n'), allowedMentions: { parse: [] } });
    return i.reply({ content: `✅ Στάλθηκε στο ${ch}.`, flags: h.EPH });
  },

  async modal(i) {
    if (!h.isCommand(i.member)) return h.deny(i, 'Μόνο η Διοίκηση μπορεί να το χρησιμοποιήσει.');
    const get = (k) => i.fields.getTextInputValue(k)?.trim();
    const e = h.baseEmbed().setDescription(get('description'));
    if (get('title')) e.setTitle(get('title'));
    if (/^#?[0-9a-f]{6}$/i.test(get('color') || '')) e.setColor(parseInt(get('color').replace('#', ''), 16));
    if (/^https:\/\/\S+$/i.test(get('image') || '')) e.setImage(get('image'));
    await i.channel.send({ embeds: [e], allowedMentions: { parse: [] } });
    return i.reply({ content: '✅ Το embed δημοσιεύτηκε.', flags: h.EPH });
  },
};
