#!/bin/sh
# Daily backup of the bot's data. Usage (crontab -e):  0 4 * * * /opt/elas-bot/scripts/backup.sh
cd "$(dirname "$0")/.." || exit 1
mkdir -p backups
[ -f data/data.json ] && cp data/data.json "backups/data-$(date +%F).json"
# keep the last 14 backups
ls -1t backups/data-*.json 2>/dev/null | tail -n +15 | xargs -r rm --
